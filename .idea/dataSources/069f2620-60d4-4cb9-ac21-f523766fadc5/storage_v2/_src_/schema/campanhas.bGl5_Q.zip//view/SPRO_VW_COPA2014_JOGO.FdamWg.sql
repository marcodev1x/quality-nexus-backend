create definer = admin@`%` view SPRO_VW_COPA2014_JOGO as
select `TB_JOGO`.`ID_JOGO`                                                                                            AS `ID_JOGO`,
       `TB_JOGO`.`ID_TIME_A`                                                                                          AS `ID_TIME_A`,
       `TB_JOGO`.`ID_TIME_B`                                                                                          AS `ID_TIME_B`,
       `TB_JOGO`.`DATA_JOGO`                                                                                          AS `DATA_JOGO`,
       `TB_JOGO`.`DT_HR_JOGO`                                                                                         AS `DT_HR_JOGO`,
       `TB_JOGO`.`HR_TERMINO`                                                                                         AS `HR_TERMINO`,
       `TB_JOGO`.`GOLS_TIME_A`                                                                                        AS `GOLS_TIME_A`,
       `TB_JOGO`.`GOLS_TIME_B`                                                                                        AS `GOLS_TIME_B`,
       `TB_JOGO`.`DT_HR_PLACAR`                                                                                       AS `DT_HR_PLACAR`,
       `TB_JOGO`.`DATA_REGISTRO`                                                                                      AS `DATA_REGISTRO`,
       (select `TB`.`TIME`
        from `campanhas`.`SPRO_COPA2014_TIME` `TB`
        where (`TB`.`ID_TIME` = `TB_JOGO`.`ID_TIME_A`))                                                               AS `TIME_A`,
       (select `TB`.`TIME`
        from `campanhas`.`SPRO_COPA2014_TIME` `TB`
        where (`TB`.`ID_TIME` = `TB_JOGO`.`ID_TIME_B`))                                                               AS `TIME_B`,
       date_format(`TB_JOGO`.`DT_HR_JOGO`, '%d/%m Ã s %H:%i')                                                         AS `DT_HR_JOGO_BR`,
       (select `TB`.`FLAG_IMG`
        from `campanhas`.`SPRO_COPA2014_TIME` `TB`
        where (`TB`.`ID_TIME` = `TB_JOGO`.`ID_TIME_A`))                                                               AS `FLAG_TIME_A`,
       (select `TB`.`FLAG_IMG`
        from `campanhas`.`SPRO_COPA2014_TIME` `TB`
        where (`TB`.`ID_TIME` = `TB_JOGO`.`ID_TIME_B`))                                                               AS `FLAG_TIME_B`
from `campanhas`.`SPRO_COPA2014_JOGO` `TB_JOGO`;

