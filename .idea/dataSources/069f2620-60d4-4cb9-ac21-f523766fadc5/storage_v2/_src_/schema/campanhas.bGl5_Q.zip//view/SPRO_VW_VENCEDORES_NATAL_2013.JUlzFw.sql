create definer = admin@`%` view SPRO_VW_VENCEDORES_NATAL_2013 as
select `TB1`.`ID_PARTICIPANTE` AS `ID_PARTICIPANTE`,
       `TB1`.`NOME`            AS `NOME`,
       `TB1`.`EMAIL`           AS `EMAIL`,
       `TB1`.`CPF`             AS `CPF`,
       `TB1`.`TELEFONE`        AS `TELEFONE`,
       `TB1`.`ID_ESCOLA`       AS `ID_ESCOLA`,
       `TB2`.`DDD_FONE`        AS `DDD_FONE`,
       `TB2`.`FONE`            AS `FONE`,
       `TB2`.`EMAIL`           AS `EMAIL_CONTATO`,
       `TB2`.`CEP`             AS `CEP`,
       `TB2`.`LOGRADOURO`      AS `LOGRADOURO`,
       `TB2`.`COMPLEMENTO`     AS `COMPLEMENTO`,
       `TB2`.`CIDADE`          AS `CIDADE`,
       `TB2`.`UF`              AS `UF`,
       `TB1`.`DATA_REGISTRO`   AS `DATA_REGISTRO`
from (`campanhas`.`SPRO_PARTICIPANTE` `TB1` join `campanhas`.`SPRO_PARTICIPANTE_CONTATO` `TB2`)
where ((`TB1`.`ID_PARTICIPANTE` = `TB2`.`ID_PARTICIPANTE`) and
       `TB1`.`ID_PARTICIPANTE` in (select `campanhas`.`SPRO_PARTICIPANTE_CUPOM`.`ID_PARTICIPANTE`
                                   from `campanhas`.`SPRO_PARTICIPANTE_CUPOM`
                                   where (`campanhas`.`SPRO_PARTICIPANTE_CUPOM`.`ID_CUPOM` in
                                          (47474, 47509, 47817, 47847, 47850, 47882, 48099, 48107, 48116, 48119, 48145,
                                           48180, 48212, 48290, 48298, 48309, 48339, 48363, 48490, 48557, 55559, 55599,
                                           55606, 55656, 55659, 55930, 55932, 55992, 56011, 56030, 56138, 56169, 56296,
                                           56297, 56674, 56705, 56716, 56794, 56846, 56870, 66237, 66336, 66394, 66425,
                                           66579, 66718, 66738, 66776, 66879, 66954, 67007, 67096, 67138, 67238, 67311,
                                           67321, 67362, 67403, 67427, 67455, 69333, 69362, 69438, 69455, 69464, 69493,
                                           69623, 69628, 69661, 69701, 69865, 69984, 70038, 70042, 70114, 70118, 70202,
                                           70273, 70343, 70379, 98789, 99132, 99136, 99157, 99165, 99199, 99206, 99298,
                                           99409, 99625, 99628, 99635, 99648, 99658, 99706, 99731, 99837, 99878, 99927,
                                           99950))));

