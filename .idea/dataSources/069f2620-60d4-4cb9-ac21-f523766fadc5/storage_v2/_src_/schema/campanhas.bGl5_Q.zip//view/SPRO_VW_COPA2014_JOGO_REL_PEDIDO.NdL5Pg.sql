create definer = admin@`%` view SPRO_VW_COPA2014_JOGO_REL_PEDIDO as
select `TB1`.`ID_JOGO_REL_PEDIDO`                         AS `ID_JOGO_REL_PEDIDO`,
       `TB1`.`NUM_PEDIDO`                                 AS `NUM_PEDIDO`,
       `TB1`.`ID_JOGO`                                    AS `ID_JOGO`,
       `TB1`.`PREMIO`                                     AS `PREMIO`,
       `TB1`.`APROVADO_EM`                                AS `APROVADO_EM`,
       `TB1`.`EMAIL_ENV_APOS_JOGO`                        AS `EMAIL_ENV_APOS_JOGO`,
       `TB1`.`DATA_REGISTRO`                              AS `DATA_REGISTRO`,
       (select `TB_TIME`.`TIME`
        from `campanhas`.`SPRO_COPA2014_TIME` `TB_TIME`
        where (`TB_TIME`.`ID_TIME` = `TB2`.`ID_TIME_A`))  AS `TIME_A`,
       (select `TB_JOGO`.`DT_HR_PLACAR`
        from `campanhas`.`SPRO_COPA2014_JOGO` `TB_JOGO`
        where (`TB_JOGO`.`ID_JOGO` = `TB2`.`ID_JOGO`))    AS `DT_HR_PLACAR`,
       (select `TB_TIME`.`FLAG_IMG`
        from `campanhas`.`SPRO_COPA2014_TIME` `TB_TIME`
        where (`TB_TIME`.`ID_TIME` = `TB2`.`ID_TIME_A`))  AS `FLAG_TIME_A`,
       (select `TB_TIME`.`FLAG_IMG`
        from `campanhas`.`SPRO_COPA2014_TIME` `TB_TIME`
        where (`TB_TIME`.`ID_TIME` = `TB2`.`ID_TIME_B`))  AS `FLAG_TIME_B`,
       (select `TB_TIME`.`TIME`
        from `campanhas`.`SPRO_COPA2014_TIME` `TB_TIME`
        where (`TB_TIME`.`ID_TIME` = `TB2`.`ID_TIME_B`))  AS `TIME_B`,
       `TB2`.`DT_HR_JOGO`                                 AS `DT_HR_JOGO`,
       date_format(`TB2`.`DT_HR_JOGO`, '%d/%m Ã s %H:%i') AS `DT_HR_JOGO_BR`,
       `TB2`.`GOLS_TIME_B`                                AS `GOLS_TIME_B`,
       `TB2`.`GOLS_TIME_A`                                AS `GOLS_TIME_A`,
       `TB1`.`ID_USER`                                    AS `ID_USER`
from (`campanhas`.`SPRO_COPA2014_JOGO_REL_PEDIDO` `TB1` join `campanhas`.`SPRO_COPA2014_JOGO` `TB2`)
where (`TB1`.`ID_JOGO` = `TB2`.`ID_JOGO`);

