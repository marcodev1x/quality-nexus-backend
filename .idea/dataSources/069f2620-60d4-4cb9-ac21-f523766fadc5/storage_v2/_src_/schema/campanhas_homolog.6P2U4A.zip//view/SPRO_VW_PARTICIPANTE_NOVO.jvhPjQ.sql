create definer = admin@`%` view SPRO_VW_PARTICIPANTE_NOVO as
select `TB1`.`NOME` AS `NOME`, `TB1`.`EMAIL` AS `EMAIL`, `TB1`.`DATA_REGISTRO` AS `DATA_REGISTRO`
from (`campanhas_homolog`.`SPRO_PARTICIPANTE` `TB1` join `campanhas_homolog`.`SPRO_PARTICIPANTE_CAMPANHA` `TB2`
      on ((`TB1`.`ID_PARTICIPANTE` = `TB2`.`ID_PARTICIPANTE`)))
where (`TB2`.`STATUS` = 'NOVO');

