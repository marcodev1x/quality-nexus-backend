create definer = admin@`%` trigger users_AFTER_DELETE
    after delete
    on users
    for each row
BEGIN
	
	DELETE FROM newsletter WHERE email = OLD.email;
END;

