create definer = admin@`%` trigger users_AFTER_INSERT
    after insert
    on users
    for each row
BEGIN
	SELECT id_newsletter INTO @id_newsletter FROM newsletter WHERE email = NEW.email;
	IF(NEW.newsletter = 1) THEN		
		IF (@id_newsletter > 0) THEN 
			
			UPDATE newsletter SET 
			full_name = NEW.full_name, email = NEW.email, email_confirmed_at = NEW.email_confirmed_at, 
			updated_at = NOW()
			WHERE
			id_newsletter = @id_newsletter;			
		ELSE 
			
			INSERT INTO newsletter (full_name, email, email_confirmed_at, created_at) 
			VALUES(NEW.full_name, NEW.email, NEW.email_confirmed_at, NOW());
		END IF;		
	ELSEIF (@id_newsletter = 0) THEN 
		
		DELETE FROM newsletter WHERE email = NEW.email;		
	END IF;	
END;

