create
    definer = rdsadmin@localhost procedure rds_start_replication_until(IN replication_log_file text, IN replication_stop_point bigint)
BEGIN
    DECLARE v_mysql_version VARCHAR(20);
    DECLARE v_called_by_user VARCHAR(50);
    DECLARE v_replication_threads_running INT;
    DECLARE v_replica_parallel_workers INT;
    DECLARE v_precheck_passed BOOLEAN;
    DECLARE v_autocommit BOOLEAN;
    DECLARE v_sql_log_bin BOOLEAN;
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
      SET @@autocommit=v_autocommit;
      SET @@sql_log_bin=v_sql_log_bin;
      RESIGNAL;
    END;
    SET v_autocommit = @@autocommit;
    SET v_sql_log_bin = @@sql_log_bin;
    SET @@autocommit = 1;
    SET @@sql_log_bin = 0;
    SET v_precheck_passed = True;
    SELECT user() INTO v_called_by_user;
    SELECT version() INTO v_mysql_version;
    SELECT @@replica_parallel_workers into v_replica_parallel_workers;
    SELECT COUNT(1) INTO v_replication_threads_running FROM (SELECT service_state FROM performance_schema.replication_applier_status UNION ALL SELECT service_state FROM performance_schema.replication_connection_status) t WHERE service_state='ON';
    IF v_replication_threads_running > 0 THEN
        SELECT 'Replication is already running. Call mysql.rds_stop_replication to stop replication' AS Message;
        SET v_precheck_passed = False;
    END IF;
    IF v_precheck_passed = True AND v_replica_parallel_workers > 0 THEN
        SELECT 'rds_start_replication_until is not supported for multi-threaded replicas' AS Message;
        SET v_precheck_passed = False;
    END IF;
    IF v_precheck_passed = True AND (replication_log_file IS NULL OR TRIM(replication_log_file) = '') THEN
        SELECT 'Invalid input: replication_log_file cannot be NULL or empty' AS Message;
        SET v_precheck_passed = False;
    END IF;
    IF v_precheck_passed = True AND TRIM(replication_log_file) REGEXP '^.+\\.[0-9]+$' = 0 THEN
      SELECT 'Invalid input: invalid syntax for replication_log_file' AS Message;
      SET v_precheck_passed = False;
    END IF;
    IF v_precheck_passed = True AND (replication_stop_point IS NULL OR replication_stop_point <= 0 ) THEN
        SELECT 'Invalid input: replication_stop_point cannot be NULL, less than or equal to 0' AS Message;
        SET v_precheck_passed = False;
    END IF;
    IF v_precheck_passed = True THEN
        CALL mysql.rds_configure_privilege_checks_user();
        UPDATE mysql.rds_replication_status SET called_by_user = v_called_by_user, action = 'start replica until', mysql_version = v_mysql_version, replication_log_file = TRIM(replication_log_file), replication_stop_point = replication_stop_point, replication_gtid = NULL WHERE action IS NOT NULL;
        COMMIT;
        SET @cmd = CONCAT('START REPLICA UNTIL ', CONCAT_WS(', ', CONCAT('MASTER_LOG_FILE = ', QUOTE(TRIM(replication_log_file))), CONCAT('MASTER_LOG_POS = ', replication_stop_point)));
        PREPARE rds_start_replication_until FROM @cmd;
        EXECUTE rds_start_replication_until;
        DEALLOCATE PREPARE rds_start_replication_until;
        INSERT INTO mysql.rds_history(called_by_user, action, mysql_version, master_log_file, master_log_pos) VALUES(v_called_by_user, 'start replica until', v_mysql_version, SUBSTRING(replication_log_file, 1, 50), replication_stop_point);
        COMMIT;
        SELECT CONCAT('Replica started until MASTER_LOG_FILE = "', TRIM(replication_log_file), '" and MASTER_LOG_POS = ', replication_stop_point) AS Message;
    END IF;
    SET @@sql_log_bin=v_sql_log_bin;
    SET @@autocommit=v_autocommit;
END;

