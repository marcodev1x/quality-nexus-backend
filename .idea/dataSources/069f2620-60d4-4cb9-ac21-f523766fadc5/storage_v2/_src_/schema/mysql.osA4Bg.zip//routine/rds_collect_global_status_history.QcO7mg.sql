create
    definer = rdsadmin@localhost procedure rds_collect_global_status_history()
BEGIN
  DECLARE v_autocommit_status BOOLEAN;
  DECLARE my_row_count INT(5) DEFAULT 0;
  DECLARE sql_logging BOOLEAN;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    SET @@sql_log_bin=sql_logging;
    SET @@autocommit=v_autocommit_status;
    RESIGNAL;
  END;
  SET v_autocommit_status=@@autocommit;
  SET @@autocommit=1;
  SELECT @@sql_log_bin INTO sql_logging;
  SET @@sql_log_bin=off;
  SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
  INSERT INTO rds_global_status_history ( collection_start, variable_name, variable_value, variable_delta )
  SELECT b.collection_end, a.variable_name, a.variable_value, a.variable_value-coalesce(b.variable_value,0) AS variable_delta
  FROM performance_schema.global_status a
  LEFT OUTER JOIN rds_global_status_history b ON a.variable_name = b.variable_name
  WHERE b.collection_end = (SELECT max(collection_end) FROM rds_global_status_history);
  SELECT row_count() INTO my_row_count;
  IF my_row_count = 0
  THEN
    INSERT INTO rds_global_status_history ( collection_start, variable_name, variable_value, variable_delta )
    SELECT NULL, variable_name, variable_value, variable_value FROM performance_schema.global_status ;
  END IF;
  COMMIT;
  SET @@sql_log_bin=sql_logging;
  SET @@autocommit=v_autocommit_status;
END;

