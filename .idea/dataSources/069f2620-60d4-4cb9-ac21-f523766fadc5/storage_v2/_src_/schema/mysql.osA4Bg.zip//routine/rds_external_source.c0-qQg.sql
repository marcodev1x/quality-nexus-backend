create
    definer = rdsadmin@localhost procedure rds_external_source(IN phase varchar(10))
BEGIN
  DECLARE v_autocommit_status BOOLEAN;
  DECLARE v_rdsrepl INT;
  DECLARE v_mysql_version VARCHAR(20);
  DECLARE v_threads_running INT;
  DECLARE v_called_by_user VARCHAR(50);
  DECLARE v_sleep INT;
  DECLARE v_rep_status INT;
  DECLARE v_rep_status_stop INT;
  DECLARE sql_logging BOOLEAN;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    SET @@sql_log_bin = sql_logging;
    SET @@autocommit=v_autocommit_status;
    RESIGNAL;
  END;
  SET v_autocommit_status=@@autocommit;
  SET @@autocommit=1;
  SELECT @@sql_log_bin INTO sql_logging;
  SELECT count(1) INTO v_rep_status_stop FROM mysql.rds_replication_status WHERE action = 'stop slave';
  SELECT count(1) INTO v_rep_status FROM mysql.rds_replication_status;
  SELECT user() INTO v_called_by_user;
  SELECT version() INTO v_mysql_version;
  SELECT count(1) INTO v_rdsrepl FROM mysql.rds_history WHERE action = 'disable set master' AND master_user = 'rdsrepladmin';
  SELECT COUNT(1) INTO v_threads_running FROM (SELECT service_state FROM performance_schema.replication_applier_status UNION ALL SELECT service_state FROM performance_schema.replication_connection_status) t WHERE service_state='ON';
  
  IF v_called_by_user != 'rdsadmin@localhost'
  THEN
    SELECT 'You do not have privileges to call this procedure' AS Message;
  ELSEIF v_rep_status = 0
  THEN
    SET @@sql_log_bin=off;
    INSERT INTO mysql.rds_replication_status(called_by_user, action, mysql_version) VALUES (v_called_by_user,'disable set master',v_mysql_version);
    INSERT INTO mysql.rds_history(called_by_user, action, master_user, mysql_version) VALUES (v_called_by_user,'disable set master','rdsrepladmin',v_mysql_version);
    COMMIT;
  ELSEIF phase NOT IN ('enable','disable')
  THEN
    SELECT 'please use the values enable or disable' AS Message;
  
  
  ELSEIF v_rdsrepl > 0 AND phase = 'disable'
  THEN
    SELECT 'MYSQL.RDS_SET_EXTERNAL_SOURCE is disabled' AS Message;
  
  ELSEIF v_rdsrepl = 0 AND phase = 'disable'
  THEN
    IF v_threads_running > 0
    THEN
      CALL mysql.rds_stop_replication();
      SELECT sleep(1) INTO v_sleep;
      UPDATE mysql.rds_replication_status SET called_by_user=v_called_by_user, action='disable set master', mysql_version=v_mysql_version where action is not null;
      COMMIT;
      SELECT sleep(1) INTO v_sleep;
      INSERT INTO mysql.rds_history(called_by_user, action, mysql_version, master_user) VALUES (v_called_by_user,'disable set master', v_mysql_version, 'rdsrepladmin');
      COMMIT;
      SELECT 'Replication has been stopped and MYSQL.RDS_SET_EXTERNAL_SOURCE has been disabled' AS Message;
    ELSE
      UPDATE mysql.rds_replication_status SET called_by_user=v_called_by_user, action='disable set master', mysql_version=v_mysql_version where action is not null;
      COMMIT;
      SELECT sleep(1) INTO v_sleep;
      INSERT INTO mysql.rds_history(called_by_user, action, mysql_version, master_user) VALUES (v_called_by_user,'disable set master', v_mysql_version, 'rdsrepladmin');
      COMMIT;
      SELECT 'MYSQL.RDS_SET_EXTERNAL_SOURCE has been disabled' AS Message;
    END IF;
  
  ELSEIF v_rdsrepl = 0 AND phase = 'enable'
  THEN
    IF v_threads_running > 0
    THEN
      UPDATE mysql.rds_replication_status SET called_by_user=v_called_by_user,action='enable set master', mysql_version=v_mysql_version where action is not null;
      COMMIT;
      SELECT 'MYSQL.RDS_SET_EXTERNAL_SOURCE is enabled.' AS Message;
    END IF;
  ELSEIF v_rdsrepl > 0 AND phase = 'enable'
  THEN
    UPDATE mysql.rds_replication_status SET called_by_user=v_called_by_user,action='enable set master', mysql_version=v_mysql_version where action is not null;
    COMMIT;
    SELECT sleep(1) INTO v_sleep;
    UPDATE mysql.rds_history SET action = 'enable set master' where action = 'disable set master' and master_user = 'rdsrepladmin';
    COMMIT;
    SELECT 'MYSQL.RDS_SET_EXTERNAL_SOURCE has been enabled' AS Message;
  END IF;
  IF v_rep_status_stop = 1
  THEN
    UPDATE mysql.rds_replication_status SET called_by_user=v_called_by_user,action='stop slave', mysql_version=v_mysql_version where action is not null;
    COMMIT;
  END IF;
  SET @@sql_log_bin=sql_logging;
  SET @@autocommit=v_autocommit_status;
END;

