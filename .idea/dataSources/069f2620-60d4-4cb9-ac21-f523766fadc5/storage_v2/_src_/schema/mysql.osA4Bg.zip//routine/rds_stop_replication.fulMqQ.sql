create
    definer = rdsadmin@localhost procedure rds_stop_replication()
BEGIN
  DECLARE v_autocommit_status BOOLEAN;
  DECLARE v_mysql_version VARCHAR(20);
  DECLARE v_threads_running INT;
  DECLARE v_called_by_user VARCHAR(50);
  DECLARE v_sleep INT;
  DECLARE sql_logging BOOLEAN;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    SET @@sql_log_bin=sql_logging;
    SET @@autocommit=v_autocommit_status;
    RESIGNAL;
  END;
  SET v_autocommit_status=@@autocommit;
  SET @@autocommit=1;
  SELECT @@sql_log_bin INTO sql_logging;
  SELECT user() INTO v_called_by_user;
  SELECT version() INTO v_mysql_version;
  SELECT COUNT(1) INTO v_threads_running FROM (SELECT service_state FROM performance_schema.replication_applier_status UNION ALL SELECT service_state FROM performance_schema.replication_connection_status) t WHERE service_state='ON';
  IF v_threads_running > 0
  THEN
    SET @@sql_log_bin = OFF;
    UPDATE mysql.rds_replication_status SET called_by_user=v_called_by_user,action='stop slave', mysql_version=v_mysql_version where action is not null;
    COMMIT;
    SELECT sleep(1) INTO v_sleep;
    STOP REPLICA;
    SELECT COUNT(1) INTO v_threads_running FROM (SELECT service_state FROM performance_schema.replication_applier_status UNION ALL SELECT service_state FROM performance_schema.replication_connection_status) t WHERE service_state='ON';
    IF v_threads_running = 0
    THEN
      INSERT INTO mysql.rds_history (called_by_user,action,mysql_version) VALUES (v_called_by_user,'stop slave',v_mysql_version);
      COMMIT;
      SELECT 'Replica is down or disabled' AS Message;
    ELSE
      SELECT 'Replica has encountered an error. Run SHOW REPLICA STATUS; to see the error.' AS Message;
    END IF;
  ELSE
    IF v_threads_running < 1
    THEN
      SELECT 'Replica is already stopped or may not be configured. Run SHOW REPLICA STATUS;' AS Message;
    END IF;
  END IF;
  SET @@sql_log_bin=sql_logging;
  SET @@autocommit=v_autocommit_status;
END;

