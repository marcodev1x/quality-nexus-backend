create
    definer = rdsadmin@localhost procedure rds_remove_binlog_ssl_material() deterministic reads sql data
BEGIN
  CALL ACTION ebr_remove_ssl_material();
END;

