create
    definer = rdsadmin@localhost function get_enable_persist_ro_replica_status_var() returns tinyint reads sql data
    RETURN @@aurora_enable_persist_ro_replica_status;

