create
    definer = rdsadmin@localhost procedure rds_skip_transaction_with_gtid(IN gtid_to_skip varchar(57))
    deterministic
    reads sql data
BEGIN
  DECLARE v_autocommit_status BOOLEAN;
  DECLARE v_threads_running int;
  DECLARE v_sleep int;
  DECLARE v_called_by_user VARCHAR(50);
  DECLARE v_mysql_version VARCHAR(20);
  DECLARE sql_logging BOOLEAN;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    SET @@sql_log_bin = sql_logging;
    SET @@autocommit=v_autocommit_status;
    RESIGNAL;
  END;
  SET v_autocommit_status=@@autocommit;
  SET @@autocommit=1;
  SELECT @@sql_log_bin INTO sql_logging;
  SELECT user() INTO v_called_by_user;
  SELECT version() INTO v_mysql_version;
  SET @regex = '^([[:alnum:]]+-){4}[[:alnum:]]+:[[:digit:]]+$';
  IF gtid_to_skip REGEXP @regex = 1
  THEN
    SET @@sql_log_bin=off;
    SET GTID_NEXT=gtid_to_skip;
    START TRANSACTION;
    COMMIT;
    SET GTID_NEXT="AUTOMATIC";
    SELECT 'Transaction has been skipped successfully.' as Message;
    SET @@sql_log_bin=off;
    INSERT into mysql.rds_history(called_by_user, action, mysql_version) values (v_called_by_user,'rds_skip_transaction_with_gtid:OK',v_mysql_version);
    COMMIT;
    SET @@sql_log_bin=sql_logging;
  ELSE
    SELECT "Invalid input GTID." as Message;
  END IF;
  SET @@autocommit=v_autocommit_status;
END;

