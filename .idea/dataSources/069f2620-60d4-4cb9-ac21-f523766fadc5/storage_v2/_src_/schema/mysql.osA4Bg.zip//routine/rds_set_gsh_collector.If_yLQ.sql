create
    definer = rdsadmin@localhost procedure rds_set_gsh_collector(IN p_period int)
BEGIN
  DECLARE v_autocommit_status BOOLEAN;
  DECLARE v_es VARCHAR(3);
  DECLARE sql_logging BOOLEAN;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    SET @@sql_log_bin=sql_logging;
    SET @@autocommit=v_autocommit_status;
    RESIGNAL;
  END;
  SET v_autocommit_status=@@autocommit;
  SET @@autocommit=1;
  SELECT @@sql_log_bin INTO sql_logging;
  SET @@sql_log_bin=off;
  SELECT variable_value INTO v_es FROM performance_schema.global_variables WHERE variable_name = 'EVENT_SCHEDULER';
  IF v_es = 'ON' THEN
        ALTER EVENT ev_rds_gsh_collector ON SCHEDULE EVERY p_period MINUTE STARTS CURRENT_TIMESTAMP ENABLE;
        SELECT concat('Collector Enabled every ', p_period ,' Minutes, Scheduler is Active') AS `Success`;
  ELSE
        SELECT 'Scheduler is NOT Active' AS `Failure`
        UNION ALL
        SELECT 'Please change the parameter event_scheduler=ON in your Parameter Group' AS `Status`;
  END IF;
  SET @@sql_log_bin=sql_logging;
  SET @@autocommit=v_autocommit_status;
END;

