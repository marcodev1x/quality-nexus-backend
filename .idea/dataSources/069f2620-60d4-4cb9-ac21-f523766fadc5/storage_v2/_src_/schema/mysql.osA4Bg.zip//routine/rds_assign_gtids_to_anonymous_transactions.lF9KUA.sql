create
    definer = rdsadmin@localhost procedure rds_assign_gtids_to_anonymous_transactions(IN gtid_opt varchar(255))
    deterministic
    reads sql data
BEGIN
  DECLARE v_autocommit_status BOOLEAN;
  DECLARE sql_logging BOOLEAN;
  SET v_autocommit_status=@@autocommit;
  SET @@autocommit=1;
SELECT @@sql_log_bin into sql_logging;
SET @@sql_log_bin=off;
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
BEGIN
      SET @@sql_log_bin=sql_logging;
      SET @@autocommit=v_autocommit_status;
      START replica;
SELECT 'An error occurred. Valid values are: OFF, LOCAL, or <uuid>. You must have GTID=ON for values LOCAL or <uuid>.' as Message;
END;
    STOP replica;
    IF (gtid_opt = 'OFF' OR gtid_opt = 'LOCAL') THEN
      SET @cmd = CONCAT('CHANGE REPLICATION SOURCE TO ASSIGN_GTIDS_TO_ANONYMOUS_TRANSACTIONS = ', gtid_opt);
ELSE
      SET @cmd = CONCAT('CHANGE REPLICATION SOURCE TO ASSIGN_GTIDS_TO_ANONYMOUS_TRANSACTIONS = ', QUOTE(gtid_opt));
END IF;
PREPARE rds_assign_gtid FROM @cmd;
EXECUTE rds_assign_gtid;
DEALLOCATE PREPARE rds_assign_gtid;
START replica;
SELECT CONCAT('ASSIGN_GTIDS_TO_ANONYMOUS_TRANSACTIONS has been set to: ', gtid_opt) AS Message;
COMMIT;
END;
  SET @@sql_log_bin=sql_logging;
  SET @@autocommit=v_autocommit_status;
END;

