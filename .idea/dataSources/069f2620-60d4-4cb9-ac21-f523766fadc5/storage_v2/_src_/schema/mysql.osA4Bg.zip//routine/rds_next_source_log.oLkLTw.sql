create
    definer = rdsadmin@localhost procedure rds_next_source_log(IN curr_source_log int) deterministic reads sql data
BEGIN
  DECLARE v_autocommit_status BOOLEAN;
  DECLARE v_threads_running INT;
  DECLARE v_sleep INT;
  DECLARE v_called_by_user VARCHAR(50);
  DECLARE v_mysql_version VARCHAR(20);
  DECLARE sql_logging BOOLEAN;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    SET @@sql_log_bin = sql_logging;
    SET @@autocommit=v_autocommit_status;
    RESIGNAL;
  END;
  SET v_autocommit_status=@@autocommit;
  SET @@autocommit=1;
  SELECT @@sql_log_bin into sql_logging;
  SELECT user() into v_called_by_user;
  SELECT version() into v_mysql_version;
  SELECT COUNT(1) INTO v_threads_running FROM (SELECT service_state FROM performance_schema.replication_applier_status UNION ALL SELECT service_state FROM performance_schema.replication_connection_status) t WHERE service_state='ON';
  IF v_threads_running = 1 
  THEN
    SET @cmd = CONCAT('CHANGE REPLICATION SOURCE TO SOURCE_LOG_FILE = "',
    CONCAT('mysql-bin-changelog.', LPAD('1' + curr_source_log, 6, '0')), '",
    SOURCE_LOG_POS = 4');
    STOP REPLICA;
    PREPARE rds_set_source FROM @cmd;
    EXECUTE rds_set_source;
    DEALLOCATE PREPARE rds_set_source;
    START REPLICA;
    SELECT 'Source Log Position has been set to start of next log' AS Message;
    SELECT sleep(2) INTO v_sleep;
    SELECT COUNT(1) INTO v_threads_running FROM (SELECT service_state FROM performance_schema.replication_applier_status UNION ALL SELECT service_state FROM performance_schema.replication_connection_status) t WHERE service_state='ON';
    SET @@sql_log_bin=off;
    IF v_threads_running = 2 THEN
      SELECT 'Replica is running normally' AS Message;
      INSERT into mysql.rds_history(called_by_user, action, mysql_version, master_log_file, master_log_pos) values (v_called_by_user,'next_master_log:OK', v_mysql_version, CONCAT('mysql-bin-changelog.', LPAD('1' + curr_master_log, 6, '0')),4);
      COMMIT;
    ELSE
      SELECT 'Replica has encountered a new error. Please use SHOW REPLICA STATUS to see the error.' AS Message;
      INSERT into mysql.rds_history(called_by_user, action, mysql_version, master_log_file, master_log_pos) values (v_called_by_user,'next_master_log:ERR', v_mysql_version, CONCAT('mysql-bin-changelog.', LPAD('1' + curr_master_log, 6, '0')),4);
      COMMIT;
    END IF;
    SET @@sql_log_bin=sql_logging;
  ELSEIF v_threads_running = 2 
  THEN
    SELECT 'Replica is running normally.  No errors detected to skip.' AS Message;
  ELSEIF v_threads_running = 0 
  THEN
    SELECT 'Replica is down or disabled.' AS Message;
  END IF;
  SET @@autocommit=v_autocommit_status;
END;

