create
    definer = rdsadmin@localhost procedure rds_set_external_source(IN host varchar(255), IN port int, IN user text,
                                                                   IN passwd text, IN name text, IN pos bigint unsigned,
                                                                   IN enable_ssl_encryption tinyint(1))
    deterministic
    reads sql data
BEGIN
  DECLARE v_autocommit_status BOOLEAN;
  DECLARE v_rdsrepl INT;
  DECLARE v_mysql_version VARCHAR(20);
  DECLARE v_called_by_user VARCHAR(50);
  DECLARE v_sleep int;
  DECLARE sql_logging BOOLEAN;
  DECLARE v_exit BOOLEAN DEFAULT FALSE;
  DECLARE EXIT HANDLER FOR 1105
BEGIN
SELECT 'Missing SSL Materials: please run mysql.rds_import_binlog_ssl_material first.' as Error;
SET v_exit = TRUE;
    SET @@sql_log_bin=sql_logging;
    SET @@autocommit=v_autocommit_status;
END;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
BEGIN
    SET @@sql_log_bin=sql_logging;
    SET @@autocommit=v_autocommit_status;
    RESIGNAL;
END;
  SET v_autocommit_status=@@autocommit;
  SET @@autocommit=1;
SELECT @@sql_log_bin into sql_logging;
SET @regex = '.*\"[[:space:]]*,[[:space:]]*[a-zA-Z_]+[[:space:]]*=[[:space:]]*\".*';
  IF host REGEXP @regex
  OR user REGEXP @regex
  OR passwd REGEXP @regex
  OR name REGEXP @regex THEN
SELECT "Invalid arguments" AS Message;
ELSE
SELECT count(1) into v_rdsrepl from mysql.rds_history where action = 'disable set master' and master_user = 'rdsrepladmin';
SELECT user() into v_called_by_user;
SELECT version() into v_mysql_version;
SET @@sql_log_bin=off;
    IF v_rdsrepl > 0 and v_called_by_user != 'rdsadmin@localhost' THEN
SELECT 'RDS_SET_EXTERNAL_SOURCE is disabled on this host.' AS Message;
ELSE
      IF enable_ssl_encryption = 1 THEN
        CALL ACTION ebr_export_ssl_material();
        SET @cmd = CONCAT('CHANGE REPLICATION SOURCE TO ',
        CONCAT('SOURCE_HOST = ', QUOTE(trim(both from host)), ', '),
        CONCAT('SOURCE_PORT = ', port, ', '),
        CONCAT('SOURCE_USER = ', QUOTE(trim(both from user)), ', '),
        CONCAT('SOURCE_PASSWORD = ', QUOTE(trim(both from passwd)), ', '),
        CONCAT('SOURCE_LOG_FILE = ', QUOTE(trim(both from name)), ', '),
        CONCAT('SOURCE_LOG_POS = ', pos, ', '),
        CONCAT('SOURCE_SSL = ', enable_ssl_encryption, ', '),
        CONCAT('SOURCE_SSL_CA = "/rdsdbdata/sslreplication/ssl_ca.pem"', ', '),
        CONCAT('SOURCE_SSL_CERT = "/rdsdbdata/sslreplication/ssl_cert.pem"', ', '),
        CONCAT('SOURCE_SSL_KEY = "/rdsdbdata/sslreplication/ssl_key.pem"', ', '),
        CONCAT('SOURCE_AUTO_POSITION = 0, '),
        CONCAT('PRIVILEGE_CHECKS_USER = NULL'));
ELSE
        SET @cmd = CONCAT('CHANGE REPLICATION SOURCE TO ',
        CONCAT('SOURCE_HOST = ', QUOTE(trim(both from host)), ', '),
        CONCAT('SOURCE_PORT = ', port, ', '),
        CONCAT('SOURCE_USER = ', QUOTE(trim(both from user)), ', '),
        CONCAT('SOURCE_PASSWORD = ', QUOTE(trim(both from passwd)), ', '),
        CONCAT('SOURCE_LOG_FILE = ', QUOTE(trim(both from name)), ', '),
        CONCAT('SOURCE_LOG_POS = ', pos, ', '),
        CONCAT('SOURCE_SSL = ', enable_ssl_encryption, ', '),
        CONCAT('SOURCE_SSL_CA = "', '", '),
        CONCAT('SOURCE_SSL_CERT = "', '", '),
        CONCAT('SOURCE_SSL_KEY = "', '", '),
        CONCAT('SOURCE_AUTO_POSITION = 0, '),
        CONCAT('PRIVILEGE_CHECKS_USER = NULL'));
END IF;
PREPARE rds_set_source FROM @cmd;
update mysql.rds_replication_status set called_by_user=v_called_by_user, action='set master', mysql_version=v_mysql_version , master_host=trim(both from host), master_port=port where action is not null;
COMMIT;
BEGIN
        DECLARE CONTINUE HANDLER FOR 1105 BEGIN END;
END;
EXECUTE rds_set_source;
DEALLOCATE PREPARE rds_set_source;
INSERT into mysql.rds_history(called_by_user, action, mysql_version, master_host, master_port, master_user, master_log_file, master_log_pos, master_ssl, auto_position)
values (v_called_by_user,'set master', v_mysql_version, trim(both from host), port, trim(both from user), trim(both from name), pos, enable_ssl_encryption, 0);
COMMIT;
END IF;
    SET @@sql_log_bin=sql_logging;
END IF;
  SET @@autocommit=v_autocommit_status;
END;

