create
    definer = rdsadmin@localhost procedure rds_rotate_slow_log() deterministic reads sql data
BEGIN
  DECLARE v_autocommit_status BOOLEAN;
  DECLARE org_sql_bin_log BOOLEAN DEFAULT 0;
  DECLARE is_locked BOOLEAN DEFAULT 0;
  DECLARE lock_rec_value INTEGER;
  DECLARE repair_table_type INTEGER DEFAULT 0;
  DECLARE errno INT;
  DECLARE msg TEXT;
  DECLARE CONTINUE HANDLER FOR 1194
  BEGIN
    IF repair_table_type = 1 THEN
      REPAIR NO_WRITE_TO_BINLOG TABLE mysql.slow_log;
    END IF;
    IF repair_table_type = 2 THEN
      REPAIR NO_WRITE_TO_BINLOG TABLE mysql.slow_log_backup;
    END IF;
    IF repair_table_type = 3 THEN
      REPAIR NO_WRITE_TO_BINLOG TABLE mysql.slow_log2;
    END IF;
  END;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    GET CURRENT DIAGNOSTICS CONDITION 1
    errno = MYSQL_ERRNO, msg = MESSAGE_TEXT;
    SELECT errno, msg;
    SET SESSION sql_log_bin = org_sql_bin_log;
    SET @@autocommit=v_autocommit_status;
    IF is_locked = 1 THEN
      SELECT RELEASE_LOCK('rds_rotate_slow_log_lock_927562058') INTO lock_rec_value;
      SET is_locked = 0;
    END IF;
  END;
  SET v_autocommit_status=@@autocommit;
  SELECT @@SESSION.sql_log_bin INTO org_sql_bin_log;
  SET @@autocommit=1;
  SELECT GET_LOCK('rds_rotate_slow_log_lock_927562058', 0) INTO lock_rec_value;
  SET is_locked = 1;
  IF lock_rec_value = 1 THEN
    SET SESSION sql_log_bin = off;
    IF EXISTS(SELECT table_name FROM information_schema.tables WHERE table_name = 'slow_log' AND table_schema = 'mysql') THEN
      SET repair_table_type = 1;
      SET @output = (SELECT 1 FROM slow_log LIMIT 1);
    END IF;
    IF EXISTS(SELECT table_name FROM information_schema.tables WHERE table_name = 'slow_log_backup' AND table_schema = 'mysql') THEN
      SET repair_table_type = 2;
      SET @output = (SELECT 1 FROM slow_log_backup LIMIT 1);
    END IF;
    IF EXISTS(SELECT table_name FROM information_schema.tables WHERE table_name = 'slow_log2' AND table_schema = 'mysql') THEN
      SET repair_table_type = 3;
      SET @output = (SELECT 1 FROM slow_log2 LIMIT 1);
    END IF;
    IF EXISTS(SELECT table_name FROM information_schema.tables WHERE table_name = 'slow_log2' AND table_schema = 'mysql') THEN
      IF NOT EXISTS(SELECT table_name FROM information_schema.tables WHERE table_name = 'slow_log' AND table_schema = 'mysql') THEN
        RENAME TABLE mysql.slow_log_backup TO mysql.slow_log, mysql.slow_log2 TO mysql.slow_log_backup;
      ELSEIF NOT EXISTS(SELECT table_name FROM information_schema.tables WHERE table_name = 'slow_log_backup' AND table_schema = 'mysql') THEN
        RENAME TABLE mysql.slow_log2 TO mysql.slow_log_backup;
      ELSE
        DROP TABLE IF EXISTS slow_log2;
      END IF;
    END IF;
    TRUNCATE TABLE mysql.slow_log_backup;
    RENAME TABLE mysql.slow_log_backup TO mysql.slow_log2, mysql.slow_log TO mysql.slow_log_backup, mysql.slow_log2 TO mysql.slow_log;
    SET SESSION sql_log_bin = org_sql_bin_log;
    SELECT RELEASE_LOCK('rds_rotate_slow_log_lock_927562058') INTO lock_rec_value;
    SET is_locked = 0;
  ELSE
    SELECT 'the other operation of rotating the slow log is in process' AS message_text;
  END IF;
  SET @@autocommit=v_autocommit_status;
END;

