create
    definer = rdsadmin@localhost procedure rds_rotate_global_status_history()
BEGIN
  DECLARE v_autocommit_status BOOLEAN;
  DECLARE sql_logging BOOLEAN;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    SET @@sql_log_bin=sql_logging;
    SET @@autocommit=v_autocommit_status;
    RESIGNAL;
  END;
  SET v_autocommit_status=@@autocommit;
  SET @@autocommit=1;
  SELECT @@sql_log_bin INTO sql_logging;
  SET @@sql_log_bin=off;
  DROP TABLE mysql.rds_global_status_history_old;
  RENAME TABLE mysql.rds_global_status_history TO mysql.rds_global_status_history_old;
  CREATE TABLE mysql.rds_global_status_history LIKE mysql.rds_global_status_history_old;
  SET @@sql_log_bin=sql_logging;
  SET @@autocommit=v_autocommit_status;
END;

