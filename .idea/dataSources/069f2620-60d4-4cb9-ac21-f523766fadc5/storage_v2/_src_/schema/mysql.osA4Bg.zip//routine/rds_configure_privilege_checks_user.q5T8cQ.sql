create
    definer = rdsadmin@localhost procedure rds_configure_privilege_checks_user()
BEGIN
  DECLARE is_user_created BOOLEAN;
  DECLARE is_user_set BOOLEAN;
  DECLARE is_user_role_set BOOLEAN;
  DECLARE is_role_created BOOLEAN;
  DECLARE username VARCHAR(30) DEFAULT 'rdsrepladmin_priv_checks_user';
  DECLARE hostname VARCHAR(10) DEFAULT 'localhost';
  DECLARE v_replication_threads_running INT;
  DECLARE v_autocommit_status BOOLEAN;
  DECLARE sql_logging BOOLEAN;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    SET @@sql_log_bin=sql_logging;
    SET @@autocommit=v_autocommit_status;
    RESIGNAL;
  END;
  SET v_autocommit_status=@@autocommit;
  SET @@autocommit=1;
  SELECT @@sql_log_bin into sql_logging;
  SET @@sql_log_bin=off;
  SELECT COUNT(1) INTO v_replication_threads_running FROM (SELECT service_state FROM performance_schema.replication_applier_status UNION ALL SELECT service_state FROM performance_schema.replication_connection_status) t WHERE service_state='ON';
  IF v_replication_threads_running > 0 THEN
    SELECT 'Replication is already running. Call mysql.rds_stop_replication to stop replication' AS Message;
  ELSE
    SET @cmd='';
    SELECT EXISTS(SELECT * FROM mysql.user WHERE user=username AND host=hostname) INTO is_user_created;
    SELECT EXISTS(SELECT * FROM mysql.default_roles WHERE user=username AND host=hostname AND default_role_user='rds_superuser_role' AND default_role_host='%') AND EXISTS(SELECT * FROM mysql.global_grants WHERE user=username AND host=hostname AND priv='REPLICATION_APPLIER')  INTO is_user_role_set;
    SELECT EXISTS(SELECT * FROM mysql.slave_relay_log_info WHERE Privilege_checks_username=username AND Privilege_checks_hostname=hostname) INTO is_user_set;
    SELECT EXISTS(SELECT * FROM mysql.user WHERE user='rds_superuser_role' AND host='%') INTO is_role_created;
    IF is_role_created = False THEN
      SET @@sql_log_bin=sql_logging;
      SET @@autocommit=v_autocommit_status;
      SELECT 'rds_superuser_role needs to be present in order to start replication.' INTO @msg;
      SIGNAL SQLSTATE VALUE '45000' SET MESSAGE_TEXT = @msg;
    END IF;
    IF (is_user_created = True AND is_user_role_set = False) THEN
      SET @@sql_log_bin=sql_logging;
      SET @@autocommit=v_autocommit_status;
      SELECT CONCAT('Please drop the user ', QUOTE(username), '@', QUOTE(hostname), ' in order to start replication.') INTO @msg;
      SIGNAL SQLSTATE VALUE '45000' SET MESSAGE_TEXT = @msg;
    END IF;
    IF is_user_created = False THEN
      SELECT CONCAT('CREATE USER ', QUOTE(username), '@', QUOTE(hostname), " IDENTIFIED WITH 'caching_sha2_password' AS '$A$005$THISISACOMBINATIONOFINVALIDSALTANDPASSWORDTHATMUSTNEVERBRBEUSED' PASSWORD EXPIRE NEVER ACCOUNT LOCK;") INTO @cmd;
      PREPARE create_user FROM @cmd;
      EXECUTE create_user;
    END IF;
    IF is_user_role_set = False THEN
      SELECT CONCAT('GRANT rds_superuser_role TO ', QUOTE(username), '@', QUOTE(hostname)) INTO @cmd;
      PREPARE grant_user_role FROM @cmd;
      EXECUTE grant_user_role;
      SELECT CONCAT('SET DEFAULT ROLE rds_superuser_role TO ', QUOTE(username), '@', QUOTE(hostname)) INTO @cmd;
      PREPARE set_user_role FROM @cmd;
      EXECUTE set_user_role;
      SELECT CONCAT('GRANT REPLICATION_APPLIER ON *.* TO ', QUOTE(username), '@', QUOTE(hostname)) INTO @cmd;
      PREPARE set_user_applier FROM @cmd;
      EXECUTE set_user_applier;
    END IF;
    IF is_user_set = False THEN
      SELECT CONCAT('CHANGE REPLICATION SOURCE TO PRIVILEGE_CHECKS_USER = ', QUOTE(username), '@', QUOTE(hostname), ';') INTO @cmd;
      PREPARE set_priv_checks_user FROM @cmd;
      EXECUTE set_priv_checks_user;
    END IF;
  END IF;
  SET @@sql_log_bin=sql_logging;
  SET @@autocommit=v_autocommit_status;
END;

