create
    definer = rdsadmin@localhost procedure rds_gtid_purged(IN gtid_set text)
BEGIN
IF (gtid_set IS NULL OR TRIM(gtid_set) = '') THEN
    SELECT 'Invalid input: gtid cannot be NULL or empty' AS Message;
ELSE
  SET GLOBAL GTID_PURGED = gtid_set;
END IF;
END;

