create
    definer = rdsadmin@localhost procedure rds_set_configuration(IN name varchar(30), IN value int)
    deterministic
    reads sql data
BEGIN
  DECLARE v_autocommit_status BOOLEAN;
  DECLARE sql_logging BOOLEAN;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    SET @@sql_log_bin = sql_logging;
    SET @@autocommit=v_autocommit_status;
    RESIGNAL;
  END;
  SET v_autocommit_status=@@autocommit;
  SET @@autocommit=1;
  SELECT @@sql_log_bin INTO sql_logging;
  IF name = 'binlog retention hours' AND value < 1 THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'For binlog retention hours the value must be between 1 and 2160 inclusive or be NULL';
  END IF;
  IF name = 'binlog retention hours' AND value > 2160 THEN
    SET value = 2160;
  END IF;
  SET @@sql_log_bin = OFF;
  UPDATE mysql.rds_configuration
  SET mysql.rds_configuration.value = value
  WHERE BINARY mysql.rds_configuration.name = BINARY name;
  SET @@sql_log_bin = sql_logging;
  SET @@autocommit=v_autocommit_status;
END;

