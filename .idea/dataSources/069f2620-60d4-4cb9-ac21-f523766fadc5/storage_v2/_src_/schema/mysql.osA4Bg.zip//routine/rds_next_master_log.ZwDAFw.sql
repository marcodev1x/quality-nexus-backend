create
    definer = rdsadmin@localhost procedure rds_next_master_log(IN curr_master_log int) deterministic reads sql data
BEGIN
  SELECT 'rds_next_master_log is deprecated and will be removed in a future release. Use rds_next_source_log instead. Refer to the documentation for more information on deprecated statements' AS Message;
  CALL `mysql`.`rds_next_source_log`(curr_master_log);
END;

