create
    definer = rdsadmin@localhost procedure rds_disable_gsh_collector()
BEGIN
  DECLARE v_autocommit_status BOOLEAN;
  DECLARE sql_logging BOOLEAN;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    SET @@sql_log_bin=sql_logging;
    SET @@autocommit=v_autocommit_status;
    RESIGNAL;
  END;
  SET v_autocommit_status=@@autocommit;
  SET @@autocommit=1;
  SELECT @@sql_log_bin INTO sql_logging;
  SET @@sql_log_bin=off;
  ALTER EVENT ev_rds_gsh_collector DISABLE;
  SELECT 'Collector Disabled' AS `Success`;
  SET @@sql_log_bin=sql_logging;
  SET @@autocommit=v_autocommit_status;
END;

