create definer = rdsadmin@localhost trigger block_metadata_md_d
    before delete
    on metadata_md_table
    for each row
BEGIN   DECLARE foo varchar(255);	IF user() NOT IN ('rdsadmin@localhost', '', 'rdsadmin@connecting host') THEN			SELECT `ERROR (RDS): CANNOT DELETE from metadata_md_table` INTO foo FROM mysql.metadata_md_table;		END IF;		END;

