create
    definer = rdsadmin@localhost procedure rds_reset_external_source() deterministic reads sql data
BEGIN
  DECLARE v_autocommit_status BOOLEAN;
  DECLARE v_rdsrepl INT;
  DECLARE v_mysql_version VARCHAR(20);
  DECLARE v_called_by_user VARCHAR(50);
  DECLARE v_sleep int;
  DECLARE v_threads_running INT;
  DECLARE sql_logging BOOLEAN;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    SET @@sql_log_bin=sql_logging;
    SET @@autocommit=v_autocommit_status;
    RESIGNAL;
  END;
  SET v_autocommit_status=@@autocommit;
  SET @@autocommit=1;
  SELECT @@sql_log_bin into sql_logging;
  SELECT count(1) into v_rdsrepl FROM mysql.rds_history WHERE action = 'disable set master' AND master_user = 'rdsrepladmin';
  SELECT user() into v_called_by_user;
  SELECT version() into v_mysql_version;
  SELECT COUNT(1) INTO v_threads_running FROM (SELECT service_state FROM performance_schema.replication_applier_status UNION ALL SELECT service_state FROM performance_schema.replication_connection_status) t WHERE service_state='ON';
  SET @@sql_log_bin=off;
  IF  v_rdsrepl > 0 and  v_called_by_user != 'rdsadmin@localhost' THEN
    SELECT 'Permission Denied: This instance is a RDS Read Replica.' AS Message;
  ELSE
    IF v_threads_running = 0 THEN
      UPDATE mysql.rds_replication_status SET called_by_user=v_called_by_user, action='reset slave', mysql_version=v_mysql_version, master_host=NULL, master_port=NULL where action is not null;
      COMMIT;
      RESET REPLICA ALL;
      INSERT INTO mysql.rds_history(called_by_user, action, mysql_version) VALUES (v_called_by_user,'reset slave', v_mysql_version);
      COMMIT;
      SELECT 'Replica has been reset' AS Message;
    ELSE
      CALL mysql.rds_stop_replication;
      SELECT sleep(1) into v_sleep;
      UPDATE mysql.rds_replication_status set called_by_user=v_called_by_user, action='reset slave', mysql_version=v_mysql_version, master_host=NULL, master_port=NULL where action is not null;
      COMMIT;
      SELECT sleep(1) INTO v_sleep;
      RESET REPLICA ALL;
      INSERT INTO mysql.rds_history(called_by_user, action, mysql_version) VALUES (v_called_by_user,'reset slave', v_mysql_version);
      COMMIT;
      SELECT 'Replica has been reset' AS Message;
    END IF;
  END IF;
  SET @@sql_log_bin=sql_logging;
  SET @@autocommit=v_autocommit_status;
END;

