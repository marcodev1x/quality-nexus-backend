create definer = admin@`%` trigger SPRO_permission_user_before_delete
    after delete
    on permission_user
    for each row
BEGIN
	CALL `fcUpdateUserPermission`(OLD.user_id);
END;

