create definer = admin@`%` trigger SPRO_role_user_before_delete
    after delete
    on role_user
    for each row
BEGIN
	CALL `fcUpdateUserPermission`(OLD.user_id);
END;

