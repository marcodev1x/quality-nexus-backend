create definer = admin@`%` trigger SPRO_permission_user_after_insert
    after insert
    on permission_user
    for each row
BEGIN
	CALL `fcUpdateUserPermission`(NEW.user_id);
END;

