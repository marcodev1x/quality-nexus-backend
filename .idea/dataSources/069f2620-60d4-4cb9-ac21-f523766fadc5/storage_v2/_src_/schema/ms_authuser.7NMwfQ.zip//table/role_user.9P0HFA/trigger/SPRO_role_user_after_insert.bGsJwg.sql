create definer = admin@`%` trigger SPRO_role_user_after_insert
    after insert
    on role_user
    for each row
BEGIN
	CALL `fcUpdateUserPermission`(NEW.user_id);
END;

