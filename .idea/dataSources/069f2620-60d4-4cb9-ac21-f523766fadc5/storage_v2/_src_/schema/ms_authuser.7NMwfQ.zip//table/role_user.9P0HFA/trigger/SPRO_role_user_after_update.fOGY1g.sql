create definer = admin@`%` trigger SPRO_role_user_after_update
    after update
    on role_user
    for each row
BEGIN
	IF(OLD.user_id != NEW.user_id) THEN
		CALL `fcUpdateUserPermission`(OLD.user_id);
		CALL `fcUpdateUserPermission`(NEW.user_id);
	ELSE
		CALL `fcUpdateUserPermission`(OLD.user_id);
	END IF;
END;

