create definer = staging@`%` view VW_SPRO_ASSINATURAS_VENCIDAS as
select `TB1`.`ID_CLIENTE`                              AS `ID_CLIENTE`,
       `TB1`.`PF_PJ`                                   AS `PF_PJ`,
       `TB1`.`EMAIL`                                   AS `EMAIL`,
       `TB1`.`NOME_PRINCIPAL`                          AS `NOME_PRINCIPAL`,
       `TB1`.`DDD_CELULAR`                             AS `DDD_CELULAR`,
       `TB1`.`FONE_CELULAR`                            AS `FONE_CELULAR`,
       `TB1`.`DDD_RESID`                               AS `DDD_RESID`,
       `TB1`.`FONE_RESID`                              AS `FONE_RESID`,
       `TB1`.`DDD_CONTATO1`                            AS `DDD_CONTATO1`,
       `TB1`.`FONE_CONTATO1`                           AS `FONE_CONTATO1`,
       ifnull(`TB1`.`ID_AUTH_PERFIL`, 0)               AS `ID_AUTH_PERFIL`,
       if((`TB1`.`ID_AUTH_PERFIL` = 6), 'ESC', 'PROF') AS `PERFIL`,
       (select `TB3`.`VENCIMENTO`
        from `superpro`.`SPRO_CREDITO_CONSOLIDADO` `TB3`
        where ((`TB3`.`ID_CLIENTE` = `TB2`.`ID_CLIENTE`) and (ifnull(`TB2`.`BONUS`, 0) = 0) and
               (`TB3`.`NUM_PEDIDO` > 0))
        order by `TB3`.`VENCIMENTO` desc
        limit 1)                                       AS `MAX_VENCIMENTO`
from (`superpro`.`SPRO_CLIENTE` `TB1` join `superpro`.`SPRO_CREDITO_CONSOLIDADO` `TB2`
      on ((`TB1`.`ID_CLIENTE` = `TB2`.`ID_CLIENTE`)))
where (`TB1`.`EMAIL` in
       (select `superpro`.`SPRO_MAIL_BLK_LIST`.`EMAIL` from `superpro`.`SPRO_MAIL_BLK_LIST`) is false and
       (ifnull(`TB2`.`BONUS`, 0) = 0) and (`TB1`.`ID_AUTH_PERFIL` <> 7) and
       (not ((`TB1`.`EMAIL` like '%interbits%'))) and (not ((`TB1`.`EMAIL` like '%teste%'))) and
       (not ((`TB1`.`EMAIL` like '%supervip%'))) and (`TB2`.`NUM_PEDIDO` > 0) and (ifnull(`TB1`.`ID_MATRIZ`, 0) = 0))
group by `TB1`.`ID_CLIENTE`
having (`MAX_VENCIMENTO` < curdate())
order by (select `TB3`.`VENCIMENTO`
          from `superpro`.`SPRO_CREDITO_CONSOLIDADO` `TB3`
          where ((`TB3`.`ID_CLIENTE` = `TB2`.`ID_CLIENTE`) and (ifnull(`TB2`.`BONUS`, 0) = 0) and
                 (`TB3`.`NUM_PEDIDO` > 0))
          order by `TB3`.`VENCIMENTO` desc
          limit 1) desc;

