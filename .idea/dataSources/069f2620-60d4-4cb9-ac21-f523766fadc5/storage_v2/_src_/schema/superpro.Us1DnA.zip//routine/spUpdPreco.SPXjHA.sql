create
    definer = admin@`%` procedure spUpdPreco(IN $planoCreditos float, IN $novaCompraPrecoAV float,
                                             IN $novaCompraPrecoParc float, IN $renovaPrecoAV float,
                                             IN $renovaPrecoParc float)
BEGIN
	# Atualiza os preços do plano Escola informado ($planoCreditos)

	SET @idPrecoPlano = 0;
	SET @percentDesc = 0;
	SET @tipoPlano = 'AVULSO';

	IF ($planoCreditos = 0) THEN
		SET @tipoPlano = 'RVLD';
	END IF;
	
	# Localiza o registro a ser alterado
	SELECT ID_PRECO_PLANO INTO @idPrecoPlano 
	FROM SPRO_PRECO_PLANO 
	WHERE ID_PLANO_CONSUMO = 6 
	AND TIPO_PLANO = @tipoPlano
	AND TOTAL_CREDITO = $planoCreditos;

	IF (@idPrecoPlano > 0) THEN
		SELECT ROUND(100 - ($novaCompraPrecoAV/$novaCompraPrecoParc * 100)) INTO @percentDesc FROM DUAL;

		IF (@tipoPlano = 'AVULSO') THEN
				# Preços para nova compra e renovação de assinatura
				UPDATE SPRO_PRECO_PLANO 
				SET VALOR = $novaCompraPrecoParc, PERCENT_DESC_AV = @percentDesc, 
				VALOR_DESC_AV = $renovaPrecoAV, PRECO_CUPOM = $renovaPrecoParc
				WHERE ID_PRECO_PLANO = @idPrecoPlano;
		ELSE
				# Preços de Revalidação
				UPDATE SPRO_PRECO_PLANO 
				SET VALOR = $novaCompraPrecoParc, PERCENT_DESC_AV = @percentDesc, 
				VALOR_DESC_AV = $novaCompraPrecoAV
				WHERE ID_PRECO_PLANO = @idPrecoPlano;				
		END IF;
	END IF;
END;

