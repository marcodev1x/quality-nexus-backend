create definer = staging@`%` view SPRO_VW_USER as
select `TB1`.`ID_USER`              AS `ID_USER`,
       `TB3`.`PERMISSOES`           AS `PERMISSOES`,
       `TB3`.`NOME_PERMISSAO`       AS `NOME_PERMISSAO`,
       `TB1`.`ID_USER_PERFIL`       AS `ID_USER_PERFIL`,
       `TB1`.`ID_AUTH_FUNCAO`       AS `ID_AUTH_FUNCAO`,
       `TB1`.`HASH`                 AS `HASH`,
       `TB1`.`ID_CAMPANHA_ORIG_CAD` AS `ID_CAMPANHA_ORIG_CAD`,
       `TB1`.`ID_MATRIZ`            AS `ID_MATRIZ`,
       `TB1`.`NOME`                 AS `NOME`,
       `TB1`.`APELIDO`              AS `APELIDO`,
       `TB1`.`EMAIL`                AS `EMAIL`,
       `TB1`.`TIPO_FONE`            AS `TIPO_FONE`,
       `TB1`.`DDD_FONE`             AS `DDD_FONE`,
       `TB1`.`FONE`                 AS `FONE`,
       `TB1`.`LOGIN`                AS `LOGIN`,
       `TB1`.`GOOGLE_ID`            AS `GOOGLE_ID`,
       `TB1`.`FB_ID`                AS `FB_ID`,
       `TB1`.`PASSWD`               AS `PASSWD`,
       `TB1`.`BLOQUEADO_EM`         AS `BLOQUEADO_EM`,
       `TB1`.`EXCLUIDO_EM`          AS `EXCLUIDO_EM`,
       `TB1`.`DT_HR_UPD_PASSWD`     AS `DT_HR_UPD_PASSWD`,
       `TB1`.`DT_HR_ULTIMO_ACESSO`  AS `DT_HR_ULTIMO_ACESSO`,
       `TB1`.`DT_EMAIL_CONF`        AS `DT_EMAIL_CONF`,
       `TB1`.`DATA_REGISTRO`        AS `DATA_REGISTRO`,
       `TB2`.`CODIGO`               AS `CODIGO_PERFIL`,
       `TB2`.`PERFIL`               AS `PERFIL`,
       `TB1`.`STATUS_CAIXA_MSG`     AS `STATUS_CAIXA_MSG`
from ((`superpro`.`SPRO_USER` `TB1` join `superpro`.`SPRO_USER_PERFIL` `TB2`) left join `superpro`.`SPRO_USER_PERMISSAO` `TB3`
      on ((`TB3`.`ID_USER` = `TB1`.`ID_USER`)))
where (`TB1`.`ID_USER_PERFIL` = `TB2`.`ID_USER_PERFIL`);

