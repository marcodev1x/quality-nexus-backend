create
    definer = admin@`%` function fcNomeAbrvMes(numMes int) returns varchar(3)
BEGIN
	declare abrev varchar(3);

	case numMes
	when 1 then set abrev = 'Jan';
	when 2 then set abrev = 'Fev';
	when 3 then set abrev = 'Mar';
	when 4 then set abrev = 'Abr';
	when 5 then set abrev = 'Mai';
	when 6 then set abrev = 'Jun';
	when 7 then set abrev = 'Jul';
	when 8 then set abrev = 'Ago';
	when 9 then set abrev = 'Set';
	when 10 then set abrev = 'Out';
	when 11 then set abrev = 'Nov';
	when 12 then set abrev = 'Dez';
	end case;

return abrev;
END;

