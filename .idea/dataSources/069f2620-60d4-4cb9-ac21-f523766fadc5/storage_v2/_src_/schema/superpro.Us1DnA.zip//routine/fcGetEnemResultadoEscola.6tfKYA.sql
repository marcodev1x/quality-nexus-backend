create
    definer = admin@`%` function fcGetEnemResultadoEscola($idEscola int, $idProva int, $idQuestaoProva int) returns int
BEGIN
	#Routine body goes here...

	RETURN 0;
END;

