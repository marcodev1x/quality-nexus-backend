create
    definer = admin@`%` function fcTipoPedidoUltimoCompra(ID_USER_ int) returns char(20)
BEGIN
	# 09/06/2014
	# Identifica qual o tipo do pedido feito na última compra do ID_USER informado.
	#
	# Pode ser:
	# - NAO_ASSINANTE, caso o ID_USER informado não seja localizado como assinante, 
	# - NOVO, para primeira compra, 
	# - RENOV, para renovação e 
	# - RVLD, para revalidação. 
	#
	# @author Claudio Rubens Silva Filho

	# Carrega cadastro feito na campanha do Natal 2013 e que ainda não compraram.
	# Verifica se o e-mail não consta na lista de assinantes e se não está na lista negra.

	DECLARE RETORNO CHAR(20);
	DECLARE TOTAL_PEDIDOS INT;
	DECLARE TIPO_PLANO_ CHAR(12);

	SET RETORNO = 'NAO_ASSINANTE'; #Caso não localize uma compra, retorna que não é assinante.
	
	# Localiza o número de pedidos válidos do usuário atual, cujo vencimento é maior igual a hoje.
	SELECT COUNT(*) INTO TOTAL_PEDIDOS FROM SPRO_CREDITO_CONSOLIDADO 
	WHERE ID_CLIENTE = ID_USER_ AND NUM_PEDIDO > 0 AND VENCIMENTO >= DATE(NOW()) AND CREDITO > 0 AND IFNULL(BONUS,0) = 0;

	IF (TOTAL_PEDIDOS > 0) THEN
		# Localizou um ou mais pedidos válidos.
		IF (TOTAL_PEDIDOS = 1) THEN
			# Localizado um único pedido. Portanto, trata-se de primeira compra.
			SET RETORNO = 'NOVO';
		ELSE
			# Há mais de um pedido válido. Verifica se a última compra é um pedido de revalidação.
			SELECT (SELECT TIPO_PLANO FROM SPRO_PRECO_PLANO TB WHERE TB.ID_PRECO_PLANO = TB1.ID_PLANO) INTO TIPO_PLANO_ 
			FROM SPRO_ECOMM_PEDIDO TB1 INNER JOIN SPRO_CREDITO_CONSOLIDADO TB2 
			ON TB1.NUM_PEDIDO = TB2.NUM_PEDIDO AND TB2.NUM_PEDIDO > 0 AND TB2.ID_CLIENTE = ID_USER_
			AND TB2.VENCIMENTO >= DATE(NOW()) AND TB2.CREDITO > 0 AND IFNULL(TB2.BONUS,0) = 0
			ORDER BY TB2.NUM_PEDIDO DESC LIMIT 1;

			IF (TIPO_PLANO_ = 'RVLD') THEN
				SET RETORNO = 'RVLD';
			ELSE 
				SET RETORNO = 'RENOV';
			END IF;			
		END IF;
	END IF;
	RETURN RETORNO;

END;

