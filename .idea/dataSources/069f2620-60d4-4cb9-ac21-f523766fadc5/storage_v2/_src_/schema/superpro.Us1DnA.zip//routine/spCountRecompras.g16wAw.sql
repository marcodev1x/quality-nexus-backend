create
    definer = admin@`%` procedure spCountRecompras(IN ano int, IN mes_ini int, IN mes_fim int, IN periodo varchar(10),
                                                   IN prazo int, IN creditos int)
BEGIN
	
declare cliente, pedido int;
declare data_ini, data_fim date;
declare fim int default 0;
	

declare c cursor for	
SELECT sep.ID_CLIENTE, sep.NUM_PEDIDO, date(scc.DATA_REGISTRO), scc.VENCIMENTO  
from SPRO_CREDITO_CONSOLIDADO scc
join SPRO_VW_CLIENTE_VALIDO sc
  	on sc.ID_CLIENTE = scc.ID_CLIENTE
join SPRO_ECOMM_PEDIDO sep
  	on sep.NUM_PEDIDO = scc.NUM_PEDIDO
left join SPRO_AUTH_PERFIL sap 
 	on sap.ID_AUTH_PERFIL = sc.ID_AUTH_PERFIL 
left join SPRO_VW_PRECO_PLANO svpp
	on svpp.ID_PRECO_PLANO = sep.ID_PLANO
where sep.ID_STATUS_LOJA = 1
  and sep.NUM_PEDIDO_PAI is null
  and scc.OPERACAO = 'C'
  and (sep.ID_TIPO_LANCAMENTO = 7 or sep.ID_TIPO_LANCAMENTO is null)
  and svpp.CODIGO_PLANO = 'PRO'
  and sep.VALIDADE_CREDITOS = prazo 
  and sep.CREDITOS = creditos
  and sep.DATA_REGISTRO BETWEEN CONCAT(ano,'-',mes_ini,'-01') and CONCAT(LAST_DAY(CONCAT(ano,'-',mes_fim,'-01')),' 23:59:59');
 
declare continue handler for not found set fim = 1;
	
if fim = 0 then 
	open c;

	recompras: loop 
	
		IF fim = 1 THEN 
			LEAVE recompras;
		END IF;	
		
		fetch c into cliente, pedido, data_ini, data_fim;
	
		INSERT into SPRO_RECOMPRAS (ID_CLIENTE, MESES, CREDITOS, PEDIDO, COMBO_ANALISADO, PERIODO)
		SELECT sep2.ID_CLIENTE, sep2.VALIDADE_CREDITOS, sep2.CREDITOS, sep2.NUM_PEDIDO, CONCAT(prazo," m ", creditos, " c"), periodo 
		from SPRO_ECOMM_PEDIDO sep2 
		join SPRO_CREDITO_CONSOLIDADO scc2 
		on scc2.NUM_PEDIDO = sep2.NUM_PEDIDO 
		where sep2.ID_STATUS_LOJA = 1
		and scc2.OPERACAO = 'C'
		and sep2.NUM_PEDIDO_PAI is null
		and sep2.ID_CLIENTE = cliente 
		and sep2.NUM_PEDIDO <> pedido
		and date(sep2.DATA_REGISTRO) >= data_ini 
		and date(sep2.DATA_REGISTRO) <= data_fim
		and sep2.DATA_REGISTRO BETWEEN CONCAT(ano,'-',mes_ini,'-01') and CONCAT(LAST_DAY(CONCAT(ano,'-',mes_fim,'-01')),' 23:59:59');

	end loop recompras;

	close c;

end if;
	
END;

