create
    definer = admin@`%` function fcCalcSaldoProfEsc(idUser int, dataVencEnMatriz datetime) returns int
BEGIN
	#Routine body goes here...
	DECLARE saldoAtual, saldoInicial, idPerfil INT default 0;
	DECLARE dataIni, historicoApartirDe TIMESTAMP;

	IF (dataVencEnMatriz IS NULL OR dataVencEnMatriz < CURDATE() = 1) THEN
		#Matriz com assinatura vencida
		RETURN 0;
	END IF;


	# Localiza a data inicial da assinatura da escola, caso seja diferente da do professor:
	SELECT MAX(HISTORICO_APARTIR_DE) INTO historicoApartirDe
	FROM SPRO_CREDITO_CONSOLIDADO 
	WHERE ID_CLIENTE = (SELECT ID_MATRIZ FROM SPRO_CLIENTE WHERE ID_CLIENTE = idUser)
	AND HISTORICO_APARTIR_DE != '0000-00-00 00:00:00';

	IF (historicoApartirDe IS NOT NULL) THEN
		SELECT SALDO_ANT, DATA_REGISTRO INTO saldoInicial, dataIni FROM SPRO_CREDITO_CONSOLIDADO 
		WHERE ID_CLIENTE = idUser AND DATA_REGISTRO > historicoApartirDe
		ORDER BY DATA_REGISTRO DESC LIMIT 1;

		IF (saldoInicial IS NULL) THEN
			SET saldoInicial = 0;
		END IF;

		IF (dataIni IS NULL) THEN
			SET dataIni = historicoApartirDe;
		END IF;
	ELSE 
		SELECT SALDO_ANT, DATA_REGISTRO INTO saldoInicial, dataIni FROM SPRO_CREDITO_CONSOLIDADO 
		WHERE ID_CLIENTE = idUser
		ORDER BY DATA_REGISTRO DESC LIMIT 1;
	END IF;

	# Localiza o perfil do usuário
	SELECT ID_AUTH_PERFIL INTO idPerfil FROM SPRO_CLIENTE WHERE ID_CLIENTE = idUser;

	IF (saldoInicial >= 0 AND dataIni IS NOT NULL) THEN 
			IF (idPerfil = 6) THEN
				# Conta Escola
				SELECT
					(IFNULL(VALOR,0) + saldoInicial) INTO saldoAtual
				FROM (
								# Subselect que soma entrada e saída de créditos a partir da data informada
								SELECT
									SUM(
										IF (
											OPERACAO = 'C',
											CREDITO,
											(- 1) * CREDITO
										)
									) AS VALOR
								FROM
									SPRO_CREDITO_CONSOLIDADO
								WHERE
									ID_CLIENTE = idUser
								AND DATA_REGISTRO >= dataIni
								GROUP BY
									ID_CLIENTE
					) AS TB_TEMP;	
			ELSE 
				# Conta Professor
				# Soma o saldo inicial + entradas - saídas - consumo de crédito
				SELECT
					(IFNULL(VALOR,0) + saldoInicial) - (
						(
							SELECT
								IFNULL(SUM(DEBITO),0)
							FROM
								SPRO_HISTORICO_GERADOC
							WHERE
								ID_LOGIN = idUser
							AND DATA_REGISTRO >= dataIni
						)
					) INTO saldoAtual
				FROM (
								# Subselect que soma entrada e saída de créditos a partir da data informada
								SELECT
									SUM(
										IF (
											OPERACAO = 'C',
											CREDITO,
											(- 1) * CREDITO
										)
									) AS VALOR
								FROM
									SPRO_CREDITO_CONSOLIDADO
								WHERE
									ID_CLIENTE = idUser
								AND DATA_REGISTRO >= dataIni
								GROUP BY
									ID_CLIENTE
					) AS TB_TEMP;	
			END IF;
	END IF;

	IF saldoAtual IS NULL THEN
		SET saldoAtual = 0;
	END IF;

	RETURN saldoAtual;
END;

