create definer = admin@`%` trigger limparQueueOnUpdate
    after update
    on SPRO_SML_ESCOLA_ADESAO
    for each row
BEGIN
     IF (NEW.ID_ESCOLA_EVOLUCIONAL > 0 && NEW.SCHOOLCODE > 0) THEN
             
             DELETE FROM SPRO_SML_QUEUE WHERE ID_CLIENTE = NEW.ID_CLIENTE AND TIPO = 'CAD_ESC';
     END IF;
END;

