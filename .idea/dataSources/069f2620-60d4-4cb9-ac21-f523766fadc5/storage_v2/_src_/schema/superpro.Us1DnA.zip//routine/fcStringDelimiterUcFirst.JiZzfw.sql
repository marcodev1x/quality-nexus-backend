create
    definer = admin@`%` function fcStringDelimiterUcFirst(oldName varchar(255), delim varchar(3), trimSpaces int) returns varchar(255)
BEGIN
  SET @oldString = oldName;
  SET @newString = "";

  tokenLoop: LOOP
    IF trimSpaces = 1 THEN SET @oldString = TRIM(BOTH " " FROM @oldString); END IF;

    SET @splitPoint = LOCATE(delim, @oldString);

    IF @splitPoint = 0 THEN
      SET @newString = CONCAT(@newString, fcStringUcFirst(@oldString));
      LEAVE tokenLoop;
    END IF;

    SET @newString = CONCAT(@newString, fcStringUcFirst(SUBSTRING(@oldString, 1, @splitPoint)));
    SET @oldString = SUBSTRING(@oldString, @splitPoint+1);
  END LOOP tokenLoop;

  RETURN @newString;
END;

