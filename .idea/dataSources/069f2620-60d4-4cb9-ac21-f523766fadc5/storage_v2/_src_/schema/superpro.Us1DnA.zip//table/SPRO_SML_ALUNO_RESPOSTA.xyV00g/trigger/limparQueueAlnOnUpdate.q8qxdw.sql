create definer = admin@`%` trigger limparQueueAlnOnUpdate
    after update
    on SPRO_SML_ALUNO_RESPOSTA
    for each row
BEGIN
     IF (NEW.ID_ALUNO_EVOLUCIONAL > 0) THEN
             
             DELETE FROM SPRO_SML_QUEUE WHERE ID_CLIENTE = NEW.ID_ALUNO_SUPERPRO AND TIPO = 'CAD_ALUNO';
     END IF;
END;

