create
    definer = admin@`%` function fcLocalizarMateriasApartirDoDoc(ID_HISTORICO_GERADOC_ int) returns varchar(100)
BEGIN
	# 29/08/2016
	# Localiza as matérias utilizadas em um documento.	
	#
	# @author Claudio Rubens Silva Filho
	DECLARE RESULT VARCHAR(100);
	
	SET @idHistGeraDocLido := 0, @idLogin := 0, @totalQuestoes := 0;

	# Verifica se o doc atual já foi lido
	SELECT ID_HISTORICO_GERADOC INTO @idHistGeraDocLido FROM SPRO_USER_REL_MATERIA_DOC_HIST 
	WHERE ID_HISTORICO_GERADOC = ID_HISTORICO_GERADOC_;

	# Localiza o ID/Login do usuário
	SELECT ID_LOGIN INTO @idLogin FROM SPRO_HISTORICO_GERADOC WHERE ID_HISTORICO_GERADOC = ID_HISTORICO_GERADOC_;

	IF ((@idHistGeraDocLido = 0 OR @idHistGeraDocLido IS NULL) AND @idLogin > 0) THEN
			INSERT INTO SPRO_USER_REL_MATERIA_DOC (ID_USER, ID_MATERIA, TOTAL_Q, DATA_REGISTRO) (
				#SELECT * FROM (
					SELECT @idLogin , ID_MATERIA, @totalQuestoes := COUNT(*), NOW()
					FROM SPRO_BCO_QUESTAO_MEMORY 
					WHERE ID_BCO_QUESTAO IN (
						SELECT ITENS_SELECIONADOS FROM SPRO_HISTORICO_GERADOC WHERE ID_HISTORICO_GERADOC = ID_HISTORICO_GERADOC_
					) GROUP BY ID_MATERIA
				#) TMP
			)  ON DUPLICATE KEY UPDATE TOTAL_Q = TOTAL_Q + @totalQuestoes;

			# Guarda o IDGeraDoc atual para evitar que seja lido duas vezes
			#REPLACE INTO SPRO_USER_REL_MATERIA_DOC_HIST (ID_HISTORICO_GERADOC, DATA_REGISTRO) 
			#VALUES (ID_HISTORICO_GERADOC_, NOW());

			# Localiza as matérias do usuário atual
			SELECT GROUP_CONCAT(ID_MATERIA,'=',TOTAL_Q) INTO RESULT FROM SPRO_USER_REL_MATERIA_DOC WHERE ID_USER = @idLogin;
	ELSE 
			SET RESULT = 'O doc informado já foi lido.';
	END IF;
	# Limpa a tabela de ajuda usada na function atual
	#DELETE FROM SPRO_USER_REL_MATERIA_HELP WHERE ID_USER = ID_USER_;
	# Retorna uma string no formato {ID_MATERIA}=x,{ID_MATERIA}=y...
	# Onde x é o total de questões encontradas em cada matéria.
	RETURN RESULT;
END;

