create definer = staging@`%` view VwAdminDadosGeograficos as
select `TB1`.`UF`                                                                                       AS `UF`,
       `TB1`.`CIDADE`                                                                                   AS `CIDADE`,
       (select `superpro`.`TB4`.`REGIAO`
        from `superpro`.`VW_SPRO_UF` `TB4`
        where (convert(`superpro`.`TB4`.`SIGLA` using utf8mb3) = `TB1`.`UF`))                           AS `REGIAO`,
       count(1)                                                                                         AS `TOTAL_USUARIOS`,
       ((count(1) / (select count(1)
                     from `superpro`.`SPRO_CLIENTE` `TB3`
                     where ((`TB3`.`ID_AUTH_PERFIL` <> 7) and (`TB3`.`ID_MATRIZ` = 0) and ((select count(1)
                                                                                            from `superpro`.`SPRO_CREDITO_CONSOLIDADO` `TB2`
                                                                                            where (`TB2`.`ID_CLIENTE` = `TB3`.`ID_CLIENTE`)) >
                                                                                           0)))) * 100) AS `PERCENT`
from `superpro`.`SPRO_CLIENTE` `TB1`
where ((`TB1`.`ID_AUTH_PERFIL` <> 7) and (`TB1`.`ID_MATRIZ` = 0) and ((select count(1)
                                                                       from `superpro`.`SPRO_CREDITO_CONSOLIDADO` `TB2`
                                                                       where (`TB2`.`ID_CLIENTE` = `TB1`.`ID_CLIENTE`)) >
                                                                      0))
group by `TB1`.`UF`, `TB1`.`CIDADE`
order by `TOTAL_USUARIOS` desc;

