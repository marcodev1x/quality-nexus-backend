create definer = powerbi@`%` view VW_PBI_FATO_CONSUMO as
select `cre`.`ID_CONSUMO_CREDITO` AS `ID_CONSUMO_CREDITO`,
       `cre`.`ID_CLIENTE`         AS `ID_CLIENTE`,
       `cre`.`DEBITO`             AS `CREDITOS CONSUMIDOS`,
       `cre`.`ID_HIST_GERADOC`    AS `ID_GERADOC`,
       `cre`.`DATA_REGISTRO`      AS `DATA_REGISTRO`
from (`superpro`.`SPRO_CONSUMO_CREDITO` `cre` join `superpro`.`SPRO_VW_CLIENTE_VALIDO` `sc`
      on ((`superpro`.`sc`.`ID_CLIENTE` = `cre`.`ID_CLIENTE`)))
where (`cre`.`DATA_REGISTRO` >= '2018-01-01 00:00:00');

