create definer = staging@`%` view VW_SPRO_LISTA_EXERCICIOS as
select (select count(0) AS `COUNT(*)`
        from `superpro`.`SPRO_LST_USUARIO` `TB`
        where (`TB`.`ID_HISTORICO_GERADOC` = `superpro`.`SPRO_HISTORICO_GERADOC`.`ID_HISTORICO_GERADOC`))  AS `USUARIOS`,
       (select count(distinct `TB1`.`ID_LST_USUARIO`) AS `COUNT(DISTINCT TB1.ID_LST_USUARIO)`
        from (`superpro`.`SPRO_LST_HIST_RESPOSTA` `TB1` join `superpro`.`SPRO_LST_USUARIO` `TB2`
              on ((`TB1`.`ID_LST_USUARIO` = `TB2`.`ID_LST_USUARIO`)))
        where (`TB2`.`ID_HISTORICO_GERADOC` =
               `superpro`.`SPRO_HISTORICO_GERADOC`.`ID_HISTORICO_GERADOC`))                                AS `USUARIOS_RESP`,
       `superpro`.`SPRO_HISTORICO_GERADOC`.`ID_HISTORICO_GERADOC`                                          AS `ID_HISTORICO_GERADOC`,
       `superpro`.`SPRO_HISTORICO_GERADOC`.`COD_LISTA`                                                     AS `COD_LISTA`,
       `superpro`.`SPRO_HISTORICO_GERADOC`.`LISTA_ATIVA`                                                   AS `LISTA_ATIVA`,
       `superpro`.`SPRO_HISTORICO_GERADOC`.`VER_IMPRESSA`                                                  AS `VER_IMPRESSA`,
       `superpro`.`SPRO_HISTORICO_GERADOC`.`ID_LOGIN`                                                      AS `ID_LOGIN`,
       `superpro`.`SPRO_HISTORICO_GERADOC`.`ID_LST_GRUPO`                                                  AS `ID_LST_GRUPO`,
       `superpro`.`SPRO_HISTORICO_GERADOC`.`TIPO`                                                          AS `TIPO`,
       `superpro`.`SPRO_HISTORICO_GERADOC`.`FORMATO`                                                       AS `FORMATO`,
       `superpro`.`SPRO_HISTORICO_GERADOC`.`GERA_DEBITO`                                                   AS `GERA_DEBITO`,
       `superpro`.`SPRO_HISTORICO_GERADOC`.`SUFIXO`                                                        AS `SUFIXO`,
       `superpro`.`SPRO_HISTORICO_GERADOC`.`NOME_ARQ`                                                      AS `NOME_ARQ`,
       `superpro`.`SPRO_HISTORICO_GERADOC`.`DESCR_ARQ`                                                     AS `DESCR_ARQ`,
       `superpro`.`SPRO_HISTORICO_GERADOC`.`DEBITO`                                                        AS `DEBITO`,
       `superpro`.`SPRO_HISTORICO_GERADOC`.`ITENS_SELECIONADOS`                                            AS `ITENS_SELECIONADOS`,
       `superpro`.`SPRO_HISTORICO_GERADOC`.`NUM_DOWNLOAD`                                                  AS `NUM_DOWNLOAD`,
       `superpro`.`SPRO_HISTORICO_GERADOC`.`DATA_REGISTRO`                                                 AS `DATA_REGISTRO`,
       `superpro`.`SPRO_HISTORICO_GERADOC`.`TEMPO_LEITURA_SEC`                                             AS `TEMPO_LEITURA_SEC`,
       `superpro`.`SPRO_HISTORICO_GERADOC`.`TEMPO_LEITURA_STR`                                             AS `TEMPO_LEITURA_STR`,
       `superpro`.`SPRO_HISTORICO_GERADOC`.`TEMPO_RESPOSTA_SEC`                                            AS `TEMPO_RESPOSTA_SEC`,
       `superpro`.`SPRO_HISTORICO_GERADOC`.`TEMPO_RESPOSTA_STR`                                            AS `TEMPO_RESPOSTA_STR`,
       `superpro`.`SPRO_HISTORICO_GERADOC`.`DT_HR_VALIDADE`                                                AS `DT_HR_VALIDADE`,
       `superpro`.`SPRO_HISTORICO_GERADOC`.`FLAG`                                                          AS `FLAG`,
       ifnull(`superpro`.`SPRO_CLIENTE`.`ID_MATRIZ`, 0)                                                    AS `ID_MATRIZ`,
       ifnull(`superpro`.`SPRO_CLIENTE`.`ID_FILIAL`, 0)                                                    AS `ID_FILIAL`,
       `superpro`.`SPRO_CLIENTE`.`NOME_PRINCIPAL`                                                          AS `NOME_PRINCIPAL`,
       `superpro`.`SPRO_CLIENTE`.`APELIDO`                                                                 AS `APELIDO`,
       `superpro`.`SPRO_CLIENTE`.`EMAIL`                                                                   AS `EMAIL`
from (`superpro`.`SPRO_HISTORICO_GERADOC` join `superpro`.`SPRO_CLIENTE`
      on ((`superpro`.`SPRO_CLIENTE`.`ID_CLIENTE` = `superpro`.`SPRO_HISTORICO_GERADOC`.`ID_LOGIN`)))
where ((`superpro`.`SPRO_HISTORICO_GERADOC`.`FORMATO` = 'LST') and
       (`superpro`.`SPRO_HISTORICO_GERADOC`.`COD_LISTA` is not null) and
       (`superpro`.`SPRO_HISTORICO_GERADOC`.`COD_LISTA` > '0') and
       (not ((`superpro`.`SPRO_CLIENTE`.`EMAIL` like '%supervip%'))) and
       (not ((`superpro`.`SPRO_CLIENTE`.`EMAIL` like '%interbits%'))));

