create
    definer = admin@`%` function fcSomaConsumoNoPeriodo(idMatriz int, dataIni datetime, dataFim datetime) returns int
BEGIN	
	# Calcula o total de créditos consumidos no período informado.
	# Criado em 05/01/2017
	# @authour Claudio Rubens Silva Filho
	# @return int total de créditos consumidos

	SET @listId_nivel1 := '';
	SET @listId_nivel2 := '';
	SET @debito_nivel1 := 0;
	SET @debito_nivel2 := 0;

	SET @debito := 0;
	SET @ret = '';
	IF (idMatriz > 0) THEN
		IF (LENGTH(dataFim) = 0 OR dataFim = '0000-00-00 00:00:00') THEN
			SET dataFim = NOW();
		END IF;

		SELECT GROUP_CONCAT(ID_CLIENTE) INTO @listId_nivel1 FROM SPRO_CLIENTE WHERE ID_MATRIZ = idMatriz;
		
		IF (LENGTH(@listId_nivel1) > 0) THEN
			# Soma os débitos do nível 1
			SELECT SUM(DEBITO) INTO @debito_nivel1 FROM SPRO_HISTORICO_GERADOC WHERE ID_LOGIN IN (@listId_nivel1) 
			AND DATA_REGISTRO >= dataIni AND DATA_REGISTRO <= dataFim;		
			
			# Verifica se há dependentes da lista atual
			SELECT GROUP_CONCAT(ID_CLIENTE) INTO @listId_nivel2 FROM SPRO_CLIENTE WHERE ID_MATRIZ IN (
					SELECT ID_CLIENTE FROM SPRO_CLIENTE WHERE ID_MATRIZ = idMatriz
			);

			IF (LENGTH(@listId_nivel2) > 0) THEN
				# O idMatriz informado é uma mantenedora						
				SELECT SUM(DEBITO) INTO @debito_nivel2 FROM SPRO_HISTORICO_GERADOC WHERE ID_LOGIN IN (
					SELECT ID_CLIENTE FROM SPRO_CLIENTE WHERE ID_MATRIZ IN (
						SELECT ID_CLIENTE FROM SPRO_CLIENTE WHERE ID_MATRIZ = idMatriz
					)
				) 
				AND DATA_REGISTRO >= dataIni AND DATA_REGISTRO <= dataFim;			
			END IF;
		END IF;
	END IF;

	SET @debito = IFNULL(@debito_nivel1,0) + IFNULL(@debito_nivel2,0);
	
	RETURN @debito;
END;

