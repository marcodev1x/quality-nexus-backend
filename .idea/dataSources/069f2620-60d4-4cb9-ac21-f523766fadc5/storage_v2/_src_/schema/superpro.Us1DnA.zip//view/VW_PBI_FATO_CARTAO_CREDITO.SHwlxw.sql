create definer = admin@`%` view VW_PBI_FATO_CARTAO_CREDITO as
select `sep`.`NUM_PEDIDO`                                                                              AS `NUMERO_PEDIDO`,
       `sep`.`NUM_PEDIDO_PAI`                                                                          AS `PEDIDO_PAI`,
       `sep`.`ID_CLIENTE`                                                                              AS `ID_CLIENTE`,
       `sep`.`ID_PLANO`                                                                                AS `ID_PLANO`,
       `spc`.`ID_PLANO_CONSUMO`                                                                        AS `ID_PLANO_CONSUMO`,
       coalesce(concat(`spc`.`CODIGO_PLANO`, ' ', `sep`.`CREDITOS`), 0)                                AS `PLANO`,
       `sep`.`VALOR_TOTAL`                                                                             AS `VALOR_PEDIDO`,
       `sep`.`VALOR_ADM`                                                                               AS `VALOR_ADM`,
       `sep`.`VALOR_PARCELA`                                                                           AS `VALOR_PARCELA`,
       `sep`.`PARCELAS`                                                                                AS `PARCELAS`,
       (case
            when regexp_like(`sep`.`DESCR_PRODUTO`, 'parcela 01|parcela 1 de') then 'PARC'
            else `sep`.`FORMA_PGTO` end)                                                               AS `FORMA_PAGAMENTO`,
       `sep`.`ID_MEIO_PGTO`                                                                            AS `ID_MEIO_PGTO`,
       `sep`.`ID_STATUS_LOJA`                                                                          AS `ID_STATUS_LOJA`,
       `sep`.`DATA_REGISTRO`                                                                           AS `DATA_REGISTRO`,
       cast(`sep`.`DATA_REGISTRO` as date)                                                             AS `DATA_PEDIDO`,
       date_format(`sep`.`DATA_REGISTRO`, '%Y%m%d')                                                    AS `ID_DATA`,
       hour(`sep`.`DATA_REGISTRO`)                                                                     AS `ID_HORA`,
       (case
            when (`sep`.`ID_STATUS_LOJA` = 1) then cast(`sep`.`DATA_REGISTRO` as date)
            else NULL end)                                                                             AS `DATA_PAGAMENTO`
from (((`superpro`.`SPRO_ECOMM_PEDIDO` `sep` join `superpro`.`SPRO_VW_CLIENTE_VALIDO` `vcv`
        on ((`superpro`.`vcv`.`ID_CLIENTE` = `sep`.`ID_CLIENTE`))) left join `superpro`.`SPRO_PRECO_PLANO` `spp`
       on ((`spp`.`ID_PRECO_PLANO` = `sep`.`ID_PLANO`))) left join `superpro`.`SPRO_PLANO_CONSUMO` `spc`
      on ((`spc`.`ID_PLANO_CONSUMO` = `spp`.`ID_PLANO_CONSUMO`)))
where ((`sep`.`ID_MEIO_PGTO` in (2, 3, 4, 5, 9, 15, 16, 17)) and (cast(`sep`.`DATA_REGISTRO` as date) >= '2018-01-01'));

