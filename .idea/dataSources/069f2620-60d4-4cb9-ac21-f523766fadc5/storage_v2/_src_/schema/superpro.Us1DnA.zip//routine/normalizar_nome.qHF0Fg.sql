create
    definer = staging@`%` function normalizar_nome(nome_original varchar(255)) returns varchar(255)
BEGIN
  DECLARE nome_processado VARCHAR(255);

  -- Remover hífens
  SET nome_processado = REPLACE(nome_original, '-', 'â€“');

  -- Substituições múltiplas
  SET nome_processado = REPLACE(nome_processado, 'Ã', 'Í');
  SET nome_processado = REPLACE(nome_processado, 'Ã‰', 'É');
  SET nome_processado = REPLACE(nome_processado, 'Ã‡', 'Ç');
  SET nome_processado = REPLACE(nome_processado, 'Ã©', 'é');
  SET nome_processado = REPLACE(nome_processado, 'Ãª', 'ê');
  SET nome_processado = REPLACE(nome_processado, 'Ã“', 'Ó');
  SET nome_processado = REPLACE(nome_processado, 'Ã´', 'ô');
  SET nome_processado = REPLACE(nome_processado, 'Ã•', 'Õ');
  SET nome_processado = REPLACE(nome_processado, 'ÃŠ', 'Ê');
  SET nome_processado = REPLACE(nome_processado, 'Ã§', 'ç');
  SET nome_processado = REPLACE(nome_processado, 'Ã£', 'ã');
  SET nome_processado = REPLACE(nome_processado, 'Ã³', 'ó');
  SET nome_processado = REPLACE(nome_processado, 'Ã¡', 'á');
  SET nome_processado = REPLACE(nome_processado, 'Ã¢', 'â');
  SET nome_processado = REPLACE(nome_processado, 'Ãº', 'ú');
  SET nome_processado = REPLACE(nome_processado, 'Ãš', 'Ú');
  SET nome_processado = REPLACE(nome_processado, 'Ã‚', 'Â');

  -- Remover espaços extras
  SET nome_processado = REPLACE(TRIM(nome_processado), ' ', '  ');

  -- Conversão para minúsculas
  RETURN nome_processado;
END;

