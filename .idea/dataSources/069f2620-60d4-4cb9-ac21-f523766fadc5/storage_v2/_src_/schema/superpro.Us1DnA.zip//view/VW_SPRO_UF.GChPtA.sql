create definer = admin@`%` view VW_SPRO_UF as
select `superpro`.`SPRO_UF`.`ID_UF`       AS `ID_UF`,
       `superpro`.`SPRO_UF`.`SIGLA`       AS `SIGLA`,
       `superpro`.`SPRO_UF`.`ID_REGIAO`   AS `ID_REGIAO`,
       `superpro`.`SPRO_REGIAO`.`REGIAO`  AS `REGIAO`,
       `superpro`.`SPRO_UF`.`NOME_ESTADO` AS `NOME_ESTADO`
from (`superpro`.`SPRO_UF` join `superpro`.`SPRO_REGIAO`
      on ((`superpro`.`SPRO_REGIAO`.`ID_REGIAO` = `superpro`.`SPRO_UF`.`ID_REGIAO`)));

