create definer = admin@`%` trigger ecomm_BEFORE_INSERT
    before insert
    on SPRO_ECOMM_PEDIDO
    for each row
BEGIN
	SET NEW.UUID_PEDIDO = uuid();
	IF (NEW.DATA_VENC_BOLETO = '0000-00-00') THEN
		SET NEW.DATA_VENC_BOLETO = NULL;
	END IF;

	IF (NEW.DATA_PGTO = '0000-00-00') THEN
		SET NEW.DATA_PGTO = NULL;
	END IF;
END;

