create definer = admin@`%` view VW_SPRO_BCO_QUESTAO as
select `superpro`.`SPRO_BCO_QUESTAO`.`ID_BCO_QUESTAO`                                    AS `ID_BCO_QUESTAO`,
       `superpro`.`SPRO_BCO_QUESTAO`.`ID_CLIENTE`                                        AS `ID_CLIENTE`,
       `superpro`.`SPRO_BCO_QUESTAO`.`ID_TIPO_QUESTAO`                                   AS `ID_TIPO_QUESTAO`,
       `superpro`.`SPRO_BCO_QUESTAO`.`ID_TEXTO`                                          AS `ID_TEXTO`,
       `superpro`.`SPRO_BCO_QUESTAO`.`ID_GRAU_DIFICULDADE`                               AS `ID_GRAU_DIFICULDADE`,
       `superpro`.`SPRO_BCO_QUESTAO`.`ID_FONTE_VESTIBULAR`                               AS `ID_FONTE_VESTIBULAR`,
       `superpro`.`SPRO_BCO_QUESTAO`.`ID_STATUS_QUESTAO`                                 AS `ID_STATUS_QUESTAO`,
       `superpro`.`SPRO_BCO_QUESTAO`.`ID_AUTH_USUARIO`                                   AS `ID_AUTH_USUARIO`,
       `superpro`.`SPRO_BCO_QUESTAO`.`ID_AUTH_COLABORADOR`                               AS `ID_AUTH_COLABORADOR`,
       `superpro`.`SPRO_BCO_QUESTAO`.`ENUNCIADO`                                         AS `ENUNCIADO`,
       `superpro`.`SPRO_BCO_QUESTAO`.`RESOLUCAO`                                         AS `RESOLUCAO`,
       `superpro`.`SPRO_BCO_QUESTAO`.`FIG`                                               AS `FIG`,
       `superpro`.`SPRO_BCO_QUESTAO`.`FIGR`                                              AS `FIGR`,
       `superpro`.`SPRO_BCO_QUESTAO`.`ANO`                                               AS `ANO`,
       `superpro`.`SPRO_BCO_QUESTAO`.`BLOQ_EDIT`                                         AS `BLOQ_EDIT`,
       `superpro`.`SPRO_BCO_QUESTAO`.`DATA_REGISTRO`                                     AS `DATA_REGISTRO`,
       `superpro`.`SPRO_BCO_QUESTAO`.`DATA_PUB`                                          AS `DATA_PUB`,
       date_format(`superpro`.`SPRO_BCO_QUESTAO`.`DATA_PUB`, '%d/%m/%Y')                 AS `DATA_PUB_BR`,
       `superpro`.`SPRO_TEXTO`.`TITULO`                                                  AS `TITULO`,
       `superpro`.`SPRO_FONTE_VESTIBULAR`.`FONTE_VESTIBULAR`                             AS `FONTE_VESTIBULAR`,
       `superpro`.`SPRO_FONTE_VESTIBULAR`.`ID_UF`                                        AS `ID_UF`,
       `superpro`.`SPRO_UF`.`SIGLA`                                                      AS `SIGLA`,
       `superpro`.`SPRO_UF`.`NOME_ESTADO`                                                AS `NOME_ESTADO`,
       `superpro`.`SPRO_REGIAO`.`REGIAO`                                                 AS `REGIAO`,
       `superpro`.`SPRO_GRAU_DIFICULDADE`.`GRAU_DIFICULDADE`                             AS `GRAU_DIFICULDADE`,
       `superpro`.`SPRO_AUTH_USUARIO`.`NOME`                                             AS `COLABORADOR`,
       `superpro`.`SPRO_TIPO_QUESTAO`.`TIPO_QUESTAO`                                     AS `TIPO_QUESTAO`,
       if((`superpro`.`SPRO_FONTE_VESTIBULAR`.`FONTE_VESTIBULAR` like '%G1%'), 'F', 'M') AS `ENSINO`,
       `superpro`.`SPRO_BCO_QUESTAO`.`AVALIACAO_NUM_VOTOS`                               AS `AVALIACAO_NUM_VOTOS`,
       `superpro`.`SPRO_BCO_QUESTAO`.`AVALIACAO_NUM_PONTOS`                              AS `AVALIACAO_NUM_PONTOS`,
       `superpro`.`SPRO_BCO_QUESTAO`.`TOTAL_USO`                                         AS `TOTAL_USO`,
       `superpro`.`SPRO_BCO_QUESTAO`.`DATA_HR_USO_ULTIMA_VEZ`                            AS `DATA_HR_USO_ULTIMA_VEZ`,
       `superpro`.`SPRO_BCO_QUESTAO`.`TEXTO_QUESTAO`                                     AS `TEXTO_QUESTAO`,
       `superpro`.`SPRO_BCO_QUESTAO`.`DATA_HR_ULT_EDICAO`                                AS `DATA_HR_ULT_EDICAO`,
       `superpro`.`SPRO_TIPO_QUESTAO`.`PREFIXO_TIPO`                                     AS `PREFIXO_TIPO`,
       `superpro`.`SPRO_BCO_QUESTAO`.`GABARITO`                                          AS `GABARITO`,
       `superpro`.`SPRO_BCO_QUESTAO`.`ING_ENUN_PT`                                       AS `ING_ENUN_PT`
from (((((((`superpro`.`SPRO_BCO_QUESTAO` left join `superpro`.`SPRO_TEXTO` on ((`superpro`.`SPRO_TEXTO`.`ID_TEXTO` =
                                                                                 `superpro`.`SPRO_BCO_QUESTAO`.`ID_TEXTO`))) join `superpro`.`SPRO_FONTE_VESTIBULAR`
           on ((`superpro`.`SPRO_FONTE_VESTIBULAR`.`ID_FONTE_VESTIBULAR` =
                `superpro`.`SPRO_BCO_QUESTAO`.`ID_FONTE_VESTIBULAR`))) join `superpro`.`SPRO_UF`
          on ((`superpro`.`SPRO_UF`.`ID_UF` =
               `superpro`.`SPRO_FONTE_VESTIBULAR`.`ID_UF`))) join `superpro`.`SPRO_REGIAO`
         on ((`superpro`.`SPRO_REGIAO`.`ID_REGIAO` =
              `superpro`.`SPRO_UF`.`ID_REGIAO`))) join `superpro`.`SPRO_GRAU_DIFICULDADE`
        on ((`superpro`.`SPRO_GRAU_DIFICULDADE`.`ID_GRAU_DIFICULDADE` =
             `superpro`.`SPRO_BCO_QUESTAO`.`ID_GRAU_DIFICULDADE`))) left join `superpro`.`SPRO_AUTH_USUARIO`
       on ((`superpro`.`SPRO_AUTH_USUARIO`.`ID_AUTH_USUARIO` =
            `superpro`.`SPRO_BCO_QUESTAO`.`ID_AUTH_COLABORADOR`))) join `superpro`.`SPRO_TIPO_QUESTAO`
      on ((`superpro`.`SPRO_TIPO_QUESTAO`.`ID_TIPO_QUESTAO` = `superpro`.`SPRO_BCO_QUESTAO`.`ID_TIPO_QUESTAO`)));

