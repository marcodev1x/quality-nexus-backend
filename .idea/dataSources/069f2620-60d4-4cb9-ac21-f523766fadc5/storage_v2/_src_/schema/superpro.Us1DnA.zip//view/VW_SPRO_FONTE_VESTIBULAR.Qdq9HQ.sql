create definer = admin@`%` view VW_SPRO_FONTE_VESTIBULAR as
select `superpro`.`SPRO_FONTE_VESTIBULAR`.`ID_FONTE_VESTIBULAR` AS `ID_FONTE_VESTIBULAR`,
       `superpro`.`SPRO_FONTE_VESTIBULAR`.`FONTE_VESTIBULAR`    AS `FONTE_VESTIBULAR`,
       `superpro`.`SPRO_FONTE_VESTIBULAR`.`ID_UF`               AS `ID_UF`,
       `superpro`.`SPRO_UF`.`SIGLA`                             AS `UF`,
       `superpro`.`SPRO_UF`.`ID_REGIAO`                         AS `ID_REGIAO`,
       `superpro`.`SPRO_REGIAO`.`REGIAO`                        AS `REGIAO`,
       `superpro`.`SPRO_FONTE_VESTIBULAR`.`DESCRICAO`           AS `DESCRICAO`,
       `superpro`.`SPRO_FONTE_VESTIBULAR`.`PUB`                 AS `PUB`
from ((`superpro`.`SPRO_FONTE_VESTIBULAR` join `superpro`.`SPRO_UF`
       on ((`superpro`.`SPRO_UF`.`ID_UF` = `superpro`.`SPRO_FONTE_VESTIBULAR`.`ID_UF`))) join `superpro`.`SPRO_REGIAO`
      on ((`superpro`.`SPRO_REGIAO`.`ID_REGIAO` = `superpro`.`SPRO_UF`.`ID_REGIAO`)));

