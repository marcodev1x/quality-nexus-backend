create definer = admin@`%` view VW_PBI_FATO_FULL_PEDIDOS as
select `sep`.`NUM_PEDIDO`                  AS `NUM_PEDIDO`,
       `sep`.`ID_CLIENTE`                  AS `ID_CLIENTE`,
       cast(`sep`.`DATA_REGISTRO` as date) AS `DATA_REGISTRO`
from (`superpro`.`SPRO_ECOMM_PEDIDO` `sep` join `superpro`.`SPRO_VW_CLIENTE_VALIDO` `sc`
      on ((`superpro`.`sc`.`ID_CLIENTE` = `sep`.`ID_CLIENTE`)))
where ((`sep`.`ID_STATUS_LOJA` = 1) and (`sep`.`NUM_PEDIDO_PAI` is null) and
       ((not (regexp_like(`sep`.`DESCR_PRODUTO`, 'parc[.]|parc|paracela|pacela|parcela'))) or
        (`sep`.`DESCR_PRODUTO` is null)));

