create definer = staging@`%` view VW_BI_DIM_MEIO_PAGAMENTO as
select distinct `superpro`.`SPRO_ECOMM_MEIO_PGTO`.`ID_MEIO_PGTO` AS `ID_MEIO_PGTO`,
                `superpro`.`SPRO_ECOMM_MEIO_PGTO`.`MEIO_PGTO`    AS `MEIO_PGTO`
from `superpro`.`SPRO_ECOMM_MEIO_PGTO`;

