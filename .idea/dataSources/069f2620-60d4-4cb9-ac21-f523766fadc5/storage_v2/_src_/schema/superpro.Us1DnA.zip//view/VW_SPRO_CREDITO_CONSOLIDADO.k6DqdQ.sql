create definer = staging@`%` view VW_SPRO_CREDITO_CONSOLIDADO as
select `superpro`.`SPRO_CREDITO_CONSOLIDADO`.`ID_CREDITO_CONSOLIDADO`                    AS `ID_CREDITO_CONSOLIDADO`,
       `superpro`.`SPRO_CREDITO_CONSOLIDADO`.`ID_CLIENTE`                                AS `ID_CLIENTE`,
       `superpro`.`SPRO_CREDITO_CONSOLIDADO`.`ID_REG_SALDO_ANT`                          AS `ID_REG_SALDO_ANT`,
       `superpro`.`SPRO_CREDITO_CONSOLIDADO`.`SALDO_ANT`                                 AS `SALDO_ANT`,
       (select `TB2`.`VALIDADE_CREDITOS`
        from `superpro`.`SPRO_ECOMM_PEDIDO` `TB2`
        where (`TB2`.`NUM_PEDIDO` = `superpro`.`SPRO_CREDITO_CONSOLIDADO`.`NUM_PEDIDO`)) AS `VALIDADE_CREDITOS`,
       `superpro`.`SPRO_CREDITO_CONSOLIDADO`.`CREDITO`                                   AS `CREDITO`,
       `superpro`.`SPRO_CREDITO_CONSOLIDADO`.`SALDO_FINAL`                               AS `SALDO_FINAL`,
       `superpro`.`SPRO_CREDITO_CONSOLIDADO`.`NUM_PEDIDO`                                AS `NUM_PEDIDO`,
       `superpro`.`SPRO_CREDITO_CONSOLIDADO`.`VENCIMENTO`                                AS `VENCIMENTO`,
       `superpro`.`SPRO_CREDITO_CONSOLIDADO`.`DATA_REGISTRO`                             AS `DATA_REGISTRO`,
       `superpro`.`SPRO_CLIENTE`.`EMAIL`                                                 AS `EMAIL`,
       `superpro`.`SPRO_CLIENTE`.`NOME_PRINCIPAL`                                        AS `NOME_PRINCIPAL`,
       `superpro`.`SPRO_CLIENTE`.`SOBRENOME`                                             AS `SOBRENOME`,
       `superpro`.`SPRO_CLIENTE`.`APELIDO`                                               AS `APELIDO`,
       `superpro`.`SPRO_CLIENTE`.`RAZAO_SOCIAL`                                          AS `RAZAO_SOCIAL`,
       `superpro`.`SPRO_CLIENTE`.`PF_PJ`                                                 AS `PF_PJ`,
       `superpro`.`SPRO_CLIENTE`.`CPF_CNPJ`                                              AS `CPF_CNPJ`,
       `superpro`.`SPRO_CLIENTE`.`INSC_EST`                                              AS `INSC_EST`,
       `superpro`.`SPRO_CLIENTE`.`INSC_MUN`                                              AS `INSC_MUN`,
       `superpro`.`SPRO_CLIENTE`.`DDD_CELULAR`                                           AS `DDD_CELULAR`,
       `superpro`.`SPRO_CLIENTE`.`FONE_CELULAR`                                          AS `FONE_CELULAR`,
       `superpro`.`SPRO_CLIENTE`.`DDD_RESID`                                             AS `DDD_RESID`,
       `superpro`.`SPRO_CLIENTE`.`FONE_RESID`                                            AS `FONE_RESID`,
       `superpro`.`SPRO_CLIENTE`.`DDD_CONTATO1`                                          AS `DDD_CONTATO1`,
       `superpro`.`SPRO_CLIENTE`.`FONE_CONTATO1`                                         AS `FONE_CONTATO1`,
       `superpro`.`SPRO_CLIENTE`.`RAMAL_CONTATO1`                                        AS `RAMAL_CONTATO1`,
       `superpro`.`SPRO_PLANO_REL_CLIENTE`.`ID_PLANO_CONSUMO`                            AS `ID_PLANO_CONSUMO`,
       `superpro`.`SPRO_CLIENTE`.`ID_FILIAL`                                             AS `ID_FILIAL`,
       `superpro`.`SPRO_CLIENTE`.`ID_MATRIZ`                                             AS `ID_MATRIZ`,
       `superpro`.`SPRO_CREDITO_CONSOLIDADO`.`BONUS`                                     AS `BONUS`,
       `superpro`.`SPRO_CREDITO_CONSOLIDADO`.`ID_CAMPANHA`                               AS `ID_CAMPANHA`,
       `superpro`.`SPRO_CLIENTE`.`ID_AUTH_PERFIL`                                        AS `ID_AUTH_PERFIL`,
       `superpro`.`SPRO_CLIENTE`.`ID_REVENDA`                                            AS `ID_REVENDA`,
       `superpro`.`SPRO_CLIENTE`.`SEXO`                                                  AS `SEXO`,
       `superpro`.`SPRO_CLIENTE`.`ID_CAMPANHA_ORIG_CAD`                                  AS `ID_CAMPANHA_ORIG_CAD`,
       `superpro`.`SPRO_CREDITO_CONSOLIDADO`.`MOTIVO`                                    AS `MOTIVO`,
       `superpro`.`SPRO_CLIENTE`.`BLOQ_AVISO_VENC_CRED`                                  AS `BLOQ_AVISO_VENC_CRED`,
       `superpro`.`SPRO_CLIENTE`.`DATA_AVISO_VENC_CRED`                                  AS `DATA_AVISO_VENC_CRED`,
       `superpro`.`SPRO_CREDITO_CONSOLIDADO`.`CUPOM`                                     AS `CUPOM`,
       (select `TB_PC`.`PLANO_CONSUMO`
        from ((`superpro`.`SPRO_PLANO_CONSUMO` `TB_PC` join `superpro`.`SPRO_PRECO_PLANO` `TB_PP`) join `superpro`.`SPRO_ECOMM_PEDIDO` `TB_ECOMM_P`
              on (((`TB_PC`.`ID_PLANO_CONSUMO` = `TB_PP`.`ID_PLANO_CONSUMO`) and
                   (`TB_ECOMM_P`.`ID_PLANO` = `TB_PP`.`ID_PRECO_PLANO`))))
        where ((`TB_ECOMM_P`.`NUM_PEDIDO` = `superpro`.`SPRO_CREDITO_CONSOLIDADO`.`NUM_PEDIDO`) and
               (`superpro`.`SPRO_CREDITO_CONSOLIDADO`.`NUM_PEDIDO` > 0)))                AS `PLANO_CONSUMO`
from (((`superpro`.`SPRO_CREDITO_CONSOLIDADO` join `superpro`.`SPRO_CLIENTE`
        on ((`superpro`.`SPRO_CLIENTE`.`ID_CLIENTE` =
             `superpro`.`SPRO_CREDITO_CONSOLIDADO`.`ID_CLIENTE`))) left join `superpro`.`SPRO_PLANO_REL_CLIENTE`
       on ((`superpro`.`SPRO_PLANO_REL_CLIENTE`.`ID_CLIENTE` =
            `superpro`.`SPRO_CLIENTE`.`ID_CLIENTE`))) left join `superpro`.`SPRO_PLANO_CONSUMO`
      on ((`superpro`.`SPRO_PLANO_CONSUMO`.`ID_PLANO_CONSUMO` =
           `superpro`.`SPRO_PLANO_REL_CLIENTE`.`ID_PLANO_CONSUMO`)))
where ((`superpro`.`SPRO_CLIENTE`.`ID_MATRIZ` = 0) and (`superpro`.`SPRO_CLIENTE`.`ID_AUTH_PERFIL` <> 7));

