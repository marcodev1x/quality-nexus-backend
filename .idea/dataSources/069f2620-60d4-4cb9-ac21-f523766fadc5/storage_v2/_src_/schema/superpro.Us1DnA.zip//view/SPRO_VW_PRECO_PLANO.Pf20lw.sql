create definer = staging@`%` view SPRO_VW_PRECO_PLANO as
select `superpro`.`SPRO_PRECO_PLANO`.`ID_PRECO_PLANO`               AS `ID_PRECO_PLANO`,
       `superpro`.`SPRO_PRECO_PLANO`.`PARCELAMENTO`                 AS `PARCELAMENTO`,
       `superpro`.`SPRO_PRECO_PLANO`.`ID_PLANO_CONSUMO`             AS `ID_PLANO_CONSUMO`,
       `superpro`.`SPRO_PRECO_PLANO`.`PERIODO_MES`                  AS `PERIODO_MES`,
       `superpro`.`SPRO_PRECO_PLANO`.`TOTAL_CREDITO`                AS `TOTAL_CREDITO`,
       `superpro`.`SPRO_PRECO_PLANO`.`VALOR`                        AS `VALOR`,
       `superpro`.`SPRO_PRECO_PLANO`.`VALOR_PROMO`                  AS `VALOR_PROMO`,
       `superpro`.`SPRO_PRECO_PLANO`.`PUB`                          AS `PUB`,
       `superpro`.`SPRO_PLANO_CONSUMO`.`PLANO_CONSUMO`              AS `PLANO_CONSUMO`,
       `superpro`.`SPRO_PLANO_CONSUMO`.`PRAZO_MESES_VENC`           AS `PRAZO_MESES_VENC`,
       `superpro`.`SPRO_PLANO_CONSUMO`.`VANTAGENS`                  AS `VANTAGENS`,
       `superpro`.`SPRO_PLANO_CONSUMO`.`TEXTO_LST`                  AS `TEXTO_LST`,
       `superpro`.`SPRO_PRECO_PLANO`.`LST_MSG`                      AS `LST_MSG`,
       `superpro`.`SPRO_PRECO_PLANO`.`TIPO_PLANO`                   AS `TIPO_PLANO`,
       `superpro`.`SPRO_PRECO_PLANO`.`PRECO_CUPOM`                  AS `PRECO_CUPOM`,
       `superpro`.`SPRO_PLANO_CONSUMO`.`CODIGO_PLANO`               AS `CODIGO_PLANO`,
       `superpro`.`SPRO_PRECO_PLANO`.`PERCENT_DESC_AV`              AS `PERCENT_DESC_AV`,
       `superpro`.`SPRO_PRECO_PLANO`.`VALOR_DESC_AV`                AS `VALOR_DESC_AV`,
       `superpro`.`SPRO_PRECO_PLANO`.`DATA_PUB`                     AS `DATA_PUB`,
       `superpro`.`SPRO_PRECO_PLANO`.`TEXTO_PROMO`                  AS `TEXTO_PROMO`,
       `superpro`.`SPRO_PRECO_PLANO`.`PRECO_CUPOM_PLANO_ANTIGO`     AS `PRECO_CUPOM_PLANO_ANTIGO`,
       `superpro`.`SPRO_PRECO_PLANO`.`QUESTOES_GRATUITAS_POR_LISTA` AS `QUESTOES_GRATUITAS_POR_LISTA`,
       `superpro`.`SPRO_PRECO_PLANO`.`NUM_LISTA_ATIVA`              AS `NUM_LISTA_ATIVA`
from (`superpro`.`SPRO_PRECO_PLANO` join `superpro`.`SPRO_PLANO_CONSUMO`
      on ((`superpro`.`SPRO_PLANO_CONSUMO`.`ID_PLANO_CONSUMO` = `superpro`.`SPRO_PRECO_PLANO`.`ID_PLANO_CONSUMO`)));

