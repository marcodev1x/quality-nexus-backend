create
    definer = admin@`%` procedure spSimuladoEnemRelEscola(IN idHistoricoGeraDoc int, IN formatoLista char(20),
                                                          IN listaAtiva int, IN listaExcluida int, IN numQuestoes int,
                                                          IN codLista int, IN nomeLista char(100),
                                                          OUT msgDebug char(255))
BEGIN
	# Localiza escolas que aderiram ao simulado Enem
	DECLARE getIdSml, getIdEscola INTEGER DEFAULT 0;
	DECLARE finished INTEGER DEFAULT 0;
	DECLARE escolasCursor CURSOR FOR 
	SELECT ID_SML_ESCOLA_ADESAO, ID_CLIENTE FROM SPRO_SML_ESCOLA_ADESAO WHERE ATIVO=1; 
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET finished = 1;
	
  # Debug:
	#SELECT formatoLista INTO msgDebug FROM DUAL;

	#Simulado Evolucional
	IF(formatoLista = 'LST_EVOLUCIONAL') THEN
		  # Debug:
			# SELECT 'Lista Evolucional...' INTO msgDebug FROM DUAL;
			IF (listaAtiva = 1 && listaExcluida = 0) THEN
				# Faz o vínculo com as escolas participantes do simulado
				OPEN escolasCursor;                                
				getEscolas: LOOP
					FETCH escolasCursor INTO getIdSml, getIdEscola;
					IF finished = 1 THEN 
						LEAVE getEscolas;
					END IF;       

					#Vincula a escola atual com a lista atual
					REPLACE INTO SPRO_SML_SIMULADO_REL_ESCOLA 
					(ID_SML_ESCOLA_ADESAO, ID_ESCOLA, TOTAL_QUESTOES, DESCRICAO, ID_HISTORICO_GERADOC, CODIGO_PROVA, DATA_REGISTRO) 
					VALUES(getIdSml, getIdEscola, numQuestoes, nomeLista, idHistoricoGeraDoc, codLista, NOW());                                    
				END LOOP getEscolas;
				CLOSE escolasCursor;
				# Debug:
        #SELECT 'Entrou no loop' INTO msgDebug FROM DUAL;
			END IF;
	END IF;

	IF (listaAtiva = 0 OR formatoLista != 'LST_EVOLUCIONAL' OR listaExcluida = 1) THEN
			# Exclui o vínculo com as escolas participantes do simulado
			DELETE FROM SPRO_SML_SIMULADO_REL_ESCOLA WHERE ID_HISTORICO_GERADOC = idHistoricoGeraDoc;
	END IF;	    
	# Debug
	#SELECT msgDebug as msg;
END;

