create definer = staging@`%` view VW_PBI_DIM_QUESTAO as
select `bq`.`ID_BCO_QUESTAO`      AS `ID_QUESTAO`,
       `bq`.`ID_FONTE_VESTIBULAR` AS `ID_FONTE_VESTIBULAR`,
       `bq`.`ID_STATUS_QUESTAO`   AS `ID_STATUS_QUESTAO`,
       `bq`.`ANO`                 AS `ANO`,
       min(`bq`.`DATA_REGISTRO`)  AS `DATA_REGISTRO`,
       max(`bq`.`DATA_PUB`)       AS `PUBLICAÇÃO`,
       max(`bq`.`DATA_UPDATE`)    AS `DATA_UPDATE`,
       `bq`.`TOTAL_USO`           AS `TOTAL_USO`,
       `bq`.`ID_MATERIA`          AS `ID_MATERIA`
from `superpro`.`SPRO_BCO_QUESTAO_MEMORY` `bq`
group by `bq`.`ID_BCO_QUESTAO`, `bq`.`FONTE_VESTIBULAR`, `bq`.`ID_MATERIA`;

