create definer = admin@`%` trigger topDownload_before_insert
    before insert
    on SPRO_TOP_DOWNLOAD_MAILING
    for each row
BEGIN
	SET NEW.HASH = uuid();
END;

