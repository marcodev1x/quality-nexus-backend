create
    definer = admin@`%` function fcCorrigirVencimento(ID_CREDITO_CONSOLIDADO_VALUE int) returns date
BEGIN
	# 21/10/2014
	# Corrige o vencimento de lançamentos anteriores, se necessário.
	# Lançamentos de crédito antigos com vencimento maior que o último lançamento devem assumir o vencimento
	# da última compra.
	# @author Claudio Rubens Silva Filho	
	DECLARE NOVO_VENC DATE;
	SET NOVO_VENC = '';
	IF (ID_CREDITO_CONSOLIDADO_VALUE > 0) THEN
		# Localiza o ID_CLIENTE do registro atual
		SELECT ID_CLIENTE INTO @ID_USER FROM SPRO_CREDITO_CONSOLIDADO WHERE ID_CREDITO_CONSOLIDADO = ID_CREDITO_CONSOLIDADO_VALUE;

		# Localiza a DATA_REGISTRO do registro informado
		SELECT DATA_REGISTRO INTO @DATA_REG_ULTIMO_PED FROM SPRO_CREDITO_CONSOLIDADO WHERE ID_CREDITO_CONSOLIDADO = ID_CREDITO_CONSOLIDADO_VALUE;

		# Localiza o VENCIMENTO do registro informado
		SELECT VENCIMENTO INTO @VENCIMENTO_ULTIMO_PED FROM SPRO_CREDITO_CONSOLIDADO WHERE ID_CREDITO_CONSOLIDADO = ID_CREDITO_CONSOLIDADO_VALUE;

		IF (@ID_USER > 0) THEN
			# Verifica se o vencimento atual é menor que vencimentos anteriores
			SELECT DISTINCT VENCIMENTO INTO @VENCIMENTO_ANT FROM SPRO_CREDITO_CONSOLIDADO WHERE ID_CLIENTE = @ID_USER
			AND DATA_REGISTRO < @DATA_REG_ULTIMO_PED AND VENCIMENTO > @VENCIMENTO_ULTIMO_PED AND ID_CREDITO_CONSOLIDADO != ID_CREDITO_CONSOLIDADO_VALUE
			ORDER BY VENCIMENTO DESC LIMIT 1;
			
			IF (LENGTH(@VENCIMENTO_ANT) > 0) THEN
				# Encontrou um vencimento maior que o pedido informado porém lançado em data anterior.
				# Redefine o vencimento anterior para o mesmo vencimento atual
				#UPDATE SPRO_CREDITO_CONSOLIDADO SET VENCIMENTO_ORIG = VENCIMENTO, VENCIMENTO = @VENCIMENTO_ULTIMO_PED 
				#WHERE ID_CLIENTE = @ID_USER AND VENCIMENTO = @VENCIMENTO_ANT;

				SET NOVO_VENC = @VENCIMENTO_ULTIMO_PED;
			END IF;
		END IF;
	END IF;

	RETURN NOVO_VENC;
END;

