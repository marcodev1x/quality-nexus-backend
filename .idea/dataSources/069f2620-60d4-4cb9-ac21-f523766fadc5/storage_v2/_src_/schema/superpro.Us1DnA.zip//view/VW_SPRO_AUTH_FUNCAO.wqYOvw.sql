create definer = admin@`%` view VW_SPRO_AUTH_FUNCAO as
select `TB1`.`ID_AUTH_FUNCAO`                                    AS `ID_AUTH_FUNCAO`,
       `TB1`.`FUNCAO`                                            AS `FUNCAO`,
       `TB1`.`LIM_CREDITO`                                       AS `LIM_CREDITO`,
       `TB1`.`CODIGO`                                            AS `CODIGO`,
       `TB1`.`RECARGA_AUTO`                                      AS `RECARGA_AUTO`,
       `TB1`.`ID_CLIENTE`                                        AS `ID_CLIENTE`,
       (select count(0) AS `COUNT(*)`
        from `superpro`.`SPRO_CLIENTE` `TB2`
        where (`TB2`.`ID_AUTH_FUNCAO` = `TB1`.`ID_AUTH_FUNCAO`)) AS `USUARIOS`
from `superpro`.`SPRO_AUTH_FUNCAO` `TB1`;

