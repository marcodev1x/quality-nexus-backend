create definer = admin@`%` trigger checkResgateSaldoAntOnInsert_
    before insert
    on SPRO_CREDITO_CONSOLIDADO
    for each row
BEGIN
         IF (NEW.ID_MATRIZ = 0) THEN
	# Verifica se é conta Escola
	SELECT ID_AUTH_PERFIL INTO @perfil FROM SPRO_CLIENTE WHERE ID_CLIENTE = NEW.ID_CLIENTE;
	IF (@perfil = 6) THEN
		SELECT MAX(VENCIMENTO) INTO @vencimentoAtual FROM SPRO_CREDITO_CONSOLIDADO WHERE ID_CLIENTE = NEW.ID_CLIENTE AND VENCIMENTO > DATE(NOW());
		IF LENGTH(@vencimentoAtual) > 0 THEN
			SET NEW.VENCIMENTO = ADDDATE(DATE(@vencimentoAtual),INTERVAL 12 MONTH);
		ELSE
			SET NEW.VENCIMENTO = ADDDATE(DATE(NOW()),INTERVAL 12 MONTH);
		END IF;
		# SET NEW.VENCIMENTO = '2021-12-31';

		IF (NEW.NUM_PEDIDO > 0) THEN
			# Verifica o saldo anterior no momento da compra
			SELECT CREDITOS_SALDO_ANT INTO @saldoAnterior FROM SPRO_ECOMM_PEDIDO WHERE NUM_PEDIDO = NEW.NUM_PEDIDO AND ID_CLIENTE = NEW.ID_CLIENTE;
			IF (@saldoAnterior = 0 AND @saldoAnterior <> NEW.SALDO_ANT) THEN
				SET NEW.SALDO_ANT = @saldoAnterior;
				SET NEW.SALDO_FINAL = NEW.CREDITO;
			END IF;
		END IF;
	END IF;
         END IF;

         IF (NEW.ID_MATRIZ = 0 AND NEW.OPERACAO = 'C' AND NEW.SALDO_ANT = 0) THEN
                   
	SELECT MAX(VENCIMENTO) INTO @VENCIMENTO_ANT FROM SPRO_CREDITO_CONSOLIDADO WHERE ID_CLIENTE = NEW.ID_CLIENTE;
	
	IF(LENGTH(@VENCIMENTO_ANT) > 0) THEN
                                   SELECT DATEDIFF(@VENCIMENTO_ANT, DATE(NOW())) INTO @DIAS_A_VENCER FROM DUAL;
                                    IF(NEW.NUM_PEDIDO > 0 AND @DIAS_A_VENCER <= 0) THEN
                                                        
			SELECT DATE(DATA_REGISTRO) INTO @DATA_REGISTRO_PEDIDO FROM SPRO_ECOMM_PEDIDO WHERE NUM_PEDIDO = NEW.NUM_PEDIDO;
                                                SELECT DATEDIFF(@VENCIMENTO_ANT, @DATA_REGISTRO_PEDIDO) INTO @DIF_DATAS FROM DUAL;

                                                 IF (@DIF_DATAS >= 0 AND @DIF_DATAS <= 10 ) THEN
                                                 	SET NEW.OBS = '';                                                        
                                                 END IF;	
		END IF;
	END IF;
      END IF;

      

      IF (NEW.NUM_PEDIDO > 0) THEN
                 
                 IF (LENGTH(NEW.CUPOM) > 1) THEN
                               
                               SET @PREFIXO_CUPOM = SUBSTR(NEW.CUPOM,1,4);
                               IF (@PREFIXO_CUPOM = 'SVC-') THEN
                                         
                                         SELECT ID_SVC_CUPOM INTO @ID_SVC_CUPOM FROM SPRO_SVC_CUPOM WHERE CUPOM = NEW.CUPOM;
                                         SET @OBS = 'Cupom SVC: PENDENTE';
                                         IF (@ID_SVC_CUPOM > 0) THEN
                                                   
                                                   
                                                   UPDATE SPRO_SVC_CUPOM_REL_USER SET NUM_PEDIDO_INI = NEW.NUM_PEDIDO, BENEFICIO_INICIADO_EM = NEW.DATA_REGISTRO, ID_USER_INDICADO = NEW.ID_CLIENTE, CREDITOS=NEW.CREDITO WHERE ID_SVC_CUPOM = @ID_SVC_CUPOM;
                                                   SET @OBS = 'Cupom SVC: Beneficio liberado com sucesso!';
                                        END IF;
                                        SET NEW.OBS = @OBS;
                                 END IF;
                 ELSE
                                  
                                  
                                  SELECT NUM_PEDIDO INTO @NUM_PEDIDO_SVC FROM SPRO_ECOMM_PEDIDO 
                                  WHERE ID_CLIENTE = NEW.ID_CLIENTE AND SUBSTR(CUPOM,1,4) = 'SVC-' AND NUM_PEDIDO != NEW.NUM_PEDIDO 
                                  ORDER BY DATA_REGISTRO DESC LIMIT 1;
                                  
                                   IF (@NUM_PEDIDO_SVC > 0) THEN
                                          
                                          UPDATE SPRO_SVC_CUPOM_REL_USER SET BENEFICIO_ENCERRADO_EM = NOW(), NUM_PEDIDO_FIM = NEW.NUM_PEDIDO, OBS = CONCAT('Nova compra. Pedido: ', NEW.NUM_PEDIDO) WHERE NUM_PEDIDO_INI = @NUM_PEDIDO_SVC;
                                   END IF;
               END IF;

               IF (NEW.HISTORICO_APARTIR_DE IS NOT NULL && NEW.HISTORICO_APARTIR_DE != '0000-00-00 00:00:00') THEN
                           
                           SELECT GROUP_CONCAT(ID_USER_INDICADO) INTO @LST_ID_USER_INDICADO FROM SPRO_SVC_CUPOM_REL_USER
                           WHERE ID_USER = NEW.ID_CLIENTE AND NUM_PEDIDO_FIM = 0;

                           IF (LENGTH(@LST_ID_USER_INDICADO) > 0) THEN
                                    
                                    UPDATE SPRO_SVC_CUPOM_REL_USER SET BENEFICIO_ENCERRADO_EM = NOW(), NUM_PEDIDO_FIM = NEW.NUM_PEDIDO, 
                                    OBS = CONCAT('Assinatura anterior vencida. Pedido: ', NEW.NUM_PEDIDO) WHERE ID_USER_INDICADO IN (@LST_ID_USER_INDICADO);
                           END IF;
               END IF;
       END IF;
END;

