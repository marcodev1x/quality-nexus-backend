create definer = admin@`%` view VW_SPRO_REGIAO as
select `superpro`.`SPRO_REGIAO`.`ID_REGIAO` AS `VALUE`, `superpro`.`SPRO_REGIAO`.`REGIAO` AS `LABEL`
from `superpro`.`SPRO_REGIAO`;

