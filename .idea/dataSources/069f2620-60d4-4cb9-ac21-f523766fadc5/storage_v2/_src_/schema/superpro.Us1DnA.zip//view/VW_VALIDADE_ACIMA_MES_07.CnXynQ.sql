create definer = staging@`%` view VW_VALIDADE_ACIMA_MES_07 as
select `TB2`.`ID_CLIENTE`                                                                                          AS `ID_CLIENTE`,
       (select `TB1`.`EMAIL`
        from `superpro`.`SPRO_CLIENTE` `TB1`
        where (`TB1`.`ID_CLIENTE` = `TB2`.`ID_CLIENTE`))                                                           AS `EMAIL`,
       `TB2`.`VENCIMENTO`                                                                                          AS `VENCIMENTO`
from `superpro`.`SPRO_CREDITO_CONSOLIDADO` `TB2`
where ((`TB2`.`ID_MATRIZ` = 0) and (`TB2`.`ID_CLIENTE` > 0) and
       (cast(`TB2`.`VENCIMENTO` as date) > cast('2020-12-29' as date)) and (`TB2`.`ID_CLIENTE` not in
                                                                            (7, 9, 433, 26436, 778042, 758043, 104359,
                                                                             735449, 314782, 39451, 465402, 400501,
                                                                             162438, 115283, 752090, 44459, 215877,
                                                                             747413, 132053, 807732, 66815)));

