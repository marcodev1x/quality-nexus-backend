create definer = admin@`%` view VW_SPRO_AUTH_HIST_ACESSO as
select `superpro`.`SPRO_AUTH_HIST_ACESSO`.`ID_AUTH_HIST_ACESSO` AS `ID_AUTH_HIST_ACESSO`,
       `superpro`.`SPRO_AUTH_HIST_ACESSO`.`ID_LOGIN`            AS `ID_LOGIN`,
       `superpro`.`SPRO_AUTH_HIST_ACESSO`.`IP_ORIG`             AS `IP_ORIG`,
       `superpro`.`SPRO_AUTH_HIST_ACESSO`.`ID_MATRIZ`           AS `ID_MATRIZ`,
       `superpro`.`SPRO_AUTH_HIST_ACESSO`.`ID_FILIAL`           AS `ID_FILIAL`,
       `superpro`.`SPRO_AUTH_HIST_ACESSO`.`BROWSER`             AS `BROWSER`,
       `superpro`.`SPRO_AUTH_HIST_ACESSO`.`BROWSER_VER`         AS `BROWSER_VER`,
       `superpro`.`SPRO_AUTH_HIST_ACESSO`.`PLATAFORMA`          AS `PLATAFORMA`,
       `superpro`.`SPRO_AUTH_HIST_ACESSO`.`DATA_REGISTRO`       AS `DATA_REGISTRO`,
       `superpro`.`SPRO_CLIENTE`.`EMAIL`                        AS `EMAIL`,
       `superpro`.`SPRO_CLIENTE`.`NOME_PRINCIPAL`               AS `NOME_PRINCIPAL`,
       `superpro`.`SPRO_CLIENTE`.`SENHA`                        AS `SENHA`,
       `superpro`.`SPRO_CLIENTE`.`PF_PJ`                        AS `PF_PJ`,
       `superpro`.`SPRO_CLIENTE`.`ID_AUTH_PERFIL`               AS `ID_AUTH_PERFIL`
from (`superpro`.`SPRO_CLIENTE` join `superpro`.`SPRO_AUTH_HIST_ACESSO`
      on (((`superpro`.`SPRO_AUTH_HIST_ACESSO`.`ID_LOGIN` = `superpro`.`SPRO_CLIENTE`.`ID_CLIENTE`) and
           (`superpro`.`SPRO_AUTH_HIST_ACESSO`.`ID_MATRIZ` = `superpro`.`SPRO_CLIENTE`.`ID_MATRIZ`) and
           (`superpro`.`SPRO_AUTH_HIST_ACESSO`.`ID_FILIAL` = `superpro`.`SPRO_CLIENTE`.`ID_FILIAL`))));

