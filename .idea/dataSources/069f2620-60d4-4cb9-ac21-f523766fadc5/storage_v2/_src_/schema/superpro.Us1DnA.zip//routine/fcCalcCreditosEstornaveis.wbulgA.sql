create
    definer = admin@`%` function fcCalcCreditosEstornaveis(ID_MATRIZ_IN int, NIVEL_CALC varchar(1)) returns int
BEGIN
	# @author Claudio Rubens Silva Filho	
	# 27/10/2016
	#
	# Calcula e retorna o total de créditos estornáveis da mantenedora.
	# É possível consultar créditos estornáveis de Professores ou Escolas, passando o parâmetro NIVEL_CALC como 'P' ou 'E' respectivamente.
	#
	# PARÂMETROS:
	# int ID_MATRIZ_IN, que deve ser o ID da mantenedora.
	# varchar(1) NIVEL_CALC, que pode ser 'P', para consulta de professores, ou 'E' para escolas
	# @return int Total de créditos estornáveis
	DECLARE CONSUMO_CRED_PROF, SALDO_INI_MATRIZ, SALDO_APOS_ESTORNO, VAR_ID_REG_SALDO_ANT, VAR_NUM_PEDIDO INT default 0;	
	DECLARE VAR_VENCIMENTO DATE;
	DECLARE DATA_ULT_COMPRA_MATRIZ TEXT;
	DECLARE VAR_PERFIL TEXT;
	DECLARE saldoEstornavelEsc int default 0;
	DECLARE saldoEstornavelProf int default 0;
	DECLARE consumoCreditoProf int default 0;
	DECLARE consumoCreditoMatriz int default 0;
	DECLARE saldoEstornavel, saldoAtualMantenedora, saldoDistribuido int default 0;
	DECLARE token varchar(32) default 'abcd';
	SELECT md5(CONCAT(ID_MATRIZ_IN, NOW())) INTO token;
	# Localiza o perfil do ID_MANTENEDORA informado
	SELECT TRIM(CODIGO) INTO VAR_PERFIL FROM SPRO_USER_PERFIL 
	WHERE ID_USER_PERFIL = (SELECT ID_USER_PERFIL FROM SPRO_USER WHERE ID_USER = ID_MATRIZ_IN);
	
	# Localiza dados da última compra da Mantenedora
	SELECT 
	ID_CREDITO_CONSOLIDADO,SALDO_FINAL, NUM_PEDIDO, VENCIMENTO, DATA_REGISTRO 
	INTO VAR_ID_REG_SALDO_ANT, SALDO_INI_MATRIZ, VAR_NUM_PEDIDO, VAR_VENCIMENTO, DATA_ULT_COMPRA_MATRIZ 
	FROM SPRO_CREDITO_CONSOLIDADO 
	WHERE ID_CLIENTE = ID_MATRIZ_IN AND VENCIMENTO >= DATE(NOW())
	ORDER BY VENCIMENTO DESC LIMIT 1;	
	IF (SALDO_INI_MATRIZ = 0) THEN
		SET saldoEstornavel = 0;
		RETURN saldoEstornavel;
	END IF;
	IF (VAR_PERFIL = 'MANTENEDOR') THEN		
		# Extrai o saldo das escolas da Mantenedora
		INSERT INTO SPRO_ESTORNO_CREDITO_CALC (ID_MANTENEDORA, TOKEN, ID_USER, PERFIL, DATA_REGISTRO) (
					SELECT ID_MATRIZ, token, ID_USER, 'ESC', NOW() FROM SPRO_USER WHERE ID_MATRIZ = ID_MATRIZ_IN
		);
		#Soma o saldo final de Escolas
		SELECT SUM(SALDO_ATUAL) INTO saldoEstornavelEsc 
		FROM SPRO_ESTORNO_CREDITO_CALC 
		WHERE PERFIL = 'ESC' AND TOKEN = token AND ID_MANTENEDORA = ID_MATRIZ_IN;
		IF (saldoEstornavelEsc IS NULL) THEN
			SET saldoEstornavelEsc = 0;
		END IF;
	END IF;
	#IF (NIVEL_CALC = 'M') THEN
		# Calcula o saldo atual da Mantenedora
		#SET saldoEstornavel = SALDO_INI_MATRIZ - consumoCreditoProf;
		#RETURN saldoEstornavel;
	#END IF;
	IF (NIVEL_CALC = 'P') THEN
			# Calcula o consumo dos professores a partir da última compra da mantenedora
			IF (VAR_PERFIL = 'MANTENEDOR') THEN		
				# O ID_MATRIZ_IN refere-se a uma Mantenedora
				SELECT SUM(DEBITO) INTO consumoCreditoProf FROM SPRO_HISTORICO_GERADOC 
				WHERE ID_LOGIN IN(
					SELECT ID_USER FROM SPRO_USER WHERE ID_MATRIZ = ID_MATRIZ_IN OR ID_MATRIZ IN (
						SELECT ID_USER FROM SPRO_USER WHERE ID_MATRIZ = ID_MATRIZ_IN
					)				
				) AND DATA_REGISTRO >= DATA_ULT_COMPRA_MATRIZ;	
			ELSE 
				# O ID_MATRIZ_IN refere-se a uma Escola (por dedução)
				SELECT SUM(DEBITO) INTO consumoCreditoProf FROM SPRO_HISTORICO_GERADOC 
				WHERE ID_LOGIN IN(SELECT ID_CLIENTE FROM SPRO_CLIENTE WHERE ID_MATRIZ = ID_MATRIZ_IN) 
				AND DATA_REGISTRO >= DATA_ULT_COMPRA_MATRIZ;	

				SELECT SUM(DEBITO) INTO consumoCreditoMatriz FROM SPRO_HISTORICO_GERADOC 
				WHERE ID_LOGIN = ID_MATRIZ_IN 
				AND DATA_REGISTRO >= DATA_ULT_COMPRA_MATRIZ;	

				IF (consumoCreditoMatriz > 0) THEN
					SET consumoCreditoProf = consumoCreditoProf + consumoCreditoMatriz;
				END IF;

			END IF;
			# Calcula o saldo atual da Mantenedora
			SELECT fcCalcSaldo(ID_MATRIZ_IN) INTO saldoAtualMantenedora;

			# Calcula o saldo estornável do professor		
			SET saldoDistribuido = SALDO_INI_MATRIZ - saldoAtualMantenedora;
			IF (saldoDistribuido > 0) THEN
					SET saldoEstornavelProf = saldoDistribuido - saldoEstornavelEsc;
					IF (consumoCreditoProf > 0) THEN				
						SET saldoEstornavelProf = saldoEstornavelProf - consumoCreditoProf;				
					END IF;
					SET saldoEstornavel = saldoEstornavelProf;
			END IF;

			IF (VAR_PERFIL != 'MANTENEDOR') THEN	
				# IMPORTANTE:
				# Nova alteração feita em 19/02/2108, pois apresentou inconsistência no cálculo de Escolas.
				#
				# O saldo distribuido pela escola é menor ou igual a zero.
				# Provavelmente um estorno em lote foi feito, retornando todos os créditos para a mantenedora e sem consumo.
				# Calcula de outra forma:
				SET token = CONCAT(NOW(),ID_MATRIZ_IN);
				
				INSERT INTO SPRO_ESTORNO_CREDITO_CALC (ID_MANTENEDORA, TOKEN, ID_USER, PERFIL, DATA_REGISTRO) (
							SELECT ID_MATRIZ, token, ID_USER, 'PROF', NOW() FROM SPRO_USER 
							WHERE ID_MATRIZ = ID_MATRIZ_IN AND (EXCLUIDO_EM = '0000-00-00 00:00:00' 
							OR EXCLUIDO_EM IS NULL)
				);

				SELECT SUM(SALDO_ATUAL) INTO saldoEstornavel 
				FROM SPRO_ESTORNO_CREDITO_CALC WHERE ID_MANTENEDORA = ID_MATRIZ_IN AND TOKEN = token;
				
				IF (saldoEstornavel < 0) THEN
					SET saldoEstornavel = 0;
				END IF;
			END IF;			
	ELSEIF (NIVEL_CALC = 'E') THEN
		SET saldoEstornavel = saldoEstornavelEsc;	
	END IF;
	DELETE FROM SPRO_ESTORNO_CREDITO_CALC WHERE ID_MANTENEDORA = ID_MATRIZ_IN AND TOKEN = token;
	RETURN saldoEstornavel;
END;

