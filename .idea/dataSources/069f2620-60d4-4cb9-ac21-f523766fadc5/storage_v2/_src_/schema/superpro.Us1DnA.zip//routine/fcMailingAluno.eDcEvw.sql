create
    definer = admin@`%` function fcMailingAluno() returns int
BEGIN
	# 22/08/2014
	# Gera lista de e-mails de alunos
	# @author Claudio Rubens Silva Filho	
	
	DECLARE RETORNO INT;

	SET @ORIGEM 				= 'SPRO_USER';
	SET @TIPO_CAD 			= 'ALUNO';
	SET @FUNC						= 'fcMailingAluno';
	SET @DT_HR_EXTRACAO = NOW();

	DELETE FROM SPRO_MAILING WHERE ORIGEM = @ORIGEM AND TIPO_CAD = @TIPO_CAD AND FUNCTION_ORIG = @FUNC;
		
	REPLACE INTO SPRO_MAILING (NOME,EMAIL, ORIGEM, PF_PJ, PERFIL, TIPO_CAD, FUNCTION_ORIG, DATA_REGISTRO, DT_HR_EXTRACAO)(
		SELECT NOME, EMAIL, ORIGEM, PF_PJ, 'ALUNO' AS PERFIL, @TIPO_CAD, @FUNC, DATA_REGISTRO, @DT_HR_EXTRACAO  
		FROM (			
			SELECT ID_USER, TRIM(NOME) AS NOME, TRIM(EMAIL) AS EMAIL, @ORIGEM AS ORIGEM, 'PF' AS PF_PJ, ID_MATRIZ, ID_USER_PERFIL, DATA_REGISTRO			
			FROM SPRO_USER TB1 WHERE ID_USER_PERFIL = 5 AND ID_MATRIZ = 0
			GROUP BY EMAIL 
			HAVING (
				(
					SELECT COUNT(1) 
					FROM SPRO_CREDITO_CONSOLIDADO TB_CRED_CONSOLID
					WHERE NUM_PEDIDO > 0 AND (ifnull(BONUS, 0) = 0)
					AND VENCIMENTO >= curdate() AND ID_MATRIZ = 0 AND ID_FILIAL = 0
					AND TB_CRED_CONSOLID.ID_CLIENTE = TB1.ID_USER
				) = 0 # Não está na lista de assinantes
				
			)			
		) AS DERIV
	);

	# Excluir registros cujo e-mail foi alterado propositalmente para evitar conflito no cadastro
	DELETE FROM SPRO_MAILING
	WHERE EMAIL LIKE '%.brx' OR EMAIL LIKE '%.comx' OR EMAIL LIKE '%.brdel' OR EMAIL LIKE '%.comdel';

	# Excluir registros que são dos domínios interbits e supervip
	DELETE FROM SPRO_MAILING 
	WHERE SPRO_MAILING.EMAIL LIKE '%interbits%' 
	OR SPRO_MAILING.EMAIL LIKE '%supervip%';

	# Excluir e-mails incluídos na blacklist
 	DELETE FROM SPRO_MAILING 
	WHERE SPRO_MAILING.ORIGEM = @ORIGEM  AND (
				SELECT count(1)
				FROM SPRO_MAIL_BLK_LIST TB_BLK
				WHERE TB_BLK.EMAIL = SPRO_MAILING.EMAIL					
	) > 0;

  # Excluir e-mails que possuem os domínios '*@dominio...' incluídos na blacklist
 	DELETE FROM SPRO_MAILING 
	WHERE SPRO_MAILING.ORIGEM = @ORIGEM  AND (
			SELECT count(1) 
			FROM SPRO_MAIL_BLK_LIST TB_BLK
			WHERE TB_BLK.EMAIL = CONCAT('*@',SUBSTRING_INDEX(SPRO_MAILING.EMAIL,'@',-1))		
	) > 0;

	SELECT COUNT(*) INTO RETORNO FROM SPRO_MAILING WHERE FUNCTION_ORIG = @FUNC;
	RETURN RETORNO;
END;

