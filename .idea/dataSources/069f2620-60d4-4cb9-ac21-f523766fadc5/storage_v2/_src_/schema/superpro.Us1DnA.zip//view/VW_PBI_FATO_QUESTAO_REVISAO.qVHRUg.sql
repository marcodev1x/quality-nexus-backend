create definer = powerbi@`%` view VW_PBI_FATO_QUESTAO_REVISAO as
select `scq`.`ID_COMENTARIO_QUESTAO`              AS `ID_COMENTARIO_QUESTAO`,
       `scq`.`MOTIVO`                             AS `MOTIVO`,
       `scq`.`ID_LOGIN`                           AS `ID_LOGIN`,
       `scq`.`VISTO`                              AS `VISTO`,
       `scq`.`ID_BCO_QUESTAO`                     AS `ID_BCO_QUESTAO`,
       cast(`scq`.`ENVIO_RESP_INTERBITS` as date) AS `date(scq.ENVIO_RESP_INTERBITS)`,
       `scq`.`DATA_REGISTRO`                      AS `date(scq.DATA_REGISTRO)`
from (`superpro`.`SPRO_COMENTARIO_QUESTAO` `scq` join `superpro`.`SPRO_VW_CLIENTE_VALIDO` `sc`
      on ((`superpro`.`sc`.`ID_CLIENTE` = `scq`.`ID_LOGIN`)));

