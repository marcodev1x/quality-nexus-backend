create definer = admin@`%` trigger insert_user_del_to_user
    after insert
    on SPRO_USER_DEL
    for each row
BEGIN
     IF (NEW.ID_USER_DEL > 0) THEN
             
            UPDATE  SPRO_USER SET LOGIN = CONCAT(LOGIN,'_del'), 
            EMAIL = CONCAT(EMAIL,'_del'), 
            EXCLUIDO_EM = NOW() WHERE ID_USER = NEW.ID_CLIENTE AND EXCLUIDO_EM IS NULL;

            
           UPDATE SPRO_ALUNO_ESCOLA SET EXCLUIDO_EM = NOW()
           WHERE ID_ALUNO = NEW.ID_CLIENTE;
     END IF;
END;

