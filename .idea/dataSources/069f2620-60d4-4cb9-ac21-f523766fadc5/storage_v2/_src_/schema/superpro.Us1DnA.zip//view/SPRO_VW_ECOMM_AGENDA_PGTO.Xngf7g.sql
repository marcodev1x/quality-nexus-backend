create definer = staging@`%` view SPRO_VW_ECOMM_AGENDA_PGTO as
select `TB1`.`ID_AGENDA_PGTO`      AS `ID_AGENDA_PGTO`,
       `TB1`.`ID_MEIO_PGTO`        AS `ID_MEIO_PGTO`,
       `TB1`.`NUM_PEDIDO_COBRANCA` AS `NUM_PEDIDO_COBRANCA`,
       `TB1`.`NUM_PEDIDO`          AS `NUM_PEDIDO`,
       `TB1`.`NUM_PEDIDO`          AS `NUM_PEDIDO_PAI`,
       `TB1`.`VALOR`               AS `VALOR`,
       `TB1`.`VENCIMENTO`          AS `VENCIMENTO`,
       `TB1`.`PARCELA`             AS `PARCELA`,
       `TB1`.`DATA_PGTO`           AS `DATA_PGTO`,
       `TB1`.`AVISO_ENVIADO_EM`    AS `AVISO_ENVIADO_EM`,
       `TB1`.`DATA_REGISTRO`       AS `DATA_REGISTRO`,
       `TB2`.`CREDITOS`            AS `CREDITOS`,
       `TB2`.`ID_STATUS_LOJA`      AS `ID_STATUS_LOJA`,
       `TB2`.`DESCR_PRODUTO`       AS `DESCR_PRODUTO`,
       `TB2`.`VALOR_TOTAL`         AS `VALOR_TOTAL`,
       `TB2`.`NOME_CLIENTE`        AS `NOME_CLIENTE`,
       `TB3`.`CPF_CNPJ`            AS `CPF_CNPJ`,
       `TB2`.`ID_CLIENTE`          AS `ID_CLIENTE`,
       `TB3`.`EMAIL`               AS `EMAIL`,
       `TB2`.`ID_PEDIDO`           AS `ID_PEDIDO`,
       `TB4`.`MEIO_PGTO`           AS `MEIO_PGTO`,
       `TB2`.`STR_NUM_PGTO`        AS `STR_NUM_PGTO`,
       `TB2`.`VALOR_PARCELA`       AS `VALOR_PARCELA`,
       `TB2`.`DATA_VENC_BOLETO`    AS `DATA_VENC_BOLETO`
from (((`superpro`.`SPRO_ECOMM_AGENDA_PGTO` `TB1` join `superpro`.`SPRO_ECOMM_PEDIDO` `TB2`) join `superpro`.`SPRO_CLIENTE` `TB3`) join `superpro`.`SPRO_ECOMM_MEIO_PGTO` `TB4`)
where ((`TB1`.`NUM_PEDIDO_COBRANCA` = `TB2`.`NUM_PEDIDO`) and (`TB2`.`ID_CLIENTE` = `TB3`.`ID_CLIENTE`) and
       (`TB4`.`ID_MEIO_PGTO` = `TB1`.`ID_MEIO_PGTO`));

-- comment on column SPRO_VW_ECOMM_AGENDA_PGTO.STR_NUM_PGTO not supported: Identifica o pagamento atual. ÃƒÅ¡lil para pedidos vinculados a um pedido pai (Ex: 1_3 = pagamento 1 do total de trÃƒÂªs)

