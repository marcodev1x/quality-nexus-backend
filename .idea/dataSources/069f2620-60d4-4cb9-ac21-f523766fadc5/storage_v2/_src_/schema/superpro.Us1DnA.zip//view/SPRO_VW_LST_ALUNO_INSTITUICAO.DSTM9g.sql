create definer = staging@`%` view SPRO_VW_LST_ALUNO_INSTITUICAO as
select `TB2`.`ID_LST_ALUNO_INSTITUICAO` AS `ID_LST_ALUNO_INSTITUICAO`,
       `TB2`.`ID_INSTITUICAO`           AS `ID_INSTITUICAO`,
       `TB1`.`NOME_PRINCIPAL`           AS `NOME_INSTITUICAO`,
       `TB2`.`NOME`                     AS `NOME_ALUNO`,
       `TB2`.`EMAIL`                    AS `EMAIL_ALUNO`,
       `TB2`.`SENHA`                    AS `SENHA`,
       `TB2`.`RA`                       AS `RA`,
       `TB2`.`COD_TURMA`                AS `COD_TURMA`,
       `TB2`.`DATA_REGISTRO`            AS `DATA_REGISTRO`,
       `TB2`.`DATA_UPD`                 AS `DATA_UPD`
from (`superpro`.`SPRO_CLIENTE` `TB1` join `superpro`.`SPRO_LST_ALUNO_INSTITUICAO` `TB2`)
where (`TB1`.`ID_CLIENTE` = `TB2`.`ID_INSTITUICAO`);

