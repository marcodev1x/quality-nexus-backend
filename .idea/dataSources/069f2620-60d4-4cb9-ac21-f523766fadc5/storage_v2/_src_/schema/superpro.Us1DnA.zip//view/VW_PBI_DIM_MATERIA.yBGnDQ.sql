create definer = admin@`%` view VW_PBI_DIM_MATERIA as
select `mat`.`ID_MATERIA`            AS `ID_MATERIA`,
       `mat`.`MATERIA`               AS `MATERIA`,
       `mat`.`AREA`                  AS `AREA`,
       (case `mat`.`ID_MATERIA`
            when 12 then 'COM'
            when 13 then 'FOR'
            when 14 then 'ATE'
            when 19 then 'LIN'
            else `mat`.`CODIGO` end) AS `CODIGO`,
       `mat`.`TOTAL_QUESTOES`        AS `TOTAL_QUESTOES`,
       `mat`.`DATA_UPD`              AS `ATUALIZAÇÃO`,
       `mat`.`TIPO_ENSINO`           AS `TIPO_ENSINO`,
       `mat`.`PUB`                   AS `PUBLICADO`
from `superpro`.`SPRO_MATERIA_QUESTAO` `mat`;

