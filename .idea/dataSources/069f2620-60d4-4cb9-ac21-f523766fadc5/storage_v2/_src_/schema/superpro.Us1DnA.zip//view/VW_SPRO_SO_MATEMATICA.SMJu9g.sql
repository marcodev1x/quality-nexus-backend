create definer = admin@`%` view VW_SPRO_SO_MATEMATICA as
select `TB1`.`ID_CLIENTE`                                                                       AS `ID_CLIENTE`,
       `TB1`.`DATA_REGISTRO`                                                                    AS `DATA_REGISTRO`,
       `TB1`.`NOME_PRINCIPAL`                                                                   AS `NOME_PRINCIPAL`,
       `TB1`.`EMAIL`                                                                            AS `EMAIL`,
       (select max(`TB`.`DATA_REGISTRO`)
        from `superpro`.`SPRO_CREDITO_CONSOLIDADO` `TB`
        where (`TB`.`ID_CLIENTE` = `TB1`.`ID_CLIENTE`))                                         AS `DATA_ULTIMA_COMPRA`,
       (select count(0)
        from `superpro`.`SPRO_CREDITO_CONSOLIDADO` `TB_CRED`
        where ((`TB_CRED`.`ID_CLIENTE` = `TB1`.`ID_CLIENTE`) and (`TB_CRED`.`NUM_PEDIDO` > 0))) AS `TOTAL_PEDIDOS`,
       (select `TB`.`VALOR_TOTAL`
        from `superpro`.`SPRO_ECOMM_PEDIDO` `TB`
        where (`TB`.`NUM_PEDIDO` = (select `TB_NUM`.`NUM_PEDIDO`
                                    from `superpro`.`SPRO_CREDITO_CONSOLIDADO` `TB_NUM`
                                    where ((`TB_NUM`.`ID_CLIENTE` = `TB1`.`ID_CLIENTE`) and (`TB_NUM`.`NUM_PEDIDO` > 0))
                                    order by `TB_NUM`.`DATA_REGISTRO` desc))
        order by `TB`.`DATA_REGISTRO` desc
        limit 1)                                                                                AS `VALOR_TOTAL`
from `superpro`.`SPRO_CLIENTE` `TB1`
where ((`TB1`.`ID_REVENDA` = 15) and (month(`TB1`.`DATA_REGISTRO`) = 11) and (year(`TB1`.`DATA_REGISTRO`) = 2016))
having (`TOTAL_PEDIDOS` = 1);

