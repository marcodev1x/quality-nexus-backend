create definer = staging@`%` view VW_SPRO_QUESTAO_MATERIA as
select `TB1`.`ID_BCO_QUESTAO`                                                                                                            AS `ID_BCO_QUESTAO`,
       `TB1`.`DATA_PUB`                                                                                                                  AS `DATA_PUB`,
       `TB1`.`FLAG`                                                                                                                      AS `FLAG`,
       `TB1`.`DATA_REGISTRO`                                                                                                             AS `DATA_REGISTRO`,
       `TB1`.`ID_FONTE_VESTIBULAR`                                                                                                       AS `ID_FONTE_VESTIBULAR`,
       `TB1`.`ANO`                                                                                                                       AS `ANO`,
       (select `TB`.`ID_MATERIA` AS `ID_MATERIA`
        from `superpro`.`SPRO_CLASSIFICACAO_QUESTAO` `TB`
        where (`TB`.`ID_BCO_QUESTAO` = `TB1`.`ID_BCO_QUESTAO`)
        limit 0,1)                                                                                                                       AS `ID_MATERIA`,
       (select `TB`.`MATERIA` AS `MATERIA`
        from `superpro`.`SPRO_MATERIA_QUESTAO` `TB`
        where (`TB`.`ID_MATERIA` = (select `TB2`.`ID_MATERIA` AS `ID_MATERIA`
                                    from `superpro`.`SPRO_CLASSIFICACAO_QUESTAO` `TB2`
                                    where (`TB2`.`ID_BCO_QUESTAO` = `TB1`.`ID_BCO_QUESTAO`)
                                    limit 0,1)))                                                                                         AS `MATERIA`,
       (select `TB`.`COMPET_HABILID` AS `COMPET_HABILID`
        from `superpro`.`SPRO_MATERIA_QUESTAO` `TB`
        where (`TB`.`ID_MATERIA` = (select `TB2`.`ID_MATERIA` AS `ID_MATERIA`
                                    from `superpro`.`SPRO_CLASSIFICACAO_QUESTAO` `TB2`
                                    where (`TB2`.`ID_BCO_QUESTAO` = `TB1`.`ID_BCO_QUESTAO`)
                                    limit 0,1)))                                                                                         AS `COMPET_HABILID`,
       (select `TB`.`FOLDER` AS `FOLDER`
        from `superpro`.`SPRO_MATERIA_QUESTAO` `TB`
        where (`TB`.`ID_MATERIA` = (select `TB2`.`ID_MATERIA` AS `ID_MATERIA`
                                    from `superpro`.`SPRO_CLASSIFICACAO_QUESTAO` `TB2`
                                    where (`TB2`.`ID_BCO_QUESTAO` = `TB1`.`ID_BCO_QUESTAO`)
                                    limit 0,1)))                                                                                         AS `FOLDER`,
       (select `TB`.`FONTE_VESTIBULAR` AS `FONTE_VESTIBULAR`
        from `superpro`.`SPRO_FONTE_VESTIBULAR` `TB`
        where (`TB`.`ID_FONTE_VESTIBULAR` = `TB1`.`ID_FONTE_VESTIBULAR`))                                                                AS `FONTE_VESTIBULAR`,
       (select `TB`.`SIGLA` AS `SIGLA`
        from `superpro`.`SPRO_UF` `TB`
        where (`TB`.`ID_UF` = (select `TB2`.`ID_UF` AS `ID_UF`
                               from `superpro`.`SPRO_FONTE_VESTIBULAR` `TB2`
                               where (`TB2`.`ID_FONTE_VESTIBULAR` = `TB1`.`ID_FONTE_VESTIBULAR`)
                               limit 0,1)))                                                                                              AS `UF`,
       (select `TB`.`REGIAO` AS `REGIAO`
        from `superpro`.`SPRO_REGIAO` `TB`
        where (`TB`.`ID_REGIAO` = (select `TB_UF`.`ID_REGIAO` AS `ID_REGIAO`
                                   from `superpro`.`SPRO_UF` `TB_UF`
                                   where (`TB_UF`.`ID_UF` = (select `TB_FONTE`.`ID_UF` AS `ID_UF`
                                                             from `superpro`.`SPRO_FONTE_VESTIBULAR` `TB_FONTE`
                                                             where (`TB_FONTE`.`ID_FONTE_VESTIBULAR` = `TB1`.`ID_FONTE_VESTIBULAR`)))))) AS `REGIAO`
from `superpro`.`SPRO_BCO_QUESTAO` `TB1`
where (`TB1`.`DATA_PUB` is not null);

