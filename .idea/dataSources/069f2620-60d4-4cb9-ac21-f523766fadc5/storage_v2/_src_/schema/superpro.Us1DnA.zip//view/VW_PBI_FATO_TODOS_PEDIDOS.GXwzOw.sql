create definer = powerbi@`%` view VW_PBI_FATO_TODOS_PEDIDOS as
select `sep`.`ID_CLIENTE`                                                         AS `ID_CLIENTE`,
       (coalesce(`sep`.`VALIDADE_CREDITOS`, 0) + coalesce(`sep`.`MESES_ADIC`, 0)) AS `VALIDADE`,
       `spc`.`ID_PLANO_CONSUMO`                                                   AS `ID_PLANO_CONSUMO`,
       `sep`.`DATA_REGISTRO`                                                      AS `DATA_REGISTRO`,
       `sep`.`DATA_ALTERADO`                                                      AS `DATA_ALTERADO`
from ((((`superpro`.`SPRO_ECOMM_PEDIDO` `sep` join `superpro`.`SPRO_VW_CLIENTE_VALIDO` `sc`
         on ((`superpro`.`sc`.`ID_CLIENTE` = `sep`.`ID_CLIENTE`))) join `superpro`.`SPRO_CREDITO_CONSOLIDADO` `scc`
        on ((`scc`.`NUM_PEDIDO` = `sep`.`NUM_PEDIDO`))) left join `superpro`.`SPRO_PRECO_PLANO` `spp`
       on ((`spp`.`ID_PRECO_PLANO` = `sep`.`ID_PLANO`))) left join `superpro`.`SPRO_PLANO_CONSUMO` `spc`
      on ((`spc`.`ID_PLANO_CONSUMO` = `spp`.`ID_PLANO_CONSUMO`)))
where ((`sep`.`ID_STATUS_LOJA` = 1) and (`scc`.`OPERACAO` = 'C') and (`sep`.`DATA_REGISTRO` is not null) and
       (`sep`.`NUM_PEDIDO_PAI` is null) and
       ((not (regexp_like(`sep`.`DESCR_PRODUTO`, 'parc[.]|parc|paracela|pacela|parcela'))) or
        (`sep`.`DESCR_PRODUTO` is null)));

