create
    definer = admin@`%` function fcLocalizarMateriasDoUsuario(ID_USER_ int, DATA_INI_ char(10)) returns char(255)
BEGIN
	# 23/05/2014
	# Localiza as matérias já utilizadas pelo ID_USER informado, 
	# a partir de seu histórico de consumo.
	# A contagem ocorre em todo o consumo do usuário, desde sempre,
	# não importando se o usuário fez alguma compra ou recebeu créditos para degustação, 
	# se a assinatura está vencida ou se foi interrompida.
	# Desde que exista consumo, as questões utilizadas serão consideradas.
	#
	# @author Claudio Rubens Silva Filho

	DECLARE MATERIAS CHAR(255);

	# Carrega a string de questões de cada registro localizado em SPRO_HISTORICO_GERADOC, separando cada 
	# questão em um novo registro na tabela SPRO_USER_REL_MATERIA_HELP.
	
	REPLACE INTO SPRO_USER_REL_MATERIA_HELP
	(
	SELECT
		ID_LOGIN,
		SUBSTRING_INDEX(SUBSTRING_INDEX(ITENS_SELECIONADOS, ',', n.digit+1), ',', -1) ID_BCO_QUESTAO
	FROM
		SPRO_HISTORICO_GERADOC
		INNER JOIN
		# Quantidade de linhas geradas pelo do ID atual
		(
		SELECT @digit := @digit + 1 as digit
		FROM SPRO_HISTORICO_GERADOC t, (SELECT @digit := -1) r WHERE t.ID_LOGIN = ID_USER_		
		AND DATE(t.DATA_REGISTRO) >= DATA_INI_
		) n
		ON LENGTH(REPLACE(ITENS_SELECIONADOS, ',' , '')) <= LENGTH(ITENS_SELECIONADOS)-n.digit
	WHERE ID_LOGIN = ID_USER_ AND DATE(SPRO_HISTORICO_GERADOC.DATA_REGISTRO) >= DATA_INI_
	ORDER BY
		ID_LOGIN,
		n.digit
	);

	# Localiza/grava as matérias localizadas a partir do consumo do usuário atual.
	REPLACE INTO SPRO_USER_REL_MATERIA (
		SELECT ID_USER_, ID_MATERIA, MATERIA, TOTAL_Q, NOW() FROM (
			SELECT DISTINCT ID_BCO_QUESTAO, ID_MATERIA, MATERIA, COUNT(ID_BCO_QUESTAO) AS TOTAL_Q FROM (
				SELECT DISTINCT ID_BCO_QUESTAO, ID_MATERIA, MATERIA FROM (
						SELECT ID_BCO_QUESTAO, ID_MATERIA, MATERIA FROM SPRO_BCO_QUESTAO_MEMORY TB1 INNER JOIN SPRO_USER_REL_MATERIA_HELP TB2 USING (ID_BCO_QUESTAO)
						WHERE TB2.ID_USER = ID_USER_ GROUP BY TB1.ID_BCO_QUESTAO, ID_MATERIA ORDER BY ID_MATERIA ASC 
				) AS TB_GROUP_QUESTAO GROUP BY ID_BCO_QUESTAO
			) AS TB_GROUP_MATERIA GROUP BY ID_MATERIA
		) AS TB_INSERT
	);

	# Localiza as matérias do usuário atual
	SELECT GROUP_CONCAT(MATERIA,'=',TOTAL_Q) INTO MATERIAS FROM SPRO_USER_REL_MATERIA WHERE ID_USER = ID_USER_;

	# Limpa a tabela de ajuda usada na function atual
	DELETE FROM SPRO_USER_REL_MATERIA_HELP WHERE ID_USER = ID_USER_;
	DELETE FROM SPRO_USER_REL_MATERIA WHERE ID_USER = ID_USER_;
	# Retorna uma string no formato materia1=x,materia2=x...
	# Onde x é o total de questões encontradas em cada matéria.
	RETURN MATERIAS;
END;

