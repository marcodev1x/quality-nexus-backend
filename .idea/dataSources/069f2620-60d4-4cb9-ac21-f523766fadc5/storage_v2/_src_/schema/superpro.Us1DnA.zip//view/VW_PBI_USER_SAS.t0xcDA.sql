create definer = admin@`%` view VW_PBI_USER_SAS as
select `su`.`ID_SAS_USER`                                   AS `ID_SAS_USER`,
       `su`.`ID_USUARIO_SAS`                                AS `ID_USUARIO_SAS`,
       `su`.`ESCOLA`                                        AS `ESCOLA`,
       `su`.`EMAIL`                                         AS `EMAIL`,
       `SPLIT_STR`(`SPLIT_STR`(`su`.`OBS`, ',', 2), '=', 2) AS `LIMITE`,
       `su`.`DATA_REGISTRO`                                 AS `DATA_REGISTRO`
from `superpro`.`SPRO_SAS_USER` `su`;

