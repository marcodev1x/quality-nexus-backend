create definer = admin@`%` view VW_PBI_DIM_DIVISAO as
select `dq`.`ID_DIVISAO` AS `ID_DIVISAO`, `dq`.`DIVISAO` AS `DIVISAO`
from `superpro`.`SPRO_DIVISAO_QUESTAO` `dq`;

