create definer = staging@`%` view VW_PBI_DIM_CLIENTE_VALIDO as
select `SC`.`ID_CLIENTE`                                    AS `ID_CLIENTE`,
       `SC`.`NOME_PRINCIPAL`                                AS `NOME`,
       `SC`.`SOBRENOME`                                     AS `SOBRENOME`,
       `SC`.`APELIDO`                                       AS `APELIDO`,
       `SC`.`SEXO`                                          AS `SEXO`,
       `SC`.`EMAIL`                                         AS `EMAIL`,
       concat(`SC`.`DDD_CELULAR`, ' ', `SC`.`FONE_CELULAR`) AS `CELULAR`,
       concat(`SC`.`DDD_RESID`, ' ', `SC`.`FONE_RESID`)     AS `TELEFONE`,
       `SC`.`ANIVERSARIO`                                   AS `NASCIMENTO`,
       `SC`.`PF_PJ`                                         AS `PF_PJ`,
       `SC`.`CPF_CNPJ`                                      AS `CPF_CNPJ`,
       `SC`.`RAZAO_SOCIAL`                                  AS `RAZAO_SOCIAL`,
       `SC`.`ID_MATRIZ`                                     AS `ID_MATRIZ`,
       `SC`.`ID_FILIAL`                                     AS `ID_FILIAL`,
       `SC`.`ID_AUTH_FUNCAO`                                AS `ID_AUTH_FUNCAO`,
       (case
            when (((`SC`.`ID_AUTH_PERFIL` = 2) or (`SC`.`ID_AUTH_PERFIL` = 0) or (`SC`.`ID_AUTH_PERFIL` is null)) and
                  (exists(select 1
                          from (`superpro`.`SPRO_ECOMM_PEDIDO` `TB1` join `superpro`.`SPRO_VW_PRECO_PLANO` `SVPP`
                                on ((`superpro`.`SVPP`.`ID_PRECO_PLANO` = `TB1`.`ID_PLANO`)))
                          where ((`superpro`.`SVPP`.`CODIGO_PLANO` = 'PRO') and
                                 (`TB1`.`ID_CLIENTE` = `SC`.`ID_CLIENTE`))) or ((select `TB2`.`ID_AUTH_PERFIL`
                                                                                 from `superpro`.`SPRO_CLIENTE` `TB2`
                                                                                 where (`TB2`.`ID_CLIENTE` = `SC`.`ID_MATRIZ`)) =
                                                                                6) or ((select `TB3`.`ID_AUTH_PERFIL`
                                                                                        from `superpro`.`SPRO_CLIENTE` `TB3`
                                                                                        where (`TB3`.`ID_CLIENTE` =
                                                                                               (select `TB4`.`ID_MATRIZ`
                                                                                                from `superpro`.`SPRO_CLIENTE` `TB4`
                                                                                                where (`TB4`.`ID_CLIENTE` = `SC`.`ID_MATRIZ`)))) =
                                                                                       9) or regexp_like(
                           (select `TB5`.`NOME_PRINCIPAL`
                            from `superpro`.`SPRO_CLIENTE` `TB5`
                            where (`TB5`.`ID_CLIENTE` = `SC`.`ID_MATRIZ`)),
                           'COL.*GIO|^CEI |VESTIBULAR|ESCOLA|EDUCACIONAL|EDUCAÇÃO|ENSINO|^E[.] M[.] ') or
                   (regexp_like(`SC`.`APELIDO`, 'PROF') and (not (regexp_like(`SC`.`APELIDO`, 'ESCOLA|ENSINO')))) or
                   (regexp_like(`SC`.`EMAIL`, 'PROF') and (not (regexp_like(`SC`.`APELIDO`, '@SUPERPROFESSOR')))) or
                   ((`SC`.`ID_MATRIZ` in (271755, 221834, 429117, 66815, 639161, 877550)) and
                    (not (regexp_like(`SC`.`NOME_PRINCIPAL`,
                                      'COL.*GIO|^CEI |VESTIBULAR|ESCOLA|EDUCACIONAL|EDUCAÇÃO|ENSINO|^E[.] M[.] '))))))
                then 3
            when (((`SC`.`ID_AUTH_PERFIL` = 2) or (`SC`.`ID_AUTH_PERFIL` = 0) or (`SC`.`ID_AUTH_PERFIL` is null)) and
                  (exists(select 1
                          from (`superpro`.`SPRO_ECOMM_PEDIDO` `TB6` join `superpro`.`SPRO_VW_PRECO_PLANO` `SVPP`
                                on ((`superpro`.`SVPP`.`ID_PRECO_PLANO` = `TB6`.`ID_PLANO`)))
                          where ((`superpro`.`SVPP`.`CODIGO_PLANO` = 'ESC') and
                                 (`TB6`.`ID_CLIENTE` = `SC`.`ID_CLIENTE`))) or exists(select 1
                                                                                      from `superpro`.`SPRO_CLIENTE` `TB7`
                                                                                      where (`TB7`.`ID_MATRIZ` = `SC`.`ID_CLIENTE`)) or
                   ((select `TB8`.`ID_AUTH_PERFIL`
                     from `superpro`.`SPRO_CLIENTE` `TB8`
                     where (`TB8`.`ID_CLIENTE` = `SC`.`ID_MATRIZ`)) = 9) or (regexp_like(`SC`.`NOME_PRINCIPAL`,
                                                                                         'COL.*GIO|^CEI |VESTIBULAR|ESCOLA|EDUCACIONAL|EDUCAÇÃO|ENSINO|^E[.] M[.] ') and
                                                                             (not (regexp_like(`SC`.`NOME_PRINCIPAL`, 'ADM |ADMIN|PROF'))) and
                                                                             (`SC`.`PF_PJ` = 'PJ')) or
                   ((`SC`.`ID_MATRIZ` in (271755, 221834, 429117, 66815, 639161, 877550)) and
                    regexp_like(`SC`.`NOME_PRINCIPAL`,
                                'COL.*GIO|^CEI |VESTIBULAR|ESCOLA|EDUCACIONAL|EDUCAÇÃO|ENSINO|^E[.] M[.] ')))) then 6
            when ((`SC`.`ID_MATRIZ` in (271755, 221834, 429117, 66815, 639161, 877550)) and
                  regexp_like(`SC`.`NOME_PRINCIPAL`,
                              'COL.*GIO|^CEI |VESTIBULAR|ESCOLA|EDUCACIONAL|EDUCAÇÃO|ENSINO|^E[.] M[.] ')) then 6
            when ((`SC`.`ID_MATRIZ` in (271755, 221834, 429117, 66815, 639161, 877550)) and
                  (not (regexp_like(`SC`.`NOME_PRINCIPAL`,
                                    'COL.*GIO|^CEI |VESTIBULAR|ESCOLA|EDUCACIONAL|EDUCAÇÃO|ENSINO|^E[.] M[.] '))))
                then 3
            when (((`SC`.`ID_AUTH_PERFIL` = 7) or (`SC`.`ID_AUTH_PERFIL` = 2) or (`SC`.`ID_AUTH_PERFIL` = 0) or
                   (`SC`.`ID_AUTH_PERFIL` is null)) and (`SC`.`ID_MATRIZ` = 0) and (not exists(select 1
                                                                                               from `superpro`.`SPRO_CREDITO_CONSOLIDADO` `TB9`
                                                                                               where (`TB9`.`ID_CLIENTE` = `SC`.`ID_CLIENTE`))) and
                  (not exists(select 1
                              from `superpro`.`SPRO_ECOMM_PEDIDO` `TB10`
                              where (`TB10`.`ID_CLIENTE` = `SC`.`ID_CLIENTE`)))) then 4
            when (((`SC`.`ID_AUTH_PERFIL` = 0) or (`SC`.`ID_AUTH_PERFIL` = 2) or (`SC`.`ID_AUTH_PERFIL` is null)) and
                  (not (regexp_like(`SC`.`NOME_PRINCIPAL`,
                                    'COL.*GIO|^CEI |VESTIBULAR|ESCOLA|EDUCACIONAL|EDUCAÇÃO|ENSINO|^E[.] M[.] '))) and
                  ((`SC`.`PF_PJ` = 'PF') or (`SC`.`PF_PJ` is null)) and exists(select 1
                                                                               from `superpro`.`SPRO_CREDITO_CONSOLIDADO` `TB11`
                                                                               where ((`TB11`.`NUM_PEDIDO` = 0) and
                                                                                      (`SC`.`ID_CLIENTE` = `TB11`.`ID_CLIENTE`) and
                                                                                      (`TB11`.`OPERACAO` = 'C') and
                                                                                      (`TB11`.`ID_REG_SALDO_ANT` = 0))))
                then 3
            when (((`SC`.`ID_AUTH_PERFIL` = 0) or (`SC`.`ID_AUTH_PERFIL` = 2) or (`SC`.`ID_AUTH_PERFIL` is null)) and
                  regexp_like(`SC`.`NOME_PRINCIPAL`,
                              'COL.*GIO|^CEI |VESTIBULAR|ESCOLA|EDUCACIONAL|EDUCAÇÃO|ENSINO|^E[.] M[.] ') and
                  (not (regexp_like(`SC`.`NOME_PRINCIPAL`, 'ADM |ADMIN|PROF'))) and exists(select 1
                                                                                           from `superpro`.`SPRO_CREDITO_CONSOLIDADO` `TB12`
                                                                                           where ((`TB12`.`NUM_PEDIDO` = 0) and
                                                                                                  (`SC`.`ID_CLIENTE` = `TB12`.`ID_CLIENTE`) and
                                                                                                  (`TB12`.`OPERACAO` = 'C') and
                                                                                                  (`TB12`.`ID_REG_SALDO_ANT` = 0))) and
                  (`SC`.`PF_PJ` = 'PJ')) then 6
            else `SC`.`ID_AUTH_PERFIL` end)                 AS `ID_AUTH_PERFIL`,
       `SC`.`COD_POSTAL`                                    AS `CEP`,
       `SC`.`LOGRADOURO`                                    AS `LOGRADOURO`,
       `SC`.`NUMERO`                                        AS `NUMERO`,
       `SC`.`BAIRRO`                                        AS `BAIRRO`,
       `SC`.`CIDADE`                                        AS `CIDADE`,
       `SC`.`UF`                                            AS `UF`,
       `SC`.`PAIS`                                          AS `PAIS`,
       `SC`.`DEL`                                           AS `DELETADO`,
       `SC`.`BLOQ`                                          AS `BLOQUEADO`,
       `SC`.`DATA_REGISTRO`                                 AS `DATA_CADASTRO`,
       `SC`.`DATA_UPD`                                      AS `DATA_ATUALIZADO`
from `superpro`.`SPRO_CLIENTE` `SC`
where (`SC`.`PBI_VALIDO` = 1);

