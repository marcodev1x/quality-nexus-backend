create definer = admin@`%` trigger SmlAfterInsert
    before insert
    on SPRO_SMLN_RELATORIO_ALUNO
    for each row
BEGIN
	SELECT FINALIZADO_POR_ID, ID_LST_USUARIO, NUM_QUESTOES_DINAMICAS, DATA_REGISTRO
	INTO @finalizado, @idLstUsuario, @numQuestoesDinamicas, @abertoEm
	FROM SPRO_LST_USUARIO WHERE ID_HISTORICO_GERADOC = NEW.ID_HISTORICO_GERADOC
	AND ID_CLIENTE = NEW.ID_ALUNO;

	SET NEW.ABERTO_EM = @abertoEm;
	SET NEW.ID_LST_USUARIO = @idLstUsuario;
	SET @acertos = 0; 
	SET @acertosPercent = 0;

	IF (@idLstUsuario > 0) THEN
	IF (@finalizado IS NOT NULL) THEN
		SET NEW. CONCLUIDO = 'S';
		
		IF (@idLstUsuario > 0) THEN
			# Localiza a data/hora em que a prova foi finalizada
			SELECT DATA_REGISTRO INTO @concluidoEm FROM SPRO_LST_HIST_RESPOSTA WHERE
			 ID_LST_USUARIO =  @idLstUsuario LIMIT 1;
	
			SET NEW.CONCLUIDO_EM = @concluidoEm;

			#Calcula o score do aluno
			SELECT COUNT(1) INTO @acertos FROM SPRO_LST_HIST_RESPOSTA WHERE 
			RESPOSTA = GABARITO AND ID_LST_USUARIO =  @idLstUsuario;
				
			IF (@acertos > 0 AND @numQuestoesDinamicas > 0) THEN
 				SET @acertosPercent =(@acertos / @numQuestoesDinamicas) * 100;
			ELSE 
				SET @acertos = 0;
			END IF;
		END IF;
	ELSE 
		SET NEW.CONCLUIDO = 'N';
	END IF;
	END IF;

	SET NEW.ACERTOS = @acertos;
	SET NEW.TOTAL_Q = @numQuestoesDinamicas;
	SET NEW.ACERTOS_PERCENT = @acertosPercent;
END;

