create
    definer = admin@`%` function delAluno(LST_ID_ALUNO text) returns text
BEGIN
	# 29/06/2015
	# Exclui um aluno
	# @author Claudio Rubens Silva Filho
	DECLARE OUT_STR TEXT;
	DECLARE TOTAL_CAD INT;

	SET TOTAL_CAD = 0;
	SET OUT_STR = '';

	IF (LENGTH(LST_ID_ALUNO) > 0) THEN	

		SELECT COUNT(*) INTO TOTAL_CAD FROM SPRO_CLIENTE WHERE ID_CLIENTE IN (LST_ID_ALUNO);
		IF (TOTAL_CAD > 0) THEN
				SET OUT_STR = CONCAT('Cadastros: ',TOTAL_CAD);
				# Exclui da tabela de cadastro:
				DELETE FROM SPRO_CLIENTE WHERE ID_CLIENTE IN (LST_ID_ALUNO);
				DELETE FROM SPRO_USER WHERE ID_USER IN (LST_ID_ALUNO);

				# Exclui os resultados de listas, se houver:
				DELETE FROM SPRO_LST_HIST_RESPOSTA WHERE ID_LST_USUARIO IN (
					SELECT ID_LST_USUARIO FROM SPRO_LST_USUARIO WHERE ID_CLIENTE IN (LST_ID_ALUNO)
				);

				# Exclui da tabela que relaciona alunos com listas:
				DELETE FROM SPRO_LST_USUARIO WHERE ID_CLIENTE IN (LST_ID_ALUNO);

				# Exclui relacionamento do aluno com turma:
				DELETE FROM SPRO_TURMA_ALUNO WHERE ID_CLIENTE IN (LST_ID_ALUNO);

				# Exclui histórico de acesso
				DELETE FROM SPRO_AUTH_HIST_ACESSO WHERE ID_LOGIN IN (LST_ID_ALUNO);
				SET OUT_STR = CONCAT(OUT_STR,', cadatros e registros dependentes excluídos.');
		ELSE 
				SET OUT_STR = "Nenhum registro foi localizado.";
		END IF;
	END IF;
	RETURN OUT_STR;
END;

