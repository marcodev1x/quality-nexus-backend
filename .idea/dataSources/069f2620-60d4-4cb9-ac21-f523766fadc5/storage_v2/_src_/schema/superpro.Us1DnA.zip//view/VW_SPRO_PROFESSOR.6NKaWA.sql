create definer = staging@`%` view VW_SPRO_PROFESSOR as
select `TB`.`ID_CLIENTE`                                        AS `ID_PROFESSOR`,
       `TB`.`ID_AUTH_FUNCAO`                                    AS `ID_AUTH_FUNCAO`,
       ifnull(`TB`.`DEL`, 0)                                    AS `DEL`,
       `TB`.`ID_MATRIZ`                                         AS `ID_MATRIZ`,
       `TB`.`ID_FILIAL`                                         AS `ID_FILIAL`,
       `TB`.`NOME_PRINCIPAL`                                    AS `PROFESSOR`,
       `TB`.`APELIDO`                                           AS `APELIDO`,
       `TB`.`CPF_CNPJ`                                          AS `CPF`,
       `TB`.`SENHA`                                             AS `SENHA`,
       `TB`.`EMAIL`                                             AS `EMAIL`,
       `TB`.`DATA_REGISTRO`                                     AS `DATA_REGISTRO`,
       `TB`.`BLOQ`                                              AS `BLOQ`,
       `TB`.`LOGIN`                                             AS `LOGIN`,
       date_format(`TB`.`DATA_REGISTRO`, '%d/%m/%Y Ãƒ s %H:%i') AS `DATA_REGISTRO_BR`,
       (select count(0) AS `COUNT(*)`
        from `superpro`.`SPRO_AUTH_HIST_ACESSO` `TB1`
        where (`TB1`.`ID_LOGIN` = `TB`.`ID_CLIENTE`))           AS `TOTAL_ACESSO`,
       0                                                        AS `CREDITOS`
from `superpro`.`SPRO_CLIENTE` `TB`
where ((ifnull(`TB`.`DEL`, 0) = 0) and (`TB`.`PF_PJ` = 'PF') and (`TB`.`ID_AUTH_PERFIL` = 3));

