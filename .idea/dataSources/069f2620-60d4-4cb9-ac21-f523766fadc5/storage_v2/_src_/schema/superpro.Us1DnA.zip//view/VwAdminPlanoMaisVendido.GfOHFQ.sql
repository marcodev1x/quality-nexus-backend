create definer = admin@`%` view VwAdminPlanoMaisVendido as
select `TB1`.`ID_PLANO`                                               AS `ID_PLANO`,
       (select `TB2`.`TIPO_PLANO`
        from `superpro`.`SPRO_PRECO_PLANO` `TB2`
        where (`TB2`.`ID_PRECO_PLANO` = `TB1`.`ID_PLANO`))            AS `Name_exp_2`,
       (select `superpro`.`TB2`.`PLANO_CONSUMO`
        from `superpro`.`VW_SPRO_PRECO_PLANO` `TB2`
        where (`superpro`.`TB2`.`ID_PRECO_PLANO` = `TB1`.`ID_PLANO`)) AS `PROF_ESC`,
       `TB1`.`CREDITOS`                                               AS `CREDITOS`,
       `TB1`.`VALIDADE_CREDITOS`                                      AS `VALIDADE_CREDITOS`,
       count(1)                                                       AS `TOTAL`
from `superpro`.`SPRO_ECOMM_PEDIDO` `TB1`
where ((year(`TB1`.`DATA_REGISTRO`) >= 2018) and (`TB1`.`ID_STATUS_LOJA` = 1))
group by `TB1`.`ID_PLANO`, `TB1`.`CREDITOS`, `TB1`.`VALIDADE_CREDITOS`
having (`TOTAL` > 1)
order by `TOTAL` desc, `TB1`.`CREDITOS`, `TB1`.`VALIDADE_CREDITOS`;

