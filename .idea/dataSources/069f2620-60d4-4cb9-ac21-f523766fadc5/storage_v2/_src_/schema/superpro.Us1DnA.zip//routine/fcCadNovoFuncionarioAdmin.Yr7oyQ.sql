create
    definer = admin@`%` function fcCadNovoFuncionarioAdmin(ID_FUNC int, PSWD_ADMIN char(15)) returns longtext
BEGIN
	# Cadastra o acesso de um novo funcionário
	DECLARE MSG, PASSWD_MD5, HASH_USER, NOME_USER, EMAIL_USER  TEXT;
	DECLARE CHECK_ID_FUNC, NEW_ID_INTRA_USER INT;

	# Localiza o ID informado na tabela SPRO_CLIENTE
	SELECT HASH,ID_CLIENTE, NOME_PRINCIPAL, EMAIL INTO HASH_USER,CHECK_ID_FUNC, NOME_USER, EMAIL_USER 
	FROM SPRO_CLIENTE WHERE ID_CLIENTE = ID_FUNC;

	IF (CHECK_ID_FUNC > 0) THEN		
		# Cadastra as permissões do usuário (permissão padrão da área comercial)
		REPLACE INTO SPRO_ADM_PERMISSAO (ID_CLIENTE, PERMISSAO, DATA_REGISTRO) 
		VALUES(ID_FUNC, 'PEDIDOS,DISTRIB_CRED,CAD_EM_LOTE', NOW());
		
		# Cadastra a senha
		SELECT MD5(TRIM(PSWD_ADMIN)) INTO PASSWD_MD5 FROM DUAL;
		IF (LENGTH(PASSWD_MD5) >= 32) THEN
			REPLACE INTO SPRO_SYS_CONFIG_ADMIN (USUARIO, EMAIL, PASSWD, EXPED_HR_INI, EXPED_HR_FIM)
			VALUES (NOME_USER, EMAIL_USER, PASSWD_MD5, '08:00:00','18:00:00');

			SET MSG = "Acesso ADMIN criado com sucesso!";
		ELSE 
			SET MSG = "Nâo foi possível finalizar o cadastro corretamene. Ocorreu um erro ao criptografar a senha informada.";
		END IF;	

		# Cadastra uma nova conta na intranet
		REPLACE INTO SPRO_INTRA_USER (HASH,NOME,USUARIO,EMAIL,PASSWD,PERFIL,SIGLA,EXPED_HR_INI,EXPED_HR_FIM,DATA_REGISTRO) 
		VALUES(HASH_USER,NOME_USER,NOME_USER,EMAIL_USER,PASSWD_MD5,'USER','','08:30:00','17:30:59',NOW());

		SET NEW_ID_INTRA_USER = LAST_INSERT_ID();
		IF (NEW_ID_INTRA_USER > 0) THEN
			# Cadastra as permissões do usuário atual - usado como padrão o perfil da área comercial
			REPLACE INTO SPRO_INTRA_USER_REL_PERMISSAO (ID_INTRA_USER, PERMISSOES, DATA_REGISTRO)
			VALUES(NEW_ID_INTRA_USER, 'POS_VENDA', NOW());
		END IF;
	ELSE
		SET MSG = "Nenhum ID_CLIENTE referente à conta do funcionário foi localizado. Verifique se o cadastro do acesso na tabela SPRO_CLIENTE já foi feito.";
	END IF;
	RETURN MSG;
END;

