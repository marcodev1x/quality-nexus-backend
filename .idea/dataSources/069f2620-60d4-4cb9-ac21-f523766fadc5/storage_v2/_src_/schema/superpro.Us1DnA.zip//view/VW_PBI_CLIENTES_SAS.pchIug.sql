create definer = admin@`%` view VW_PBI_CLIENTES_SAS as
select `su`.`ID_USER`       AS `ID_CLIENTE`,
       `su`.`NOME`          AS `NOME_PRINCIPAL`,
       `su`.`ID_MATRIZ`     AS `ID_MATRIZ`,
       `su`.`LOGIN`         AS `LOGIN`,
       `su`.`EMAIL`         AS `EMAIL`,
       `su`.`DATA_REGISTRO` AS `DATA_REGISTRO`,
       `su`.`BLOQUEADO_EM`  AS `BLOQUEADO_EM`,
       `su`.`EXCLUIDO_EM`   AS `EXCLUIDO_EM`
from `superpro`.`SPRO_USER` `su`
where (`su`.`ID_MATRIZ` in (66815, 877547, 890196));

