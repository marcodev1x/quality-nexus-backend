create definer = admin@`%` trigger vincularProvasOnInsert
    after insert
    on SPRO_SML_ESCOLA_ADESAO
    for each row
BEGIN
     DECLARE idHistoricoGeraDoc, numQuestoes, codLista INTEGER DEFAULT 0;
     DECLARE nomeLista CHAR(100);
     DECLARE finished INTEGER DEFAULT 0;
     DECLARE listasCursor CURSOR FOR 
            SELECT ID_HISTORICO_GERADOC, NUM_QUESTOES, NOME_ARQ, COD_LISTA 
            FROM SPRO_HISTORICO_GERADOC 
            WHERE FORMATO = 'LST_EVOLUCIONAL' AND LISTA_ATIVA = 1; 
     DECLARE CONTINUE HANDLER FOR NOT FOUND SET finished = 1;
	
     OPEN listasCursor;                                
     getListas: LOOP
             FETCH listasCursor INTO idHistoricoGeraDoc, numQuestoes, nomeLista, codLista;
             IF finished = 1 THEN 
                     LEAVE getListas;
            END IF;       
         
            
           REPLACE INTO SPRO_SML_SIMULADO_REL_ESCOLA 
          (ID_SML_ESCOLA_ADESAO, ID_ESCOLA, TOTAL_QUESTOES, DESCRICAO, ID_HISTORICO_GERADOC, CODIGO_PROVA, DATA_REGISTRO) 
          VALUES(NEW.ID_SML_ESCOLA_ADESAO, NEW.ID_CLIENTE, numQuestoes, nomeLista, idHistoricoGeraDoc, codLista, NOW());                                    
     
     END LOOP getListas;
     CLOSE listasCursor;
END;

