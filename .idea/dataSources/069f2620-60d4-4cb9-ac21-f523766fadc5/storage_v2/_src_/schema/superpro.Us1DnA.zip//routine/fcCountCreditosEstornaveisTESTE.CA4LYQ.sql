create
    definer = admin@`%` function fcCountCreditosEstornaveisTESTE(ID_MATRIZ_IN int, NIVEL_CALC varchar(1)) returns int
BEGIN

	DECLARE ULT_SALDO_MATRIZ INT default 0;

	DECLARE VAR_VENCIMENTO DATE;

	DECLARE VAR_PERFIL int;

	DECLARE saldoEstornavelEsc int default 0;

	DECLARE saldoEstornavelProf int default 0;

	DECLARE saldoEstornavel int default 0;



	SELECT ID_AUTH_PERFIL INTO VAR_PERFIL FROM SPRO_CLIENTE WHERE ID_CLIENTE = ID_MATRIZ_IN;



	# Localiza dados da última compra da Mantenedora

	SELECT SALDO_FINAL, VENCIMENTO INTO ULT_SALDO_MATRIZ, VAR_VENCIMENTO

	FROM SPRO_CREDITO_CONSOLIDADO 

	WHERE ID_CLIENTE = ID_MATRIZ_IN AND VENCIMENTO >= DATE(NOW())

	ORDER BY VENCIMENTO DESC LIMIT 1;



	IF (ULT_SALDO_MATRIZ = 0) THEN

		RETURN 0;

	END IF;



	# Se for mantenedora

	IF (VAR_PERFIL = 9) THEN		

		#Soma o saldo final de Escolas

		SELECT SUM(fcCalcSaldo(ID_CLIENTE)) INTO saldoEstornavelEsc 

		FROM SPRO_CLIENTE 

		WHERE ID_MATRIZ = ID_MATRIZ_IN;

	

		IF (saldoEstornavelEsc IS NULL) THEN

			SET saldoEstornavelEsc = 0;

		END IF;

	END IF;



	IF (NIVEL_CALC = 'P') THEN

		# Se for mantenedora

		IF (VAR_PERFIL = 9) THEN	

			SELECT SUM(fcCalcSaldoProfEsc(ID_CLIENTE, VAR_VENCIMENTO)) INTO saldoEstornavelProf FROM SPRO_VW_CLIENTE_VALIDO 

			WHERE ID_MATRIZ IN(

				SELECT ID_USER FROM SPRO_USER 

				WHERE ID_MATRIZ = ID_MATRIZ_IN 

				OR ID_MATRIZ IN (

					SELECT ID_USER FROM SPRO_USER WHERE ID_MATRIZ = ID_MATRIZ_IN

				)				

			);

		# Se for Escola

		ELSE

			SELECT SUM(fcCalcSaldoProfEsc(ID_CLIENTE, VAR_VENCIMENTO)) INTO saldoEstornavelProf FROM SPRO_VW_CLIENTE_TEMP 

			WHERE ID_MATRIZ = ID_MATRIZ_IN;

		END IF;

	

		SET saldoEstornavel = saldoEstornavelProf;



	ELSEIF (NIVEL_CALC = 'E') THEN

		SET saldoEstornavel = saldoEstornavelEsc;	

	END IF;



	IF (saldoEstornavel < 0) THEN

		SET saldoEstornavel = 0;

	END IF;



	RETURN saldoEstornavel;

END;

