create definer = staging@`%` view VW_SPRO_ESCOLA as
select `TB`.`ID_CLIENTE`                                        AS `ID_ESCOLA`,
       `TB`.`NOME_PRINCIPAL`                                    AS `UNIDADE`,
       `TB`.`RAZAO_SOCIAL`                                      AS `ESCOLA`,
       `TB`.`CPF_CNPJ`                                          AS `CNPJ`,
       `TB`.`SENHA`                                             AS `SENHA`,
       `TB`.`EMAIL`                                             AS `EMAIL`,
       `TB`.`DATA_REGISTRO`                                     AS `DATA_REGISTRO`,
       `TB`.`BLOQ`                                              AS `BLOQ`,
       `TB`.`LOGIN`                                             AS `LOGIN`,
       date_format(`TB`.`DATA_REGISTRO`, '%d/%m/%Y Ãƒ s %H:%i') AS `DATA_REGISTRO_BR`,
       (select count(0) AS `COUNT(*)`
        from `superpro`.`SPRO_AUTH_HIST_ACESSO` `TB1`
        where (`TB1`.`ID_LOGIN` = `TB`.`ID_CLIENTE`))           AS `NUM_ACESSOS`
from `superpro`.`SPRO_CLIENTE` `TB`
where ((`TB`.`PF_PJ` = 'PJ') and (`TB`.`ID_AUTH_PERFIL` = 6));

