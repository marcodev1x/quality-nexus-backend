create
    definer = admin@`%` function fcTempoMedioResgateTrim(cliente int, ano int, mes_ini int, mes_fim int, data_resgate datetime) returns float
BEGIN
/*Criado por Luis Otavio*/
	
	declare dias, resgates int default 0;
	declare venc_anterior date;
	declare registro, vencimento date;
	declare inicio int default 1;
	declare fim int default 0;
	

	/*encontrando todas compras no periodo, desde o primeiro resgate. Podendo ter mais resgate nessas compras*/
	declare c cursor for 
	SELECT date(sep.DATA_REGISTRO) , scc.VENCIMENTO  
	from SPRO_CREDITO_CONSOLIDADO scc 
	join SPRO_ECOMM_PEDIDO sep
	    on sep.NUM_PEDIDO = scc.NUM_PEDIDO
	where scc.ID_CLIENTE = cliente
		and scc.OPERACAO = 'C'
		and date(sep.DATA_REGISTRO) >= date(data_resgate) 
		and date(sep.DATA_REGISTRO) <= CONCAT(ano,'-',mes_fim,'-31')
	   	and sep.ID_STATUS_LOJA = 1;
	   
	declare continue handler for not found set fim = 1;
	

	/*pegando o ultimo vencimento, antes do resgate*/
	SELECT date(max(scc.VENCIMENTO)) into venc_anterior 
	from SPRO_CREDITO_CONSOLIDADO scc 
	where scc.ID_CLIENTE = cliente 
	and scc.VENCIMENTO < date(data_resgate)
	and date(scc.DATA_REGISTRO) >= CONCAT(ano,'-',mes_ini,'-01')
	and date(scc.DATA_REGISTRO) <= CONCAT(ano,'-',mes_fim,'-31');


	if venc_anterior is null then return 0; end if;

	open c;
	
	while fim=0
	do
	fetch c into registro, vencimento;
		if fim = 0 then 
			/*if inicio = 1 then
				set venc_anterior = vencimento;
				set inicio = 0;
			else*/
				if registro > venc_anterior then
					set dias = dias + DATEDIFF(registro, venc_anterior);
					set resgates = resgates + 1;
				end if;
				
				set venc_anterior = vencimento;
			/*end if;*/
		end if;
	end while;
	
	close c;

	if resgates =0 then return 0; end if;

	/*return floor(dias/resgates);*/
	return dias/resgates;
END;

