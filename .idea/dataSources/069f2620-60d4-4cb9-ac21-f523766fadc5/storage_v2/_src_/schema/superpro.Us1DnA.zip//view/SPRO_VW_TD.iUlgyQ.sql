create definer = staging@`%` view SPRO_VW_TD as
select `TB1`.`ID_CLIENTE`                                                                  AS `ID_CLIENTE`,
       (select `TB2`.`NOME_PRINCIPAL`
        from `superpro`.`SPRO_CLIENTE` `TB2`
        where (`TB2`.`ID_CLIENTE` = `TB1`.`ID_CLIENTE`))                                   AS `NOME`,
       if(((select count(1) from `superpro`.`SPRO_TD_CADASTRO` `TB2` where (`TB2`.`ID_USER` = `TB1`.`ID_CLIENTE`)) > 0),
          'HOTSITE', 'FONE')                                                               AS `ORIGEM`,
       (select `TB2`.`NOME_PRINCIPAL`
        from `superpro`.`SPRO_CLIENTE` `TB2`
        where (`TB2`.`ID_CLIENTE` = cast(replace(`TB1`.`CUPOM`, 'ADM_', '') as unsigned))) AS `FUNC`,
       `TB1`.`SALDO_ANT`                                                                   AS `SALDO_ANT`,
       `TB1`.`CREDITO`                                                                     AS `CREDITO`,
       `TB1`.`SALDO_FINAL`                                                                 AS `SALDO_FINAL`,
       `TB1`.`VENCIMENTO`                                                                  AS `VENCIMENTO`,
       `TB1`.`CUPOM`                                                                       AS `CUPOM`,
       `TB1`.`DATA_REGISTRO`                                                               AS `DATA_REGISTRO`
from `superpro`.`SPRO_CREDITO_CONSOLIDADO` `TB1`
where (`TB1`.`MOTIVO` like 'Degusta%')
order by `TB1`.`DATA_REGISTRO` desc;

