create definer = admin@`%` view VW_SPRO_CLIENTE_TESTE as
select `superpro`.`SPRO_CLIENTE`.`ID_CLIENTE` AS `ID_CLIENTE`
from `superpro`.`SPRO_CLIENTE`
where ((`superpro`.`SPRO_CLIENTE`.`EMAIL` like '%interbits%') or
       (`superpro`.`SPRO_CLIENTE`.`EMAIL` like '%supervip%') or (`superpro`.`SPRO_CLIENTE`.`EMAIL` like '%teste%'));

