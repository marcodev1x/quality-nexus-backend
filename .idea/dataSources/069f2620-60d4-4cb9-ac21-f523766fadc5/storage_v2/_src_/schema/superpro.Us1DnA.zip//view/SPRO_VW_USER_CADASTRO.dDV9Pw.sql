create definer = admin@`%` view SPRO_VW_USER_CADASTRO as
select `TB1`.`ID_USER`     AS `ID_USER`,
       `TB1`.`PF_PJ`       AS `PF_PJ`,
       `TB1`.`CPF_CNPJ`    AS `CPF_CNPJ`,
       `TB1`.`COD_POSTAL`  AS `COD_POSTAL`,
       `TB1`.`LOGRADOURO`  AS `LOGRADOURO`,
       `TB1`.`NUMERO`      AS `NUMERO`,
       `TB1`.`COMPLEMENTO` AS `COMPLEMENTO`,
       `TB1`.`BAIRRO`      AS `BAIRRO`,
       `TB1`.`CIDADE`      AS `CIDADE`,
       `TB1`.`UF`          AS `UF`,
       `TB2`.`NOME`        AS `NOME`,
       `TB2`.`EMAIL`       AS `EMAIL`
from (`superpro`.`SPRO_USER_CADASTRO` `TB1` join `superpro`.`SPRO_USER` `TB2`)
where (`TB1`.`ID_USER` = `TB2`.`ID_USER`);

