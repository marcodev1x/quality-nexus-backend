create definer = admin@`%` view VW_PBI_DIM_FUNCAO as
select `saf`.`ID_AUTH_FUNCAO` AS `ID_AUTH_FUNCAO`, `saf`.`FUNCAO` AS `FUNCAO`, `saf`.`CODIGO` AS `CODIGO_FUNCAO`
from `superpro`.`SPRO_AUTH_FUNCAO` `saf`;

