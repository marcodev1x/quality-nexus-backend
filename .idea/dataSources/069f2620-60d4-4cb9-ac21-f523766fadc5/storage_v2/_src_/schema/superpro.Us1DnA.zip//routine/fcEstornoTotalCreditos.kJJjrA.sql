create
    definer = admin@`%` function fcEstornoTotalCreditos(idMatriz int, NivelMatriz char(10), NivelEstorno char(10)) returns int
BEGIN
	# 07/11/2016
	# Faz o estorno de créditos da matriz (pode ser uma escola ou uma mantenedora)
	# Torna a rotina de estorno em lote mais ágil, sem a necessidade de calcular o estorno de cada professor
	#
	# Recebe o idMatriz, que deve ser o ID da mantenedora ou da escola (sem vínculo com mantenedora).
	# Recebe NivelMatriz. Pode ser 'M', indicando que o idMatriz refere-se a uma mantenedora, ou 'E' indicando Escola.
	# Recebe o NivelEstorno, que pode ter os valores PROF, para estorno de professores, e ESC, para estorno de escolas
	#
	# @author Claudio Rubens Silva Filho	

	DECLARE retorno, consumoCredProf, saldoIniMatriz, SALDO_APOS_ESTORNO, idRegSaldoAnt, numPedido INT default 0;	
	DECLARE dataVencMatrizEn DATE;
	DECLARE token, dataUltimaCompraMatrizEn TEXT;
	
	SET @consumoCreditoProf := 0;
	SET @saldoAestornarProf := 0;
	SET @creditosEstornados := 0;
	SET @agora := NOW();

	SELECT MD5(CONCAT(NOW(), idMatriz)) INTO token;

	IF (idMatriz IS NULL OR idMatriz <= 0) THEN
		#Matriz inválida
		RETURN 0;
	END IF;

	# Localiza o vencimento da matriz informada
	SELECT 
	ID_CREDITO_CONSOLIDADO,SALDO_FINAL, NUM_PEDIDO, VENCIMENTO, DATA_REGISTRO 
	INTO idRegSaldoAnt, saldoIniMatriz, numPedido, dataVencMatrizEn, dataUltimaCompraMatrizEn 
	FROM SPRO_CREDITO_CONSOLIDADO 
	WHERE ID_CLIENTE = idMatriz AND VENCIMENTO >= DATE(NOW())
	ORDER BY VENCIMENTO DESC LIMIT 1;	

	IF (dataVencMatrizEn IS NULL OR dataVencMatrizEn < CURDATE() = 1) THEN
		#Matriz com assinatura vencida
		RETURN 0;
	END IF;

	# Limpa a tabela temporária usada para efetuar o estorno dos professores
	DELETE FROM SPRO_ESTORNO_CREDITO WHERE ID_MATRIZ = idMatriz;
	

	IF (NivelMatriz = 'M' AND NivelEstorno = 'PROF') THEN
				# Matriz = Mantenedora. Faz o estorno dos professores
				REPLACE INTO SPRO_ESTORNO_CREDITO (ID_MATRIZ, ID_USER, VENC_MATRIZ_EN, DATA_REGISTRO) 
				(SELECT ID_MATRIZ, ID_USER, dataVencMatrizEn, @agora FROM SPRO_USER WHERE ID_MATRIZ IN (
						SELECT ID_USER FROM SPRO_USER WHERE ID_MATRIZ = idMatriz
				));

				# Gera uma linha em CreditoConsolidado a partir da última compra - o consumo até o momento.ALTER
				# 1 - Calcula o consumo de créditos dos professores até o momento
				SELECT SUM(DEBITO) INTO @consumoCreditoProf FROM SPRO_HISTORICO_GERADOC 
				WHERE ID_LOGIN IN(
					SELECT ID_USER FROM SPRO_USER WHERE ID_MATRIZ IN (
						SELECT ID_USER FROM SPRO_USER WHERE ID_MATRIZ = idMatriz
					)				
				) AND DATA_REGISTRO >= dataUltimaCompraMatrizEn;		
	ELSEIF (NivelMatriz = 'M' AND NivelEstorno = 'ESC') THEN
				# Matriz = Mantenedora. Faz o estorno das escolas
				REPLACE INTO SPRO_ESTORNO_CREDITO (ID_MATRIZ, ID_USER, VENC_MATRIZ_EN, DATA_REGISTRO) 
				(SELECT ID_MATRIZ, ID_USER, dataVencMatrizEn, @agora FROM SPRO_USER WHERE ID_MATRIZ = idMatriz);

	ELSEIF (NivelMatriz = 'E' OR NivelEstorno = 'ESC') THEN
				# Faz o estorno dos dependentes (professor se NivelMatriz = 'E' ou escola se NivelMatriz = 'M')
				INSERT INTO SPRO_ESTORNO_CREDITO_CALC (ID_MANTENEDORA, TOKEN, ID_USER, PERFIL, DATA_REGISTRO) (
							SELECT ID_MATRIZ, token, ID_USER, 'ESC', NOW() FROM SPRO_USER WHERE ID_MATRIZ = idMatriz
				);

				REPLACE INTO SPRO_ESTORNO_CREDITO (ID_MATRIZ, ID_USER, VENC_MATRIZ_EN, DATA_REGISTRO) 
				(SELECT ID_MATRIZ, ID_USER, dataVencMatrizEn, NOW() FROM SPRO_USER WHERE ID_MATRIZ = idMatriz);	
				
				# 1 - Calcula o consumo de créditos dos professores até o momento
				IF (NivelMatriz = 'M') THEN
					# Consumo dos professores da Mantenedora atual
					SELECT SUM(DEBITO) INTO @consumoCreditoProf FROM SPRO_HISTORICO_GERADOC 
					WHERE ID_LOGIN IN(
						SELECT ID_USER FROM SPRO_USER WHERE ID_MATRIZ = idMatriz OR ID_MATRIZ IN (
							SELECT ID_USER FROM SPRO_USER WHERE ID_MATRIZ = idMatriz
						)				
					) AND DATA_REGISTRO > dataUltimaCompraMatrizEn;		
				ELSE
					# Consumo dos professores da escola atual
					SELECT SUM(DEBITO) INTO @consumoCreditoProf FROM SPRO_HISTORICO_GERADOC 
					WHERE ID_LOGIN IN(
						SELECT ID_USER FROM SPRO_USER WHERE ID_MATRIZ = idMatriz			
					) AND DATA_REGISTRO > dataUltimaCompraMatrizEn;	
				END IF;
				# Calcula o saldo real da mantenedora
	END IF;
	
	IF (@consumoCreditoProf IS NULL) THEN
		SET @consumoCreditoProf := 0;
	END IF;

	# Soma o total estornado
	IF ((NivelMatriz = 'E' OR NivelEstorno = 'ESC')) THEN
			# Verifica se há créditos a estornar de professor
			SELECT fcCalcCreditosEstornaveis(idMatriz, 'P') INTO @saldoAestornarProf;
			
			IF (@saldoAestornarProf = 0) THEN	
				# Todos os créditos de professor e Escola foram estornados. 
				# Faz um resumo simplificado do saldo subtraindo o total de consumo do saldo inicial.
				SET @saldoAestornarProf := 0;
				SET @agora := (NOW() + INTERVAL 1 MINUTE);
				SET @saldoAposEstorno := saldoIniMatriz - @consumoCreditoProf;
				INSERT INTO SPRO_CREDITO_CONSOLIDADO (
					ID_MATRIZ, ID_FILIAL, MOTIVO, OPERACAO, ID_CLIENTE, ID_REG_SALDO_ANT, 
					SALDO_ANT, CREDITO, SALDO_FINAL,NUM_PEDIDO, VENCIMENTO, DATA_REGISTRO
				) 
				VALUES(
					0, 0, 'ESTORNO_EM_LOTE (fcEstornoTotalCreditos)','C',idMatriz, idRegSaldoAnt, 
					@saldoAposEstorno, 0, @saldoAposEstorno, numPedido, dataVencMatrizEn, @agora
				);
				SET retorno = 2;
			END IF;
			SELECT SUM(SALDO_ATUAL) INTO @creditosEstornados FROM SPRO_ESTORNO_CREDITO_CALC 
			WHERE ID_MANTENEDORA = idMatriz AND TOKEN = token;

			SET retorno = 1;
	END IF;

	# Grava um resumo do estorno	
	REPLACE INTO SPRO_ESTORNO_RESUMO (ORIGEM, ID_USER, NIVEL_ESTORNO, CREDITOS_ESTORNADOS, DATA_REGISTRO)
	VALUES('fcEstornoTotalCreditos', idMatriz, NivelEstorno, IFNULL(@creditosEstornados,0), @agora);
	
	DELETE FROM SPRO_ESTORNO_CREDITO_CALC WHERE ID_MANTENEDORA = idMatriz AND TOKEN = token;
	RETURN retorno;
END;

