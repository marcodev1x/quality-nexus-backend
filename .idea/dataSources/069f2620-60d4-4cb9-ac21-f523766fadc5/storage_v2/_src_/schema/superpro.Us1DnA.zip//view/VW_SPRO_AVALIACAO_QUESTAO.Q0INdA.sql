create definer = admin@`%` view VW_SPRO_AVALIACAO_QUESTAO as
select `superpro`.`SPRO_BCO_QUESTAO`.`AVALIACAO_NUM_PONTOS` AS `AVALIACAO_NUM_PONTOS`,
       `superpro`.`SPRO_BCO_QUESTAO`.`AVALIACAO_NUM_VOTOS`  AS `AVALIACAO_NUM_VOTOS`
from `superpro`.`SPRO_BCO_QUESTAO`
where ((`superpro`.`SPRO_BCO_QUESTAO`.`AVALIACAO_NUM_PONTOS` is not null) or
       (`superpro`.`SPRO_BCO_QUESTAO`.`AVALIACAO_NUM_VOTOS` is not null));

