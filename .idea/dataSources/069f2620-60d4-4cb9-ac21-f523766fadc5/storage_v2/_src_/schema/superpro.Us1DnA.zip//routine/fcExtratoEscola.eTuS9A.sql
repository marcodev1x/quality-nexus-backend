create
    definer = admin@`%` function fcExtratoEscola(ID_ESCOLA_IN int) returns longtext
BEGIN
	# 14/05/2015
	# Calcula o saldo do ID_USER informado, independentemente do perfil.
	# @author Claudio Rubens Silva Filho

	DECLARE RESUMO TEXT;
	DECLARE LIST_ID_DEPENDENTES LONGTEXT;
	DECLARE SOMA_CREDITO INTEGER;
	DECLARE SOMA_DEBITO INT;
	DECLARE SALDO_DISTRIBUIDO INT;
	DECLARE SOMA_CONSUMO INT;
	DECLARE SALDO_FINAL INT;
	DECLARE NOME_ESCOLA VARCHAR(100);

	SET RESUMO = '';
	SET LIST_ID_DEPENDENTES = '';

	# Gera a lista de IDs dos dependentes da escola atual
	SELECT GROUP_CONCAT(ID_CLIENTE) INTO LIST_ID_DEPENDENTES FROM SPRO_CLIENTE WHERE ID_MATRIZ = ID_ESCOLA_IN;

	IF (LENGTH(LIST_ID_DEPENDENTES) > 0) THEN
		# Encontrou um ou mais usuários vinculados ao ID atual
		# Localiza o nome da escola
		SELECT NOME_PRINCIPAL INTO NOME_ESCOLA FROM SPRO_CLIENTE WHERE ID_CLIENTE = ID_ESCOLA_IN;

		# Calcula o total de créditos enviados aos professores:
		SELECT SUM(CREDITO) INTO SOMA_CREDITO FROM SPRO_CREDITO_CONSOLIDADO 
		WHERE OPERACAO = 'C' AND ID_CLIENTE IN (LIST_ID_DEPENDENTES);
		SET RESUMO = SOMA_CREDITO;
		RETURN RESUMO;

		SELECT SUM(CREDITO) INTO SOMA_DEBITO FROM SPRO_CREDITO_CONSOLIDADO 
		WHERE OPERACAO = 'D' AND ID_CLIENTE IN (LIST_ID_DEPENDENTES);

		# Calcula o total de créditos distribuídos
		SELECT SUM(DEBITO) INTO SOMA_CONSUMO FROM SPRO_HISTORICO_GERADOC WHERE ID_LOGIN IN (LIST_ID_DEPENDENTES);
		SET SOMA_CONSUMO = IFNULL(SOMA_CONSUMO,0);

		# Calcula o saldo estornável da escola atual
		SET SALDO_DISTRIBUIDO = IFNULL(SOMA_CREDITO,0) - IFNULL(SOMA_DEBITO,0);		

		SET SALDO_FINAL = SALDO_DISTRIBUIDO - SOMA_CONSUMO;

		# Monta a string de retorno
		SET RESUMO = CONCAT("Resumo da escola ", NOME_ESCOLA, "(",ID_ESCOLA_IN,")","\n");
		SET RESUMO = CONCAT(RESUMO,"------------------------------------------------------------------------------","\n");
		SET RESUMO = CONCAT(RESUMO, "Distribuídos (creditados - estornados): ", SALDO_DISTRIBUIDO,"\n");
		SET RESUMO = CONCAT(RESUMO, "Consumidos: ", SOMA_CONSUMO,"\n");
		SET RESUMO = CONCAT(RESUMO, "Saldo final: ", SALDO_FINAL,"\n");
		
	ELSE
		SET RESUMO = "O ID informado não possui usuários cadastrados!";
	END IF;

	RETURN RESUMO;
END;

