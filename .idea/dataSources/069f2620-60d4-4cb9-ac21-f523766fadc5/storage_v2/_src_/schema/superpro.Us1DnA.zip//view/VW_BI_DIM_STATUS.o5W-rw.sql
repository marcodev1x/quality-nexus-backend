create definer = admin@`%` view VW_BI_DIM_STATUS as
select `superpro`.`SPRO_ECOMM_STATUS_LOJA`.`ID_STATUS_LOJA` AS `ID_STATUS_LOJA`,
       `superpro`.`SPRO_ECOMM_STATUS_LOJA`.`STATUS_LOJA`    AS `STATUS_LOJA`,
       `superpro`.`SPRO_ECOMM_STATUS_LOJA`.`DESCRICAO`      AS `DESCRICAO`
from `superpro`.`SPRO_ECOMM_STATUS_LOJA`;

