create definer = staging@`%` view VW_SPRO_RESUMO_COLAB as
select `TB2`.`ID_AUTH_USUARIO`                     AS `ID_COLABORADOR`,
       `TB2`.`NOME`                                AS `NOME`,
       `TB2`.`EMAIL`                               AS `EMAIL`,
       sum(`TB1`.`TOTAL_Q`)                        AS `TOTAL_Q`,
       sum(`TB1`.`TOTAL_Q_COM_DEBITO`)             AS `TOTAL_Q_COM_DEBITO`,
       date_format(`TB1`.`DATA_REGISTRO`, '%m/%Y') AS `MES_ANO`
from (`superpro`.`SPRO_RESUMO_COLAB` `TB1` join `superpro`.`SPRO_AUTH_USUARIO` `TB2`)
where (`TB1`.`ID_AUTH_COLABORADOR` = `TB2`.`ID_AUTH_USUARIO`)
group by `TB1`.`ID_AUTH_COLABORADOR`, date_format(`TB1`.`DATA_REGISTRO`, '%m/%Y')
order by `TB2`.`NOME`, `TB1`.`DATA_REGISTRO` desc;

