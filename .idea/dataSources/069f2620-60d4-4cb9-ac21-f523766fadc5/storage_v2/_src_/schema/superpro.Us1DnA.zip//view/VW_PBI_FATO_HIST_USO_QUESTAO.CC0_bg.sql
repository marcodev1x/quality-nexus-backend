create definer = powerbi@`%` view VW_PBI_FATO_HIST_USO_QUESTAO as
select `hq`.`ID_HIST_USO_QUESTAO`  AS `ID_HIST_USO_QUESTAO`,
       `hq`.`ID_HISTORICO_GERADOC` AS `ID_HISTORICO_GERADOC`,
       `hq`.`ID_QUESTAO`           AS `ID_QUESTAO`,
       `hq`.`ID_CLIENTE`           AS `ID_CLIENTE`,
       `hq`.`NUM_PEDIDO_REF`       AS `NUM_PEDIDO_REF`,
       `hq`.`VALOR_UNIT_CRED`      AS `VALOR_UNIT_CRED`,
       `hq`.`FLAG`                 AS `FLAG`,
       `hq`.`DATA_REGISTRO`        AS `DATA_REGISTRO`
from (`superpro`.`SPRO_HIST_USO_QUESTAO` `hq` join `superpro`.`SPRO_VW_CLIENTE_VALIDO` `sc`
      on ((`superpro`.`sc`.`ID_CLIENTE` = `hq`.`ID_CLIENTE`)))
where (`hq`.`DATA_REGISTRO` >= '2018-01-01 00:00:00');

