create definer = admin@`%` view VW_SPRO_LST_HIST_RESPOSTA as
select `superpro`.`SPRO_LST_HIST_RESPOSTA`.`ID_LST_HIST_RESPOSTA` AS `ID_LST_HIST_RESPOSTA`,
       `superpro`.`SPRO_LST_HIST_RESPOSTA`.`ID_LST_USUARIO`       AS `ID_LST_USUARIO`,
       `superpro`.`SPRO_LST_HIST_RESPOSTA`.`ID_BCO_QUESTAO`       AS `ID_BCO_QUESTAO`,
       `superpro`.`SPRO_LST_HIST_RESPOSTA`.`RESPOSTA`             AS `RESPOSTA`,
       `superpro`.`SPRO_LST_HIST_RESPOSTA`.`GABARITO`             AS `GABARITO`,
       `superpro`.`SPRO_LST_HIST_RESPOSTA`.`DATA_REGISTRO`        AS `DATA_REGISTRO`,
       `superpro`.`SPRO_LST_USUARIO`.`NUM_QUESTOES`               AS `NUM_QUESTOES`,
       `superpro`.`SPRO_LST_USUARIO`.`NUM_QUESTOES_ESTATICAS`     AS `NUM_QUESTOES_ESTATICAS`,
       `superpro`.`SPRO_LST_USUARIO`.`NUM_QUESTOES_DINAMICAS`     AS `NUM_QUESTOES_DINAMICAS`,
       `superpro`.`SPRO_LST_USUARIO`.`LST_QUESTOES_ESTATICAS`     AS `LST_QUESTOES_ESTATICAS`,
       `superpro`.`SPRO_LST_USUARIO`.`LST_QUESTOES_DINAMICAS`     AS `LST_QUESTOES_DINAMICAS`,
       `superpro`.`SPRO_LST_USUARIO`.`ID_CLIENTE`                 AS `ID_CLIENTE`,
       `superpro`.`SPRO_LST_USUARIO`.`ID_HISTORICO_GERADOC`       AS `ID_HISTORICO_GERADOC`,
       `superpro`.`SPRO_LST_USUARIO`.`RESPOSTAS_TEMP`             AS `RESPOSTAS_TEMP`,
       `superpro`.`SPRO_CONSUMO_CREDITO`.`DEBITO`                 AS `DEBITO`,
       `superpro`.`SPRO_CONSUMO_CREDITO`.`ID_CONSUMO_CREDITO`     AS `ID_CONSUMO_CREDITO`,
       `superpro`.`SPRO_CONSUMO_CREDITO`.`REFERENCIA`             AS `REFERENCIA`,
       `superpro`.`SPRO_CLIENTE`.`EMAIL`                          AS `EMAIL`,
       `superpro`.`SPRO_CLIENTE`.`SOBRENOME`                      AS `SOBRENOME`,
       `superpro`.`SPRO_CLIENTE`.`NOME_PRINCIPAL`                 AS `NOME_PRINCIPAL`,
       `superpro`.`SPRO_HISTORICO_GERADOC`.`COD_LISTA`            AS `COD_LISTA`,
       `superpro`.`SPRO_LST_USUARIO`.`DT_HR_EMAIL_ENV`            AS `DT_HR_EMAIL_ENV`,
       `superpro`.`SPRO_LST_USUARIO`.`MSG_EMAIL_ENV`              AS `MSG_EMAIL_ENV`
from ((((`superpro`.`SPRO_LST_USUARIO` join `superpro`.`SPRO_LST_HIST_RESPOSTA`
         on ((`superpro`.`SPRO_LST_USUARIO`.`ID_LST_USUARIO` =
              `superpro`.`SPRO_LST_HIST_RESPOSTA`.`ID_LST_USUARIO`))) join `superpro`.`SPRO_CONSUMO_CREDITO`
        on ((`superpro`.`SPRO_CONSUMO_CREDITO`.`ID_HIST_GERADOC` =
             `superpro`.`SPRO_LST_USUARIO`.`ID_HISTORICO_GERADOC`))) join `superpro`.`SPRO_CLIENTE`
       on ((`superpro`.`SPRO_CLIENTE`.`ID_CLIENTE` =
            `superpro`.`SPRO_LST_USUARIO`.`ID_CLIENTE`))) join `superpro`.`SPRO_HISTORICO_GERADOC`
      on ((`superpro`.`SPRO_HISTORICO_GERADOC`.`ID_HISTORICO_GERADOC` =
           `superpro`.`SPRO_LST_USUARIO`.`ID_HISTORICO_GERADOC`)));

