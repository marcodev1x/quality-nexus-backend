create
    definer = admin@`%` function fcResultadoSimulado() returns int
BEGIN
	#Resultado prova

	DECLARE finished INTEGER DEFAULT 0;
	DECLARE codTurma, contador INTEGER DEFAULT 0;
	DECLARE idEscola INTEGER DEFAULT 760185;
	DECLARE instituicao VARCHAR(100) DEFAULT '';

	DECLARE escolasCursor CURSOR FOR 
	SELECT DISTINCT COD_TURMA, (SELECT NOME_PRINCIPAL FROM SPRO_CLIENTE TB1 WHERE TB1.ID_CLIENTE = TB2.COD_TURMA) AS INSTITUICAO
	FROM SPRO_LST_ALUNO_INSTITUICAO TB2
	WHERE ID_INSTITUICAO = idEscola AND COD_TURMA IS NOT NULL
	ORDER BY COD_TURMA ASC;

	DECLARE CONTINUE HANDLER FOR NOT FOUND SET finished = 1;

	SET @nomeEscola = '';
	DELETE FROM SPRO_SIMULADO_NACIONAL;

	IF (finished != 1) THEN
			OPEN escolasCursor;                                
			loopEscolas: LOOP
					FETCH escolasCursor INTO codTurma, instituicao;

					IF (instituicao is null) THEN
						SET instituicao = 'Indefinido';
					END IF;

					# Localiza os alunos da escola atual
					SELECT GROUP_CONCAT(ID_CLIENTE) INTO @listaAluno FROM SPRO_CLIENTE TB1, SPRO_LST_ALUNO_INSTITUICAO TB2
					WHERE TB1.EMAIL = TB2.EMAIL AND TB2.COD_TURMA = codTurma;
						
					# Idiomas
					SET @idHistGeraDoc = 6498130;
					SET @lista = 'IDIOMAS';

					# Abriu
					select count(1) INTO @alunosAbriram
					from `SPRO_LST_USUARIO` where (`SPRO_LST_USUARIO`.`ID_CLIENTE` IN (SELECT ID_CLIENTE 
					FROM SPRO_LST_ALUNO_INSTITUICAO TB1, SPRO_CLIENTE TB2 
					WHERE TB1.EMAIL = TB2.EMAIL AND TB1.ID_INSTITUICAO = idEscola AND TB1.COD_TURMA = codTurma)
					and (`SPRO_LST_USUARIO`.`DATA_REGISTRO` >= '2020-10-10 12:0:00') 
					and (`SPRO_LST_USUARIO`.`ID_HISTORICO_GERADOC` = @idHistGeraDoc));

					# Concluiu
					select count(1) INTO @alunosConcluiram
					from `SPRO_LST_USUARIO` where ((`SPRO_LST_USUARIO`.`ID_CLIENTE` IN (SELECT ID_CLIENTE 
					FROM SPRO_LST_ALUNO_INSTITUICAO TB1, SPRO_CLIENTE TB2 
					WHERE TB1.EMAIL = TB2.EMAIL AND TB1.ID_INSTITUICAO = idEscola AND TB1.COD_TURMA = codTurma))
					and (`SPRO_LST_USUARIO`.`DATA_REGISTRO` >= '2020-10-10 12:0:00') 
					and (`SPRO_LST_USUARIO`.`ID_HISTORICO_GERADOC` = @idHistGeraDoc))
					and `SPRO_LST_USUARIO`.`FINALIZADO_POR_ID` IS NOT NULL;

					INSERT INTO SPRO_SIMULADO_NACIONAL (COLEGIO, ID_COLEGIO, LISTA, ABRIU, RESPONDEU)
					VALUES(instituicao, codTurma, @lista, @alunosAbriram, @alunosConcluiram);


					# Idiomas
					SET @idHistGeraDoc = 6498258;
					SET @lista = 'LINGUAGENS';

					# Abriu
					select count(1) INTO @alunosAbriram
					from `SPRO_LST_USUARIO` where (`SPRO_LST_USUARIO`.`ID_CLIENTE` IN (SELECT ID_CLIENTE 
					FROM SPRO_LST_ALUNO_INSTITUICAO TB1, SPRO_CLIENTE TB2 
					WHERE TB1.EMAIL = TB2.EMAIL AND TB1.ID_INSTITUICAO = idEscola AND TB1.COD_TURMA = codTurma)
					and (`SPRO_LST_USUARIO`.`DATA_REGISTRO` >= '2020-10-10 12:0:00') 
					and (`SPRO_LST_USUARIO`.`ID_HISTORICO_GERADOC` = @idHistGeraDoc));

					# Concluiu
					select count(1) INTO @alunosConcluiram
					from `SPRO_LST_USUARIO` where ((`SPRO_LST_USUARIO`.`ID_CLIENTE` IN (SELECT ID_CLIENTE 
					FROM SPRO_LST_ALUNO_INSTITUICAO TB1, SPRO_CLIENTE TB2 
					WHERE TB1.EMAIL = TB2.EMAIL AND TB1.ID_INSTITUICAO = idEscola AND TB1.COD_TURMA = codTurma))
					and (`SPRO_LST_USUARIO`.`DATA_REGISTRO` >= '2020-10-10 12:0:00') 
					and (`SPRO_LST_USUARIO`.`ID_HISTORICO_GERADOC` = @idHistGeraDoc))
					and `SPRO_LST_USUARIO`.`FINALIZADO_POR_ID` IS NOT NULL;

					INSERT INTO SPRO_SIMULADO_NACIONAL (COLEGIO, ID_COLEGIO, LISTA, ABRIU, RESPONDEU)
					VALUES(instituicao, codTurma, @lista, @alunosAbriram, @alunosConcluiram);

					# Idiomas
					SET @idHistGeraDoc = 6498265;
					SET @lista = 'HUMANAS';

					# Abriu
					select count(1) INTO @alunosAbriram
					from `SPRO_LST_USUARIO` where (`SPRO_LST_USUARIO`.`ID_CLIENTE` IN (SELECT ID_CLIENTE 
					FROM SPRO_LST_ALUNO_INSTITUICAO TB1, SPRO_CLIENTE TB2 
					WHERE TB1.EMAIL = TB2.EMAIL AND TB1.ID_INSTITUICAO = idEscola AND TB1.COD_TURMA = codTurma)
					and (`SPRO_LST_USUARIO`.`DATA_REGISTRO` >= '2020-10-10 12:0:00') 
					and (`SPRO_LST_USUARIO`.`ID_HISTORICO_GERADOC` = @idHistGeraDoc));

					# Concluiu
					select count(1) INTO @alunosConcluiram
					from `SPRO_LST_USUARIO` where ((`SPRO_LST_USUARIO`.`ID_CLIENTE` IN (SELECT ID_CLIENTE 
					FROM SPRO_LST_ALUNO_INSTITUICAO TB1, SPRO_CLIENTE TB2 
					WHERE TB1.EMAIL = TB2.EMAIL AND TB1.ID_INSTITUICAO = idEscola AND TB1.COD_TURMA = codTurma))
					and (`SPRO_LST_USUARIO`.`DATA_REGISTRO` >= '2020-10-10 12:0:00') 
					and (`SPRO_LST_USUARIO`.`ID_HISTORICO_GERADOC` = @idHistGeraDoc))
					and `SPRO_LST_USUARIO`.`FINALIZADO_POR_ID` IS NOT NULL;

					INSERT INTO SPRO_SIMULADO_NACIONAL (COLEGIO, ID_COLEGIO, LISTA, ABRIU, RESPONDEU)
					VALUES(instituicao, codTurma, @lista, @alunosAbriram, @alunosConcluiram);

					SET contador = contador + 1;

					IF finished = 1 THEN 
						LEAVE loopEscolas;
					END IF;
			END LOOP loopEscolas;
			CLOSE escolasCursor;
	END IF;
	RETURN contador;
END;

