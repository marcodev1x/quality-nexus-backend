create
    definer = admin@`%` function fcNovaContaWS(nomeParam varchar(100), emailParam varchar(100),
                                               passwd varchar(20)) returns varchar(100)
BEGIN
	# 25/05/2017
	# Cadastro de novo acesso de Mantenedora (webservice) no ambiente homolog
	#
	# @author Claudio Rubens Silva Filho
	SET @response := 'Erro não identificado.';
	SET @idUser := 0;

	IF (LENGTH(nomeParam) > 0 AND LENGTH(emailParam) > 0) THEN	

		SELECT ID_USER INTO @idUser FROM superpro_homolog.SPRO_USER WHERE EMAIL = emailParam AND ID_USER_PERFIL=9;
		IF (@idUser = 0) THEN
				# Efetua novo cadastro Mantenedora
				INSERT INTO superpro_homolog.SPRO_USER (HASH,ID_USER_PERFIL,NOME, APELIDO,EMAIL,LOGIN,PASSWD,DATA_REGISTRO) 
				VALUES(MD5(emailParam),9,nomeParam, nomeParam, emailParam,emailParam,MD5(passwd),NOW());

				# Localiza o ID do registro
				SELECT ID_USER INTO @idUser FROM superpro_homolog.SPRO_USER WHERE EMAIL = emailParam AND ID_USER_PERFIL=9;
		END IF;

		IF (@idUser = 0) THEN 
				SET @response := "Não foi possível cadastrar/localizar um usuário para o e-mail informado.";
		ELSE 
				# Cadastra um user WS
				SET @pos := INSTR(emailParam, '@');
				SET @login := SUBSTR(emailParam,1,@pos-1);
			
				IF (LENGTH(@login) < 5) THEN
					SET @login := CONCAT('superpro_',@login);
				END IF;

				REPLACE INTO superpro_homolog.SPRO_WS_USER(ID_USER, LOGIN, SENHA, DT_REGISTRO) 
				VALUES(@idUser, @login, MD5(passwd), NOW());
				
				#Lança um novo pedido e créditos para a conta atual
				SET @numPedido := 0;
				SET @credito := 1000;	
				SET @meses := 12;
				SELECT (MAX(NUM_PEDIDO)+1) INTO @numPedido FROM superpro_homolog.SPRO_ECOMM_PEDIDO ORDER BY NUM_PEDIDO DESC;

				IF (@numPedido > 0) THEN
						# Gera um pedido:
						INSERT INTO superpro_homolog.SPRO_ECOMM_PEDIDO (
						ORIGEM, ID_CLIENTE, NUM_PEDIDO, NOME_CLIENTE, EMAIL_CLIENTE, ID_MEIO_PGTO, PARCELAS, VALOR_TOTAL, 
						VALOR_PARCELA, CREDITOS, VALIDADE_CREDITOS, ID_STATUS_LOJA, DATA_REGISTRO
						) VALUES ('fcNovaContaWS', @idUser, @numPedido, nomeParam, emailParam, 13, 1, 10, 10, @credito, @meses, 1, NOW());
					
						# Lança créditos:
						SELECT superpro_homolog.fcNovaCarga(@idUser, @credito, @numPedido, @meses, 'C') INTO @novaCarga;

						SET @saldoAtual = fcCalcSaldo(@idUser);
						SET @response := CONCAT('idUser: ', @idUser, ', login: ',@login,', senha: ' ,passwd, ', saldoAtual: ',@saldoAtual);
				ELSE 
						SET @response := "Não foi possível gerar um número de pedido.";
				END IF;				
		END IF;
		

	ELSE 
		SET @response := "Um ou mais parâmetros obrigatórios não foram informados ou estão vazios.";
	END IF;
	RETURN @response;
END;

