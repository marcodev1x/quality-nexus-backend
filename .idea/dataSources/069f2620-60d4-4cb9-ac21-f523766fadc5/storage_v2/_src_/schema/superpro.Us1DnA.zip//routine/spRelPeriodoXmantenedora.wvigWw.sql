create
    definer = admin@`%` procedure spRelPeriodoXmantenedora(IN varIdMantenedora int, IN varAno int, IN apenasEscolasComConsumo int)
BEGIN
	# Localiza escolas que aderiram ao simulado Enem
	DECLARE idEscola, totalConsumoCredDaEscola, totalRegistros, somaCreditos, finished INTEGER DEFAULT 0;
	DECLARE	nomeDaEscola, sistEnsino CHAR(100);
	DECLARE lstIdEscolas, lstIdProfessores LONGTEXT;

	DECLARE escolasCursor CURSOR FOR 
	SELECT ID_CLIENTE, NOME_PRINCIPAL,TAG AS SIST_ENSINO FROM SPRO_CLIENTE 
	WHERE ID_MATRIZ = varIdMantenedora 
	ORDER BY NOME_PRINCIPAL ASC;

	DECLARE CONTINUE HANDLER FOR NOT FOUND SET finished = 1;
	

	SET totalRegistros = 0;
	SET somaCreditos = 0;
	SET lstIdProfessores = '';

	IF finished != 1 THEN
		# Cria a tabela que será usada para guardar a extração dos dados.
		DROP TABLE IF EXISTS `ADM_REL_ESC_X_PERIODO`;
		CREATE TABLE `ADM_REL_ESC_X_PERIODO` (
			`ID_CLIENTE` int(11) NOT NULL,
			`NOME` varchar(100) NOT NULL,
			`SIST_ENSINO` char(20) NOT NULL,
			`CONSUMO_CRED` int(11) NOT NULL,
			`LST_ID_USER` LONGTEXT NOT NULL
		) ENGINE=InnoDB DEFAULT CHARSET=latin1;

		OPEN escolasCursor;                                
				getEscolas: LOOP
					FETCH escolasCursor INTO idEscola, nomeDaEscola, sistEnsino;
					IF finished = 1 THEN 
						LEAVE getEscolas;
					END IF;       
					
					#Localiza os professores da escola atual:
					SET totalConsumoCredDaEscola = 0;
					SELECT GROUP_CONCAT(ID_CLIENTE) INTO lstIdProfessores FROM SPRO_CLIENTE WHERE ID_MATRIZ = idEscola;
					
					# Soma o total de consumo dos professores no ano informado:
					IF (LENGTH(lstIdProfessores) > 0) THEN
						SELECT SUM(DEBITO) INTO totalConsumoCredDaEscola 
						FROM SPRO_HISTORICO_GERADOC 
						WHERE FIND_IN_SET(ID_LOGIN, lstIdProfessores) AND YEAR(DATA_REGISTRO) = varAno;
					END IF;				

					# Grava os dados na tabela temporária:
					IF ((totalConsumoCredDaEscola > 0 AND apenasEscolasComConsumo = 1) OR apenasEscolasComConsumo = 0) THEN
						INSERT IGNORE INTO ADM_REL_ESC_X_PERIODO (ID_CLIENTE, NOME, SIST_ENSINO, CONSUMO_CRED, LST_ID_USER) 
						VALUES(idEscola, nomeDaEscola, sistEnsino, totalConsumoCredDaEscola, lstIdProfessores);
						SET totalRegistros=totalRegistros+1;
					END IF;
					SET somaCreditos = somaCreditos + totalConsumoCredDaEscola;
					#SELECT lstIdProfessores FROM DUAL;  
					#echo 'Ok';
		END LOOP getEscolas;
		CLOSE escolasCursor;
	ELSE 
		SELECT 'Nenhuma escola foi localizada para a mantenedora informada.' FROM DUAL;
	END IF;
  # Debug:
	#SELECT lstIdEscolas FROM DUAL;
	SELECT totalRegistros AS TOTAL_ESCOLAS, somaCreditos AS TOTAL_CONSUMO FROM DUAL;

END;

