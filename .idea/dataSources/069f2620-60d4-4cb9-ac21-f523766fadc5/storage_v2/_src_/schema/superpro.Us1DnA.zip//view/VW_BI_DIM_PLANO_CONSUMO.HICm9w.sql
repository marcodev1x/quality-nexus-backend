create definer = staging@`%` view VW_BI_DIM_PLANO_CONSUMO as
select distinct `PC`.`ID_PLANO_CONSUMO` AS `ID_PLANO_CONSUMO`,
                `PC`.`PLANO_CONSUMO`    AS `PLANO_CONSUMO`,
                `PC`.`CODIGO_PLANO`     AS `CODIGO_PLANO`,
                `PC`.`VALOR_MIN`        AS `VALOR_MIN`,
                `PC`.`PRAZO_MESES_VENC` AS `PRAZO_MESES_VENC`,
                `PC`.`PUB`              AS `PUB`
from `superpro`.`SPRO_PLANO_CONSUMO` `PC`;

