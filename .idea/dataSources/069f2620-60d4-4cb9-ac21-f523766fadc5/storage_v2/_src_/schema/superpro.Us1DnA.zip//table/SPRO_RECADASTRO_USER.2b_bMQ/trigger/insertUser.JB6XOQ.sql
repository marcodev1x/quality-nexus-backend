create definer = admin@`%` trigger insertUser
    after insert
    on SPRO_RECADASTRO_USER
    for each row
BEGIN
                IF (NEW.ID_USER > 0) THEN
                        UPDATE SPRO_CLIENTE SET NOME_PRINCIPAL = NEW.NOME_PRINCIPAL, APELIDO = NEW.APELIDO
                        WHERE ID_CLIENTE = NEW.ID_USER;

                       IF (NEW.DDD_RESID > 0 AND NEW.FONE_RESID > 0) THEN
                                  UPDATE SPRO_CLIENTE SET DDD_RESID = NEW.DDD_RESID, FONE_RESID = NEW.FONE_RESID
                                  WHERE ID_CLIENTE = NEW.ID_USER;
                       END IF;

                       IF (NEW.DDD_CELULAR > 0 AND NEW.FONE_CELULAR > 0) THEN
                                  UPDATE SPRO_CLIENTE SET DDD_CELULAR = NEW.DDD_CELULAR, FONE_CELULAR = NEW.FONE_CELULAR
                                  WHERE ID_CLIENTE = NEW.ID_USER;
                       END IF;

                       IF (NEW.PASSWD_MOBILE != '') THEN
                                  	REPLACE INTO SPRO_USER_HOMOLOG SET LOGIN = NEW.LOGIN_MOBILE, PASSWORD_MD5 = NEW.PASSWD_MOBILE, 
		ATIVO=1, ID_CLIENTE = NEW.ID_USER, DATA_REGISTRO = NOW();		
                       END IF;
                 END IF;
END;

