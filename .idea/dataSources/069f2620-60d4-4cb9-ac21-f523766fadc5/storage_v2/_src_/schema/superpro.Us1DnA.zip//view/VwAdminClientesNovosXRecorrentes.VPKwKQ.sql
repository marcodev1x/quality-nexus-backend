create definer = admin@`%` view VwAdminClientesNovosXRecorrentes as
select `TB1`.`ID_CLIENTE`                                AS `ID_CLIENTE`,
       (select count(1)
        from `superpro`.`SPRO_CREDITO_CONSOLIDADO` `TB2`
        where (`TB2`.`ID_CLIENTE` = `TB1`.`ID_CLIENTE`)) AS `COMPRAS`,
       date_format(`TB1`.`DATA_REGISTRO`, '%m/%Y')       AS `MES_ANO`,
       cast(`TB1`.`DATA_REGISTRO` as date)               AS `DATA_REGISTRO`,
       month(`TB1`.`DATA_REGISTRO`)                      AS `MES`,
       year(`TB1`.`DATA_REGISTRO`)                       AS `ANO`
from `superpro`.`SPRO_CREDITO_CONSOLIDADO` `TB1`
where ((`TB1`.`ID_MATRIZ` = 0) and (`TB1`.`NUM_PEDIDO` > 0) and (`TB1`.`ID_CLIENTE` > 0))
having (`MES_ANO` <> '00/0000');

