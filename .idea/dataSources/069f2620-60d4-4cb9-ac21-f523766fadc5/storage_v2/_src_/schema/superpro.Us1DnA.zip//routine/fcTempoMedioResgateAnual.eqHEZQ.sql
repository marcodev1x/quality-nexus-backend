create
    definer = admin@`%` function fcTempoMedioResgateAnual(cliente int, ano varchar(4)) returns int
BEGIN
	declare dias, resgates int default 0;
	declare venc_anterior date default '2000-01-01';
	declare registro, vencimento date;
	declare inicio int default 1;

	declare fim int default 0;
	
	
	declare c cursor for 
	SELECT scc.DATA_REGISTRO , scc.VENCIMENTO  
	from SPRO_CREDITO_CONSOLIDADO scc 
	join SPRO_ECOMM_PEDIDO sep
	    on sep.NUM_PEDIDO = scc.NUM_PEDIDO
	where scc.ID_CLIENTE = cliente
		and scc.OPERACAO = 'C'
		and date(scc.VENCIMENTO) >=  CONCAT(ano,'-01-01') 
		and date(scc.DATA_REGISTRO) <= CONCAT(ano,'-12-31')
	   	and sep.ID_STATUS_LOJA = 1;
	   
	declare continue handler for not found set fim = 1;
	
	open c;
	
	while fim=0
	do
	fetch c into registro, vencimento;
		if fim = 0 then 
			if inicio = 1 then
				set venc_anterior = vencimento;
				set inicio = 0;
			else
				if registro > venc_anterior then
					set dias = dias + DATEDIFF(registro, venc_anterior);
					set resgates = resgates + 1;
				end if;
				
				set venc_anterior = vencimento;
			end if;
		end if;
	end while;
	
	close c;

	return floor(dias/resgates);
END;

