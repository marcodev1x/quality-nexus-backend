create definer = admin@`%` trigger insertUpdSas
    before insert
    on SPRO_SAS_RELATORIO
    for each row
BEGIN
	SELECT GROUP_CONCAT(DISTINCT ESCOLA) INTO @escola FROM SPRO_SAS_USER WHERE EMAIL = NEW.EMAIL;
	SET NEW.ESCOLA = @escola;
END;

