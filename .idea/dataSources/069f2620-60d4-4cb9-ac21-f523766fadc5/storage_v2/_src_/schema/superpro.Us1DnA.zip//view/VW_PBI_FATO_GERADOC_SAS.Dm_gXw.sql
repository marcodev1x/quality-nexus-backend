create definer = admin@`%` view VW_PBI_FATO_GERADOC_SAS as
select `hg`.`ID_HISTORICO_GERADOC`        AS `ID_GERADOC`,
       `hg`.`LISTA_ATIVA`                 AS `LISTA_ATIVA`,
       `hg`.`FORMATO`                     AS `FORMATO`,
       `hg`.`ID_LOGIN`                    AS `ID_LOGIN`,
       `hg`.`DEBITO`                      AS `DEBITO`,
       `hg`.`NUM_QUESTOES`                AS `NUM_QUESTOES`,
       `hg`.`NUM_DOWNLOAD`                AS `NUM_DOWNLOAD`,
       `hg`.`DEL`                         AS `DELETADA`,
       cast(`hg`.`DATA_REGISTRO` as date) AS `DATA_REGISTRO`,
       `hg`.`DATA_UPD`                    AS `DATA ATUALIZAÇÃO`
from (`superpro`.`SPRO_HISTORICO_GERADOC` `hg` join `superpro`.`VW_PBI_CLIENTES_SAS` `sc`
      on ((`superpro`.`sc`.`ID_CLIENTE` = `hg`.`ID_LOGIN`)))
where (`hg`.`DATA_REGISTRO` >= '2018-01-01 00:00:00');

