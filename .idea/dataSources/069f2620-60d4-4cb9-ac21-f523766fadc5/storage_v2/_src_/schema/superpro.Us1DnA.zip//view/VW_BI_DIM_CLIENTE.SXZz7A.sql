create definer = staging@`%` view VW_BI_DIM_CLIENTE as
select distinct `superpro`.`SPRO_CLIENTE`.`ID_CLIENTE`                                                    AS `ID_CLIENTE`,
                `superpro`.`SPRO_CLIENTE`.`NOME_PRINCIPAL`                                                AS `CLIENTE`,
                `superpro`.`SPRO_CLIENTE`.`APELIDO`                                                       AS `APELIDO`,
                `superpro`.`SPRO_CLIENTE`.`PF_PJ`                                                         AS `PF_PJ`,
                `superpro`.`SPRO_CLIENTE`.`CPF_CNPJ`                                                      AS `CPF_CNPJ`,
                `superpro`.`SPRO_CLIENTE`.`RAZAO_SOCIAL`                                                  AS `RAZAO_SOCIAL`,
                `superpro`.`SPRO_CLIENTE`.`ANIVERSARIO`                                                   AS `DT_NASCIMENTO`,
                `superpro`.`SPRO_CLIENTE`.`SEXO`                                                          AS `SEXO`,
                `superpro`.`SPRO_CLIENTE`.`COD_POSTAL`                                                    AS `CEP`,
                `superpro`.`SPRO_CLIENTE`.`LOGRADOURO`                                                    AS `LOGRADOURO`,
                `superpro`.`SPRO_CLIENTE`.`NUMERO`                                                        AS `NUMERO`,
                `superpro`.`SPRO_CLIENTE`.`COMPLEMENTO`                                                   AS `COMPLEMENTO`,
                `superpro`.`SPRO_CLIENTE`.`BAIRRO`                                                        AS `BAIRRO`,
                `superpro`.`SPRO_CLIENTE`.`CIDADE`                                                        AS `CIDADE`,
                `superpro`.`SPRO_CLIENTE`.`UF`                                                            AS `UF`,
                `superpro`.`SPRO_CLIENTE`.`PAIS`                                                          AS `PAIS`,
                `superpro`.`SPRO_CLIENTE`.`EMAIL`                                                         AS `EMAIL`,
                concat(`superpro`.`SPRO_CLIENTE`.`DDD_CELULAR`, `superpro`.`SPRO_CLIENTE`.`FONE_CELULAR`) AS `CELULAR`,
                concat(`superpro`.`SPRO_CLIENTE`.`DDD_RESID`, `superpro`.`SPRO_CLIENTE`.`FONE_RESID`)     AS `TELEFONE`,
                `superpro`.`SPRO_CLIENTE`.`DATA_REGISTRO`                                                 AS `DT_REGISTROS`
from `superpro`.`SPRO_CLIENTE`;

