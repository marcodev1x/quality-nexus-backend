create definer = admin@`%` trigger questaoBeforeInsert
    before insert
    on SPRO_BCO_QUESTAO
    for each row
BEGIN
	SET NEW.LINK_EXTERNO = 0;
	IF (NEW.TEXTO_IMGQUESTAO LIKE '%http:%' OR NEW.TEXTO_IMGQUESTAO LIKE '%www.%'
	OR NEW.TEXTO_QUESTAO LIKE '%http:%' OR NEW.TEXTO_QUESTAO LIKE '%www.%'
	OR NEW.ENUNCIADO LIKE '%http:%' OR NEW.ENUNCIADO LIKE '%www:%') THEN
		SET NEW.LINK_EXTERNO = 1;
	END IF;
END;

