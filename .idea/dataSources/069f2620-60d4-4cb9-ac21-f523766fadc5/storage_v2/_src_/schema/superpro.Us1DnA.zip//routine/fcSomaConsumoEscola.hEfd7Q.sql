create
    definer = admin@`%` function fcSomaConsumoEscola(dataHoraIni char(20), dataHoraFim char(20), idEscola int) returns int
BEGIN
	#Routine body goes here...
	DECLARE totalConsumo INT;
	DECLARE listIdProfessores TEXT;

	SET totalConsumo = 0;

	IF (LENGTH(dataHoraIni) >= 19 AND LENGTH(dataHoraFim) >= 19) THEN
		SELECT
			SUM(DEBITO) INTO @consumo
		FROM
			SPRO_HISTORICO_GERADOC TB1, SPRO_CLIENTE TB2
		WHERE
		TB1.ID_LOGIN = TB2.ID_CLIENTE
		AND TB2.ID_MATRIZ = idEscola
		AND TB1.DATA_REGISTRO >= dataHoraIni
		AND TB1.DATA_REGISTRO <= dataHoraFim;

		IF (@consumo > 0) THEN
			SET totalConsumo = @consumo;
		END IF;
	END IF;
	RETURN totalConsumo;
END;

