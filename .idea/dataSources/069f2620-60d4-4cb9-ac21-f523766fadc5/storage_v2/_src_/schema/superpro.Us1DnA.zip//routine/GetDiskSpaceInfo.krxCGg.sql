create
    definer = staging@`%` procedure GetDiskSpaceInfo()
BEGIN
    DECLARE total_space_gb DECIMAL(10, 2);
    DECLARE free_space_gb DECIMAL(10, 2);
    DECLARE used_space_percent DECIMAL(10, 2);

    SELECT 
        ROUND(SUM(data_length + index_length) / 1024 / 1024 / 1024, 2) INTO total_space_gb
    FROM 
        information_schema.tables;

    SELECT
        ROUND(SUM(data_free) / 1024 / 1024 / 1024, 2) INTO free_space_gb
    FROM
        information_schema.tables;

    SET used_space_percent = 100 - (free_space_gb / total_space_gb * 100);

    SELECT
        'Total' AS Mount,
        '' AS Volume,
        total_space_gb AS 'Total (GB)',
        free_space_gb AS 'Espaço Disponível (GB)',
        used_space_percent AS 'Espaço em uso (%)';
END;

