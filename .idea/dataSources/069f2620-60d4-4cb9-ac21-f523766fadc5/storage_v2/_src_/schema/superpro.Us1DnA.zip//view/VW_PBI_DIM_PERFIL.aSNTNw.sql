create definer = admin@`%` view VW_PBI_DIM_PERFIL as
select `sap`.`ID_AUTH_PERFIL` AS `ID_AUTH_PERFIL`, `sap`.`PERFIL` AS `PERFIL`, `sap`.`TIPO` AS `TIPO`
from `superpro`.`SPRO_AUTH_PERFIL` `sap`;

