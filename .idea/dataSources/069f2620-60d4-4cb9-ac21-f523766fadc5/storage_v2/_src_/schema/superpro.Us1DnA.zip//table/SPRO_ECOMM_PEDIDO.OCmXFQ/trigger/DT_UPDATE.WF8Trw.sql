create definer = admin@`%` trigger DT_UPDATE
    before update
    on SPRO_ECOMM_PEDIDO
    for each row
BEGIN
    SET NEW.DATA_ALTERADO = NOW();
END;

