create
    definer = admin@`%` function fcAdmResumoConsumo(idMantenedora int, dataIni datetime, dataFim datetime) returns varchar(255)
BEGIN
	DECLARE idProfessor, finished, totalRegUpdated INTEGER DEFAULT 0;
	
	#Média consumo/mês, por professor
	DECLARE myCursor CURSOR FOR
	SELECT ID_CLIENTE AS idProfessor FROM SPRO_CLIENTE WHERE ID_MATRIZ IN (@lst_escolas);
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET finished = 1;
	OPEN myCursor;
	
	# Total Professores
	SET @lst_escolas := '';
	SELECT GROUP_CONCAT(ID_CLIENTE) INTO @lst_escolas FROM SPRO_CLIENTE WHERE ID_MATRIZ = idMantenedora;

	SELECT COUNT(1) INTO @value_ FROM SPRO_CLIENTE WHERE ID_MATRIZ IN (@lst_escolas);

	REPLACE INTO SPRO_ADM_RESUMO_CONSUMO (ID_MANTENEDORA, VARIABLE, VALUE, DATA_REGISTRO) 
	VALUES(idMantenedora, 'TOTAL_PROFESSORES', @value_, NOW());


	loopSelect: LOOP		
		# O valor de varIgnoreThis é CASE INSENSITIVE;
		FETCH myCursor INTO idProfessor;

		SET @mes := '';
		SET @ano := '';
		SET @idEscola := '';

		IF (idProfessor > 0) THEN
			SELECT SUM(DEBITO), (SELECT ID_MATRIZ FROM SPRO_USER TB2 WHERE TB2.ID_USER = TB1.ID_LOGIN) AS ID_MATRIZ, 
			MONTH(DATA_REGISTRO) AS MES, YEAR(DATA_REGISTRO) AS ANO INTO @value_, @mes, @ano, @idEscola
			FROM SPRO_HISTORICO_GERADOC TB1 WHERE ID_LOGIN = idProfessor AND 
			DATA_REGISTRO >= dataIni AND DATA_REGISTRO <= dataFim;

			REPLACE INTO SPRO_ADM_RESUMO_CONSUMO (ID_MANTENEDORA, ID_ESCOLA, ID_PROFESSOR, VARIABLE, VALUE, DATA_REGISTRO) 
			VALUES(idMantenedora, @idEscola, idProfessor,  CONCAT('CONSUMO_',@mes,'_',@ano), @value_, NOW());

		END IF;
		IF finished = 1 THEN 
			LEAVE loopSelect;
		END IF;
	END LOOP loopSelect;

  CLOSE myCursor;

	RETURN '';
END;

