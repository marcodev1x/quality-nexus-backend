create
    definer = admin@`%` function fcCalcResgates(ano int, mes_ini int, mes_fim int) returns int
BEGIN
	
	declare resgates int default 0; 
	declare fim int default 0; 
	declare tem_compra int default 0;
	declare cliente int;
	declare data_r datetime; 
	declare data_v date;

	declare c cursor for
	select  sep.ID_CLIENTE,
			sep.DATA_REGISTRO as data_resgate,
			(select MAX(scc2.VENCIMENTO) 
	        from SPRO_ECOMM_PEDIDO sep2
	        join SPRO_CREDITO_CONSOLIDADO scc2 
				on sep2.NUM_PEDIDO = scc2.NUM_PEDIDO
	       	where sep2.ID_CLIENTE = sc.ID_CLIENTE
	       	 and scc2.OPERACAO = 'C'
	       	 and sep2.ID_STATUS_LOJA = 1
	         and date(scc2.VENCIMENTO) < date(sep.DATA_REGISTRO)) as ult_venc
	  from SPRO_ECOMM_PEDIDO sep
	  join SPRO_VW_CLIENTE_VALIDO sc
	    on sc.ID_CLIENTE = sep.ID_CLIENTE
	  join SPRO_CREDITO_CONSOLIDADO scc 
	    on sep.NUM_PEDIDO = scc.NUM_PEDIDO
	 where scc.OPERACAO = 'C'
	   and sep.ID_STATUS_LOJA = 1
	   and date(sep.DATA_REGISTRO) between CONCAT(ano,'-', mes_ini,'-01') and CONCAT(ano,'-', mes_fim,'-31')
	   and (select max(scc2.VENCIMENTO)
		    from SPRO_ECOMM_PEDIDO sep2
		    join SPRO_CREDITO_CONSOLIDADO scc2 
				on sep2.NUM_PEDIDO = scc2.NUM_PEDIDO
		   where sep2.ID_CLIENTE = sc.ID_CLIENTE
		   	 and scc2.OPERACAO = 'C'
		   	 and sep2.ID_STATUS_LOJA = 1
		     and sep2.DATA_REGISTRO < sep.DATA_REGISTRO) < date(sep.DATA_REGISTRO);
	                
	declare continue handler for not found set fim = 1;
	                
	open c;
	
	while fim=0 do 
	
		fetch c into cliente, data_r, data_v;
		
		if fim = 0 then
	
			SELECT count(sep.NUM_PEDIDO) into tem_compra
			from SPRO_ECOMM_PEDIDO sep 
			join SPRO_CREDITO_CONSOLIDADO scc 
			on scc.NUM_PEDIDO = sep.NUM_PEDIDO 
			where sep.ID_STATUS_LOJA = 1
			and scc.OPERACAO = 'C'
			and sep.ID_CLIENTE = cliente 
			and date(sep.DATA_REGISTRO) > data_v 
			and sep.DATA_REGISTRO < data_r;
		
			/*SELECT cliente, tem_compra, data_r, data_v;*/
		
			if (tem_compra = 0 or tem_compra is null) then 
				set resgates = resgates + 1;
			end if;
			
		
			set tem_compra =0;
	
		end if;
	
	end while;

	close c;
	

	return resgates;	

END;

