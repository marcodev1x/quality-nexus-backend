create definer = staging@`%` view VW_BANDEIRA_ULTIMAS_TRANSACAO as
select `t2`.`pedido_id` AS `pedido_id`, `t2`.`bandeira_cartao` AS `bandeira_cartao`
from (`superpro`.`transacoes` `t2` join (select max(`t`.`id`) AS `id`
                                         from `superpro`.`transacoes` `t`
                                         group by `t`.`pedido_id`) `tab` on ((`tab`.`id` = `t2`.`id`)));

