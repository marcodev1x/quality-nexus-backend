create definer = admin@`%` trigger ecomm_AFTER_UPD
    after update
    on SPRO_ECOMM_PEDIDO
    for each row
BEGIN
	IF (NEW.ID_STATUS_LOJA = 1 AND NEW.ID_STATUS_LOJA != OLD.ID_STATUS_LOJA) THEN
		# O status do pedido foi alterado para aprovado.
		# Verificar se é a primeira compra do cliente
		SELECT COUNT(1) INTO @pedidosAprovados FROM SPRO_ECOMM_PEDIDO
		WHERE ID_STATUS_LOJA = 1 AND NUM_PEDIDO != NEW.NUM_PEDIDO
		AND ID_CLIENTE = NEW.ID_CLIENTE;
	
		# Retira o bloqueio do cliente, se houver
		UPDATE SPRO_CLIENTE SET BLOQ = 0 
		WHERE ID_CLIENTE = NEW.ID_CLIENTE AND BLOQ = 2;
	ELSEIF (NEW.ID_MEIO_PGTO = 1 AND NEW.ID_STATUS_LOJA = 2  AND (NEW.ID_STATUS_LOJA != OLD.ID_STATUS_LOJA OR OLD.ID_STATUS_LOJA IS NULL)) THEN
		# O pedido foi feito com boleto e o status foi alterado para pendente
		# Verificar se é a primeira compra do cliente
		SELECT COUNT(1) INTO @pedidosAprovados FROM SPRO_ECOMM_PEDIDO
		WHERE ID_STATUS_LOJA = 1 AND NUM_PEDIDO != NEW.NUM_PEDIDO
		AND ID_CLIENTE = NEW.ID_CLIENTE;

		SELECT fcCalcSaldo(NEW.ID_CLIENTE) INTO @saldoAtual;

		IF (@pedidosAprovados = 0 OR @saldoAtual = 0) THEN
			UPDATE SPRO_CLIENTE SET BLOQ = 2 WHERE ID_CLIENTE = NEW.ID_CLIENTE;
		END IF;
	END IF;
END;

