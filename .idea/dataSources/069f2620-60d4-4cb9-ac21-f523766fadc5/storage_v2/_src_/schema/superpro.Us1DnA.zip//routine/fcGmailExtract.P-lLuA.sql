create
    definer = admin@`%` function fcGmailExtract(dataEnIni char(10), dataEnFim char(10)) returns text
BEGIN
	# 17/06/2016
	# Function usada para extrair usuários com e-mails @gmail.
  # Um registro pode ser do tipo IN indicando tratar-se de um novo usuário (prospect), ou 
  # OUT, indicando tratar-se de um assinante. Ao final, o objetivo é permitir a extração de duas listas, 
  # uma IN e outra OUT, que serão enviadas ao Google para remarketing via AdWords. 
  # A publicidade direcionada aparecerá para usuários do GMAIL que estejam na lista IN. E, no sentido contrário, 
  # usuários da lista OUT não devem ver essa publicidade.
  # exemplo de parâmetro: "2016-06-07","2016-06-24"
	# verificar tabela SPRO_GMAIL_EXTRACT após executar função
	# @author Claudio Rubens Silva Filho

	DECLARE msgOut TEXT;
	DECLARE diaSemanaIni, diaSemanaFim, totalRegistros INT;
	DECLARE dataAgora DATETIME;

	SET msgOut = '';
	SET dataAgora = NOW();

	# Verifica se as datas informadas são válidas
	SELECT DATE_FORMAT( dataEnIni, '%w' ) INTO diaSemanaIni;
	SELECT DATE_FORMAT( dataEnFim, '%w' ) INTO diaSemanaFim;

	IF (diaSemanaIni > 0 AND diaSemanaFim > 0) THEN
		# Localizar e-mails novos do período e que ainda não compraram
		REPLACE INTO SPRO_GMAIL_EXTRACT (EMAIL, ACAO, NUM_PEDIDO, DATA_REGISTRO) (
				SELECT	
					EMAIL,
					'IN' AS ACAO, 
					0 AS ULTIMO_PEDIDO,
					dataAgora AS DATA_REGISTRO
				FROM
					SPRO_CLIENTE TB_CLI
				WHERE
					(
						(
							`TB_CLI`.`ID_MATRIZ` = 0
						)
						AND (
							`TB_CLI`.`EMAIL` LIKE '%@gmail%'
						)
						AND (
							cast(
								`TB_CLI`.`DATA_REGISTRO` AS date
							) >= dataEnIni
						)
						AND (
							cast(
								`TB_CLI`.`DATA_REGISTRO` AS date
							) <= dataEnFim
						)

						AND (
							SELECT COUNT(1) FROM SPRO_CREDITO_CONSOLIDADO TB_CC 
							WHERE TB_CC.ID_CLIENTE = TB_CLI.ID_CLIENTE 
							AND TB_CC.NUM_PEDIDO > 0 AND VENCIMENTO >= DATE(NOW())							
						) = 0
					)
					
				GROUP BY
					`TB_CLI`.`EMAIL`
				ORDER BY
					`TB_CLI`.`DATA_REGISTRO` DESC
		);

		# Localizar novos pedidos: OUT
		REPLACE INTO SPRO_GMAIL_EXTRACT (EMAIL, ACAO, NUM_PEDIDO, DATA_REGISTRO) (
				SELECT	
					`TB1`.`EMAIL_CLIENTE` AS EMAIL,
					IF ((
							SELECT COUNT(1) 
							FROM SPRO_CREDITO_CONSOLIDADO TB2 
							WHERE TB2.ID_CLIENTE = TB1.ID_CLIENTE 
							AND VENCIMENTO >= DATE(NOW()) AND TB2.NUM_PEDIDO > 0
							) > 0,'OUT','IN'
					) AS ACAO, 
				(
					SELECT MAX(NUM_PEDIDO)
					FROM SPRO_CREDITO_CONSOLIDADO TB2 
					WHERE TB2.ID_CLIENTE = TB1.ID_CLIENTE 
					AND VENCIMENTO >= DATE(NOW()) AND TB2.NUM_PEDIDO > 0 LIMIT 1
				) AS ULTIMO_PEDIDO,
				dataAgora AS DATA_REGISTRO
				FROM
					`SPRO_ECOMM_PEDIDO` TB1 INNER JOIN SPRO_GMAIL_DB TB_DB ON TB1.EMAIL_CLIENTE = TB_DB.EMAIL
				WHERE
					(
						(
							`TB1`.`ID_STATUS_LOJA` = 1
						)
						AND (
							`TB1`.`EMAIL_CLIENTE` LIKE '%@gmail%'
						)
						AND (
							cast(
								`TB1`.`DATA_REGISTRO` AS date
							) >= dataEnIni
						)
						AND (
							cast(
								`TB1`.`DATA_REGISTRO` AS date
							) <= dataEnFim
						)
					)
				GROUP BY
					`TB1`.`EMAIL_CLIENTE`
				HAVING ACAO = 'OUT'
				ORDER BY
					`TB1`.`DATA_REGISTRO` DESC
		);

		# Exclui registros que não estão na lista inicial enviada ao GMAIL
		DELETE FROM SPRO_GMAIL_EXTRACT WHERE EMAIL NOT IN (SELECT EMAIL FROM SPRO_GMAIL_DB);


		# Localiza o total de registros extraídos
		SELECT COUNT(*) INTO totalRegistros FROM SPRO_GMAIL_EXTRACT WHERE DATA_REGISTRO = dataAgora;

		SELECT CONCAT("Total de registros extraídos no período: ",totalRegistros) INTO msgOut;
	ELSE
		SET msgOut = "Necessário informar uma data de início e outra de fim, nessa ordem, no formato YYYY-mm-dd.";
	END IF;

	RETURN msgOut;
END;

