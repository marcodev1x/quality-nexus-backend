create
    definer = admin@`%` function fcRecuperarSaldoAnterior_vazio(VAR_ID_CLIENTE int) returns int
BEGIN
	# Localiza o saldo anterior à última compra que pode ser resgatado.
	# @return int total de créditos passíveis de resgate.
	DECLARE VAR_ID_CLIENTE_TMP INT;	
	DECLARE SALDO_ANT INT;
	DECLARE ID_REG_SALDO_ANT INT;       
	DECLARE VAR_VENCIMENTO_ULTIMO_PED DATE;
	DECLARE VAR_VENCIMENTO_ANT DATE;
  DECLARE VAR_OUT INT;
	DECLARE RETORNO DATE;
	DECLARE DIF_DATA INT;

	SET VAR_ID_CLIENTE_TMP  = 999999;
	SET VAR_OUT 		= -1;



	RETURN 0;
END;

