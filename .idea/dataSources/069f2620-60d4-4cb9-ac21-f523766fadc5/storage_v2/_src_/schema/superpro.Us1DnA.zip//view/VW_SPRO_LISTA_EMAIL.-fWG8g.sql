create definer = staging@`%` view VW_SPRO_LISTA_EMAIL as
select `TB`.`EMAIL`                       AS `EMAIL`,
       (select count(0) AS `COUNT(*)`
        from `superpro`.`SPRO_CREDITO_CONSOLIDADO` `TB1`
        where ((`TB1`.`ID_CLIENTE` = `TB`.`ID_CLIENTE`) and (`TB1`.`CREDITO` >= 200) and (`TB1`.`CREDITO` <= 800) and
               (`TB1`.`NUM_PEDIDO` > 0))) AS `ASSINANTE`
from `superpro`.`SPRO_CLIENTE` `TB`
where ((not ((`TB`.`EMAIL` like '%supervip%'))) and (not ((`TB`.`EMAIL` like '%interbits%'))) and
       (`TB`.`ID_MATRIZ` = 0) and (`TB`.`ID_FILIAL` = 0) and (`TB`.`PF_PJ` = 'PF') and
       ((`TB`.`ID_AUTH_PERFIL` <> 6) or (`TB`.`ID_AUTH_PERFIL` is null)))
order by (select count(0) AS `COUNT(*)`
          from `superpro`.`SPRO_CREDITO_CONSOLIDADO` `TB1`
          where ((`TB1`.`ID_CLIENTE` = `TB`.`ID_CLIENTE`) and (`TB1`.`CREDITO` >= 200) and (`TB1`.`CREDITO` <= 800) and
                 (`TB1`.`NUM_PEDIDO` > 0))) desc;

