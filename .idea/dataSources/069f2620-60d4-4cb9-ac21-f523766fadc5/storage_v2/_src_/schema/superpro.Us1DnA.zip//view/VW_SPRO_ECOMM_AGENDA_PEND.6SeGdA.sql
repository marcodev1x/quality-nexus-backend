create definer = admin@`%` view VW_SPRO_ECOMM_AGENDA_PEND as
select `TB3`.`ID_AGENDA_PGTO`                                                                                   AS `ID_AGENDA_PGTO`,
       `TB2`.`ID_CLIENTE`                                                                                       AS `ID_CLIENTE`,
       count(0)                                                                                                 AS `NUM_PARC`,
       `TB1`.`CREDITOS`                                                                                         AS `CREDITOS`,
       (select `TB`.`EMAIL`
        from `superpro`.`SPRO_CLIENTE` `TB`
        where (`TB`.`ID_CLIENTE` = `TB2`.`ID_CLIENTE`))                                                         AS `EMAIL_CLIENTE`,
       `TB1`.`VALOR_TOTAL`                                                                                      AS `VALOR_TOTAL`,
       `TB3`.`VALOR`                                                                                            AS `VALOR_PARC`,
       `TB1`.`DATA_REGISTRO`                                                                                    AS `DATA_COMPRA`,
       date_format(`TB1`.`DATA_REGISTRO`, '%d/%m/%Y')                                                           AS `DATA_COMPRA_BR`,
       date_format(`TB2`.`DATA_REGISTRO`, '%d/%m/%Y')                                                           AS `DATA_PRI_PGTO_BR`,
       `TB2`.`DATA_REGISTRO`                                                                                    AS `DATA_PRI_PGTO`,
       `TB3`.`NUM_PEDIDO`                                                                                       AS `NUM_PEDIDO`
from ((`superpro`.`SPRO_ECOMM_PEDIDO` `TB1` join `superpro`.`SPRO_CREDITO_CONSOLIDADO` `TB2`) join `superpro`.`SPRO_ECOMM_AGENDA_PGTO` `TB3`)
where ((`TB2`.`NUM_PEDIDO` = `TB3`.`NUM_PEDIDO`) and (`TB1`.`NUM_PEDIDO` = `TB3`.`NUM_PEDIDO`) and
       (ifnull(`TB3`.`NUM_PEDIDO_COBRANCA`, 0) = 0))
group by `TB3`.`NUM_PEDIDO`;

