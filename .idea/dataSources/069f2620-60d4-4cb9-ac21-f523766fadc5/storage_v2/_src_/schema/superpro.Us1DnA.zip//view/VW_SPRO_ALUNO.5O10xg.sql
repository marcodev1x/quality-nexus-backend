create definer = admin@`%` view VW_SPRO_ALUNO as
select `superpro`.`SPRO_CLIENTE`.`ID_CLIENTE`     AS `ID_CLIENTE`,
       `superpro`.`SPRO_CLIENTE`.`NOME_PRINCIPAL` AS `NOME_PRINCIPAL`,
       `superpro`.`SPRO_CLIENTE`.`EMAIL`          AS `EMAIL`
from `superpro`.`SPRO_CLIENTE`
where ((`superpro`.`SPRO_CLIENTE`.`ID_AUTH_PERFIL` = 7) and
       (not ((`superpro`.`SPRO_CLIENTE`.`EMAIL` like '%interbits%'))) and
       (not ((`superpro`.`SPRO_CLIENTE`.`EMAIL` like '%supervip%'))) and
       (not ((`superpro`.`SPRO_CLIENTE`.`EMAIL` like '%teste%'))) and `superpro`.`SPRO_CLIENTE`.`EMAIL` in
                                                                      (select `superpro`.`SPRO_MAIL_BLK_LIST`.`EMAIL`
                                                                       from `superpro`.`SPRO_MAIL_BLK_LIST`) is false and
       `superpro`.`SPRO_CLIENTE`.`ID_CLIENTE` in (select `superpro`.`SPRO_CREDITO_CONSOLIDADO`.`ID_CLIENTE`
                                                  from `superpro`.`SPRO_CREDITO_CONSOLIDADO`) is false and
       (`superpro`.`SPRO_CLIENTE`.`ID_MATRIZ` = 0))
order by `superpro`.`SPRO_CLIENTE`.`ID_CLIENTE`;

