create definer = admin@`%` view VW_PBI_DIM_TOPICO as
select `tq`.`ID_TOPICO` AS `ID_TOPICO`, `tq`.`TOPICO` AS `TOPICO`
from `superpro`.`SPRO_TOPICO_QUESTAO` `tq`;

