create
    definer = admin@`%` function fcProrrogaTd(idUser int) returns int
BEGIN
	#Verifica se o usuário possui crédito de TD e redefine o vencimento para a data atual + 48h
	#@author Claudio Rubens Silva Filho
	DECLARE dataIni, dataVencEn DATE;
	DECLARE idCreditoConsolidado, msgCode INT;

	SET idCreditoConsolidado = 0;
	SET dataVencEn = NULL;
	SET msgCode = 0;

	IF (idUser > 0) THEN
		SET @novaDataVencEn := DATE_ADD(DATE(NOW()),INTERVAL 2 DAY);
		SELECT DATE_ADD(DATE(NOW()),INTERVAL -14 DAY) INTO dataIni FROM DUAL;

		SELECT ID_CREDITO_CONSOLIDADO, VENCIMENTO INTO idCreditoConsolidado, dataVencEn FROM SPRO_CREDITO_CONSOLIDADO WHERE ID_CLIENTE = idUser AND MOTIVO LIKE 'Degusta%' 
		AND NUM_PEDIDO = 0 AND BONUS = 1 AND DATE(DATA_REGISTRO) >= dataIni AND (VENCIMENTO_ORIG IS NULL OR VENCIMENTO_ORIG = '0000-00-00')
		AND VENCIMENTO < @novaDataVencEn ORDER BY DATA_REGISTRO DESC LIMIT 1;

		IF (dataVencEn IS NOT NULL AND idCreditoConsolidado > 0) THEN
			# Modificar a data de vencimento do TD para hoje + 2 dias			
			UPDATE SPRO_CREDITO_CONSOLIDADO SET VENCIMENTO = @novaDataVencEn, VENCIMENTO_ORIG = dataVencEn 
			WHERE ID_CREDITO_CONSOLIDADO = idCreditoConsolidado;
			SET msgCode = 1; # Data alterada com sucesso
		ELSE 
			# Não há um registro a ser alterado
			SET msgCode = 2;
		END IF;
	END IF;
	RETURN msgCode;
END;

