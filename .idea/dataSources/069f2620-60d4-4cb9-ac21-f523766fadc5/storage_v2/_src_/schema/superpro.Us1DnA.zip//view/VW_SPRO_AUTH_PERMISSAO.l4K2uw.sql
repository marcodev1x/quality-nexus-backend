create definer = admin@`%` view VW_SPRO_AUTH_PERMISSAO as
select `TB`.`ID_AUTH_PERMISSAO`                         AS `ID_AUTH_PERMISSAO`,
       `TB`.`ID_DEP`                                    AS `ID_DEP`,
       `TB`.`PERMISSAO`                                 AS `PERMISSAO`,
       `TB`.`URL_PERMISSAO`                             AS `URL_PERMISSAO`,
       `TB`.`ICONE`                                     AS `ICONE`,
       `TB`.`COMUM_A_TODOS`                             AS `COMUM_A_TODOS`,
       `TB`.`ORDEM`                                     AS `ORDEM`,
       if((`TB`.`ID_DEP` > 0), if((ifnull((select `TB1`.`ID_DEP` AS `ID_DEP`
                                           from `superpro`.`SPRO_AUTH_PERMISSAO` `TB1`
                                           where (`TB1`.`ID_AUTH_PERMISSAO` = `TB`.`ID_DEP`)), 0) > 0), 'MENU_SUBITEM',
                                  'MENU_ITEM'), 'MENU') AS `TIPO`
from `superpro`.`SPRO_AUTH_PERMISSAO` `TB`;

