create definer = staging@`%` view SPRO_VW_CLASSIFICACAO_QUESTAO as
select `superpro`.`SPRO_CLASSIFICACAO_QUESTAO`.`ID_CLASSIFICACAO`   AS `ID_CLASSIFICACAO`,
       `superpro`.`SPRO_CLASSIFICACAO_QUESTAO`.`ID_BCO_QUESTAO`     AS `ID_BCO_QUESTAO`,
       `superpro`.`SPRO_CLASSIFICACAO_QUESTAO`.`ID_TOPICO`          AS `ID_TOPICO`,
       `superpro`.`SPRO_CLASSIFICACAO_QUESTAO`.`ID_ITEM`            AS `ID_ITEM`,
       `superpro`.`SPRO_CLASSIFICACAO_QUESTAO`.`ID_SUBITEM`         AS `ID_SUBITEM`,
       `superpro`.`SPRO_CLASSIFICACAO_QUESTAO`.`ID_SISTEMA`         AS `ID_SISTEMA`,
       `superpro`.`SPRO_CLASSIFICACAO_QUESTAO`.`DATA_REGISTRO`      AS `DATA_REGISTRO`,
       `superpro`.`SPRO_MATERIA_QUESTAO`.`MATERIA`                  AS `MATERIA`,
       `superpro`.`SPRO_MATERIA_QUESTAO`.`TIPO_ENSINO`              AS `TIPO_ENSINO`,
       `superpro`.`SPRO_MATERIA_QUESTAO`.`FOLDER`                   AS `FOLDER`,
       `superpro`.`SPRO_DIVISAO_QUESTAO`.`DIVISAO`                  AS `DIVISAO`,
       `superpro`.`SPRO_TOPICO_QUESTAO`.`TOPICO`                    AS `TOPICO`,
       `superpro`.`SPRO_ITEM_QUESTAO`.`NOME_ITEM`                   AS `NOME_ITEM`,
       `superpro`.`SPRO_SUBITEM_QUESTAO`.`SUBITEM`                  AS `SUBITEM`,
       `superpro`.`SPRO_SISTEMA`.`SISTEMA`                          AS `SISTEMA`,
       concat(`superpro`.`SPRO_CLASSIFICACAO_QUESTAO`.`ID_MATERIA`, '_',
              `superpro`.`SPRO_CLASSIFICACAO_QUESTAO`.`ID_DIVISAO`, '_',
              `superpro`.`SPRO_CLASSIFICACAO_QUESTAO`.`ID_TOPICO`, '_',
              `superpro`.`SPRO_CLASSIFICACAO_QUESTAO`.`ID_ITEM`, '_',
              `superpro`.`SPRO_CLASSIFICACAO_QUESTAO`.`ID_SUBITEM`) AS `CODIGO`,
       `superpro`.`SPRO_CLASSIFICACAO_QUESTAO`.`ID_DIVISAO`         AS `ID_DIVISAO`,
       `superpro`.`SPRO_BCO_QUESTAO`.`DATA_PUB`                     AS `DATA_PUB`,
       `superpro`.`SPRO_BCO_QUESTAO`.`ID_TEXTO`                     AS `ID_TEXTO`,
       `superpro`.`SPRO_BCO_QUESTAO`.`ANO`                          AS `ANO`,
       `superpro`.`SPRO_BCO_QUESTAO`.`ARQ_PDF_ENUN`                 AS `ARQ_PDF_ENUN`,
       `superpro`.`SPRO_BCO_QUESTAO`.`ARQ_PDF_RESO`                 AS `ARQ_PDF_RESO`,
       `superpro`.`SPRO_BCO_QUESTAO`.`TAM_UNID`                     AS `TAM_UNID`,
       `superpro`.`SPRO_BCO_QUESTAO`.`TAM_BYTES`                    AS `TAM_BYTES`,
       `superpro`.`SPRO_BCO_QUESTAO`.`FLAG`                         AS `FLAG`,
       `superpro`.`SPRO_BCO_QUESTAO`.`TOTAL_USO`                    AS `TOTAL_USO`,
       `superpro`.`SPRO_BCO_QUESTAO`.`DATA_HR_USO_ULTIMA_VEZ`       AS `DATA_HR_USO_ULTIMA_VEZ`,
       `superpro`.`SPRO_FONTE_VESTIBULAR`.`FONTE_VESTIBULAR`        AS `FONTE_VESTIBULAR`,
       `superpro`.`SPRO_TAX_BLOOM`.`CODIGO`                         AS `TAX_BLOOM`,
       `superpro`.`SPRO_UF`.`SIGLA`                                 AS `SIGLA`,
       `superpro`.`SPRO_REGIAO`.`REGIAO`                            AS `REGIAO`,
       `superpro`.`SPRO_CLASSIFICACAO_QUESTAO`.`OBS`                AS `OBS`,
       `superpro`.`SPRO_CLASSIFICACAO_QUESTAO`.`FLAG`               AS `FLAG_CLASSIF`,
       `superpro`.`SPRO_BCO_QUESTAO`.`ID_TIPO_QUESTAO`              AS `ID_TIPO_QUESTAO`,
       `superpro`.`SPRO_MATERIA_QUESTAO`.`COMPET_HABILID`           AS `COMPET_HABILID`,
       `superpro`.`SPRO_BCO_QUESTAO`.`ERRO_IMG`                     AS `ERRO_IMG`,
       `superpro`.`SPRO_BCO_QUESTAO`.`BLOQ_EDIT`                    AS `BLOQ_EDIT`,
       `superpro`.`SPRO_BCO_QUESTAO`.`TEXTO_QUESTAO`                AS `TEXTO_QUESTAO`,
       `superpro`.`SPRO_BCO_QUESTAO`.`TEXTO_IMGQUESTAO`             AS `TEXTO_IMGQUESTAO`,
       `superpro`.`SPRO_BCO_QUESTAO`.`ID_GRAU_DIFICULDADE`          AS `ID_GRAU_DIFICULDADE`,
       `superpro`.`SPRO_BCO_QUESTAO`.`FIGR`                         AS `FIGR`,
       `superpro`.`SPRO_BCO_QUESTAO`.`FIG`                          AS `FIG`,
       `superpro`.`SPRO_REGIAO`.`ID_REGIAO`                         AS `ID_REGIAO`,
       `superpro`.`SPRO_BCO_QUESTAO`.`ID_FONTE_VESTIBULAR`          AS `ID_FONTE_VESTIBULAR`,
       `superpro`.`SPRO_CLASSIFICACAO_QUESTAO`.`ID_MATERIA`         AS `ID_MATERIA`,
       `superpro`.`SPRO_CLASSIFICACAO_QUESTAO`.`PRINCIPAL`          AS `PRINCIPAL`,
       `superpro`.`SPRO_BCO_QUESTAO`.`ID_STATUS_QUESTAO`            AS `ID_STATUS_QUESTAO`,
       `superpro`.`SPRO_BCO_QUESTAO`.`ID_AUTH_USUARIO`              AS `ID_AUTH_USUARIO`,
       `superpro`.`SPRO_BCO_QUESTAO`.`ID_AUTH_COLABORADOR`          AS `ID_AUTH_COLABORADOR`,
       `superpro`.`SPRO_BCO_QUESTAO`.`ID_TAX_BLOOM`                 AS `ID_TAX_BLOOM`,
       `superpro`.`SPRO_BCO_QUESTAO`.`GABARITO`                     AS `GABARITO`,
       `superpro`.`SPRO_BCO_QUESTAO`.`DATA_UPDATE`                  AS `DATA_UPDATE`,
       `superpro`.`SPRO_BCO_QUESTAO`.`DATA_HR_ULT_EDICAO`           AS `DATA_HR_ULT_EDICAO`,
       `superpro`.`SPRO_BCO_QUESTAO`.`AVALIACAO_NUM_PONTOS`         AS `AVALIACAO_NUM_PONTOS`,
       `superpro`.`SPRO_BCO_QUESTAO`.`AVALIACAO_NUM_VOTOS`          AS `AVALIACAO_NUM_VOTOS`,
       `superpro`.`SPRO_CLASSIFICACAO_QUESTAO`.`DATA_HR_REF`        AS `DATA_HR_REF`
from (((((((((((`superpro`.`SPRO_CLASSIFICACAO_QUESTAO` join `superpro`.`SPRO_MATERIA_QUESTAO`
                on ((`superpro`.`SPRO_MATERIA_QUESTAO`.`ID_MATERIA` =
                     `superpro`.`SPRO_CLASSIFICACAO_QUESTAO`.`ID_MATERIA`))) left join `superpro`.`SPRO_DIVISAO_QUESTAO`
               on ((`superpro`.`SPRO_DIVISAO_QUESTAO`.`ID_DIVISAO` =
                    `superpro`.`SPRO_CLASSIFICACAO_QUESTAO`.`ID_DIVISAO`))) left join `superpro`.`SPRO_TOPICO_QUESTAO`
              on ((`superpro`.`SPRO_TOPICO_QUESTAO`.`ID_TOPICO` =
                   `superpro`.`SPRO_CLASSIFICACAO_QUESTAO`.`ID_TOPICO`))) left join `superpro`.`SPRO_ITEM_QUESTAO`
             on ((`superpro`.`SPRO_ITEM_QUESTAO`.`ID_ITEM` =
                  `superpro`.`SPRO_CLASSIFICACAO_QUESTAO`.`ID_ITEM`))) left join `superpro`.`SPRO_SUBITEM_QUESTAO`
            on ((`superpro`.`SPRO_SUBITEM_QUESTAO`.`ID_SUBITEM` =
                 `superpro`.`SPRO_CLASSIFICACAO_QUESTAO`.`ID_SUBITEM`))) left join `superpro`.`SPRO_SISTEMA`
           on ((`superpro`.`SPRO_SISTEMA`.`ID_SISTEMA` =
                `superpro`.`SPRO_CLASSIFICACAO_QUESTAO`.`ID_SISTEMA`))) join `superpro`.`SPRO_BCO_QUESTAO`
          on ((`superpro`.`SPRO_BCO_QUESTAO`.`ID_BCO_QUESTAO` =
               `superpro`.`SPRO_CLASSIFICACAO_QUESTAO`.`ID_BCO_QUESTAO`))) left join `superpro`.`SPRO_TAX_BLOOM`
         on ((`superpro`.`SPRO_TAX_BLOOM`.`ID_TAX_BLOOM` =
              `superpro`.`SPRO_BCO_QUESTAO`.`ID_TAX_BLOOM`))) join `superpro`.`SPRO_FONTE_VESTIBULAR`
        on ((`superpro`.`SPRO_FONTE_VESTIBULAR`.`ID_FONTE_VESTIBULAR` =
             `superpro`.`SPRO_BCO_QUESTAO`.`ID_FONTE_VESTIBULAR`))) join `superpro`.`SPRO_UF`
       on ((`superpro`.`SPRO_UF`.`ID_UF` = `superpro`.`SPRO_FONTE_VESTIBULAR`.`ID_UF`))) join `superpro`.`SPRO_REGIAO`
      on ((`superpro`.`SPRO_REGIAO`.`ID_REGIAO` = `superpro`.`SPRO_UF`.`ID_REGIAO`)))
where (`superpro`.`SPRO_BCO_QUESTAO`.`DATA_PUB` is not null);

