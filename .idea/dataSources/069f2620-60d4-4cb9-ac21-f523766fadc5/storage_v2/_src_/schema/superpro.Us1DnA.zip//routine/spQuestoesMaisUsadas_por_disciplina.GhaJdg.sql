create
    definer = admin@`%` procedure spQuestoesMaisUsadas_por_disciplina(IN $mes int, IN $ano int, IN $limit int)
BEGIN
	DECLARE thisLimit, idMateria, thisYear, thisMonth, finished INTEGER DEFAULT 0;
	DECLARE	MateriaExt CHAR(30);
	DECLARE contador INT DEFAULT 0;

	# Localiza todas as disciplinas
	DECLARE materiasCursor CURSOR FOR 
	SELECT ID_MATERIA, MATERIA FROM SPRO_MATERIA_QUESTAO 
	WHERE PUB = 1 AND ID_MATERIA = 22
	ORDER BY MATERIA ASC;

	DECLARE CONTINUE HANDLER FOR NOT FOUND SET finished = 1;

	SET thisMonth = MONTH(NOW());
	SET thisYear = YEAR(NOW());
	SET thisLimit = 3;

	IF ($mes > 0) THEN
		SET thisMonth = $mes;
	END IF;

	IF ($ano > 0) THEN
		SET thisYear = $ano;
	END IF;

	IF ($limit > 0) THEN
		SET thisLimit = $limit;
	END IF;

	# Limpa a tabela de destino
	DELETE FROM SPRO_QUESTAO_MAIS_USADA;

	IF finished != 1 THEN
		OPEN materiasCursor;                                
			getQuestoesMaisUsadas: LOOP

					FETCH materiasCursor INTO idMateria, MateriaExt;
					IF finished = 1 THEN 
						LEAVE getQuestoesMaisUsadas;
					END IF; 

					INSERT INTO SPRO_QUESTAO_MAIS_USADA 
					(ID_BCO_QUESTAO, QTDE, MATERIA, PERIODO, DATA_REGISTRO)
					(	
						SELECT DISTINCT
							ID_QUESTAO,
							count(ID_QUESTAO) AS qtd,
							MateriaExt,
							CONCAT(thisMonth,'/',thisYear) AS Periodo,
							NOW() AS DATA_EXTRACT
						FROM
							SPRO_HIST_USO_QUESTAO
						WHERE
						DATA_REGISTRO >= concat(thisYear,'-',thisMonth,'-01 00:00:00')
						AND DATA_REGISTRO <= concat(thisYear,'-',thisMonth,'-',LAST_DAY(CONCAT(thisYear,'-',thisMonth,'-01')),' 23:59:59')
						AND ID_MATERIA = idMateria
						GROUP BY
							ID_QUESTAO
						ORDER BY
							ID_MATERIA,
							qtd DESC
						LIMIT thisLimit
					);

					SET contador = contador + 1;

			END LOOP getQuestoesMaisUsadas;
		CLOSE materiasCursor;
	END IF;

	# Lista as questões extraídas
	SELECT * FROM SPRO_QUESTAO_MAIS_USADA
	ORDER BY MATERIA ASC, QTDE DESC;

END;

