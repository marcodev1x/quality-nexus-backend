create definer = admin@`%` view VW_PBI_DIM_ITEM as
select `iq`.`ID_ITEM` AS `ID_ITEM`, `iq`.`NOME_ITEM` AS `NOME_ITEM`
from `superpro`.`SPRO_ITEM_QUESTAO` `iq`;

