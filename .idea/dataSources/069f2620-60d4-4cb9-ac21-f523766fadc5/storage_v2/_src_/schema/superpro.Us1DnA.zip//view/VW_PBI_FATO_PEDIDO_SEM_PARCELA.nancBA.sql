create definer = admin@`%` view VW_PBI_FATO_PEDIDO_SEM_PARCELA as
select `sep`.`NUM_PEDIDO`                           AS `NUMERO_PEDIDO`,
       `sep`.`ID_CLIENTE`                           AS `ID_CLIENTE`,
       `sep`.`ID_PLANO`                             AS `ID_PLANO`,
       `spc`.`ID_PLANO_CONSUMO`                     AS `ID_PLANO_CONSUMO`,
       `sep`.`VALOR_TOTAL`                          AS `VALOR_PEDIDO`,
       `sep`.`VALOR_ADM`                            AS `VALOR_ADM`,
       `sep`.`PARCELAS`                             AS `PARCELAS`,
       `sep`.`FORMA_PGTO`                           AS `FORMA_PAGAMENTO`,
       `sep`.`ID_MEIO_PGTO`                         AS `ID_MEIO_PGTO`,
       `sep`.`ID_STATUS_LOJA`                       AS `ID_STATUS_LOJA`,
       `sep`.`DATA_REGISTRO`                        AS `DATA_REGISTRO`,
       date_format(`sep`.`DATA_REGISTRO`, '%Y%m%d') AS `ID_DATA`,
       date_format(`sep`.`DATA_REGISTRO`, '%H%i')   AS `ID_HORA`,
       `sep`.`DATA_VENC_BOLETO`                     AS `VENCIMENTO_BOLETO`,
       `sep`.`DATA_PGTO`                            AS `DATA_PAGAMENTO`
from (((`superpro`.`SPRO_ECOMM_PEDIDO` `sep` join `superpro`.`VW_PBI_DIM_CLIENTE_VALIDO` `vcv`
        on ((`superpro`.`vcv`.`ID_CLIENTE` = `sep`.`ID_CLIENTE`))) left join `superpro`.`SPRO_PRECO_PLANO` `spp`
       on ((`spp`.`ID_PRECO_PLANO` = `sep`.`ID_PLANO`))) left join `superpro`.`SPRO_PLANO_CONSUMO` `spc`
      on ((`spc`.`ID_PLANO_CONSUMO` = `spp`.`ID_PLANO_CONSUMO`)))
where (((`sep`.`ID_MEIO_PGTO` not in (13, 18, 19)) or ((`sep`.`ID_MEIO_PGTO` in (13, 18, 19)) and
                                                       ((not (regexp_like(`sep`.`DESCR_PRODUTO`,
                                                                          'ref .. parcela|ref[.]|ref[=]|ref:|ref parc|ref*parc|parc[.]|parc|paracela|pacela|Parcela'))) or
                                                        regexp_like(`sep`.`DESCR_PRODUTO`, 'parcela 01|parcela 1')))) and
       (cast(`sep`.`DATA_REGISTRO` as date) >= '2018-01-01') and (`sep`.`NUM_PEDIDO_PAI` is null));

