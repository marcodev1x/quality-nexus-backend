create definer = powerbi@`%` view VW_PBI_FATO_PEDIDOS as
select `sep`.`NUM_PEDIDO`                                               AS `NUMERO_PEDIDO`,
       `sep`.`NUM_PEDIDO_PAI`                                           AS `PEDIDO_PAI`,
       `sep`.`ID_CLIENTE`                                               AS `ID_CLIENTE`,
       `sep`.`ID_PLANO`                                                 AS `ID_PLANO`,
       `spc`.`ID_PLANO_CONSUMO`                                         AS `ID_PLANO_CONSUMO`,
       coalesce(concat(`spc`.`CODIGO_PLANO`, ' ', `sep`.`CREDITOS`), 0) AS `PLANO`,
       `sep`.`VALOR_TOTAL`                                              AS `VALOR_PEDIDO`,
       `sep`.`VALOR_ADM`                                                AS `VALOR_ADM`,
       `sep`.`VALOR_PARCELA`                                            AS `VALOR_PARCELA`,
       `sep`.`PARCELAS`                                                 AS `PARCELAS`,
       (case
            when ((`sep`.`NUM_PEDIDO_PAI` is not null) or
                  regexp_like(`sep`.`DESCR_PRODUTO`, 'parc[.]|parc|paracela|pacela|parcela')) then 'Sim'
            else 'Não' end)                                             AS `BOLETO_PEDIDO_PARCELADO`,
       (case
            when regexp_like(`sep`.`DESCR_PRODUTO`, 'parcela 01|parcela 1 de') then 'PARC'
            else `sep`.`FORMA_PGTO` end)                                AS `FORMA_PAGAMENTO`,
       `sep`.`ID_MEIO_PGTO`                                             AS `ID_MEIO_PGTO`,
       `sep`.`CREDITOS`                                                 AS `CREDITOS`,
       `sep`.`VALIDADE_CREDITOS`                                        AS `PRAZO`,
       `sep`.`MESES_ADIC`                                               AS `MESES ADD`,
       `sep`.`ID_STATUS_LOJA`                                           AS `ID_STATUS_LOJA`,
       `sep`.`DATA_REGISTRO`                                            AS `DATA_REGISTRO`,
       cast(`sep`.`DATA_REGISTRO` as date)                              AS `DATA_PEDIDO`,
       date_format(`sep`.`DATA_REGISTRO`, '%Y%m%d')                     AS `ID_DATA`,
       hour(`sep`.`DATA_REGISTRO`)                                      AS `ID_HORA`,
       `sep`.`DATA_ALTERADO`                                            AS `DATA_ALTERADO`,
       `sep`.`DATA_VENC_BOLETO`                                         AS `VENCIMENTO_BOLETO`,
       (case
            when (`sep`.`DATA_VENC_BOLETO` is not null) then (case
                                                                  when (weekday(`sep`.`DATA_VENC_BOLETO`) in (3, 4))
                                                                      then (`sep`.`DATA_VENC_BOLETO` + interval 4 day)
                                                                  when (weekday(`sep`.`DATA_VENC_BOLETO`) = 5)
                                                                      then (`sep`.`DATA_VENC_BOLETO` + interval 3 day)
                                                                  when (weekday(`sep`.`DATA_VENC_BOLETO`) in (6, 0, 1, 2))
                                                                      then (`sep`.`DATA_VENC_BOLETO` + interval 2 day)
                                                                  else NULL end)
            else NULL end)                                              AS `DATA_LIMITE_BOLETO`,
       (case
            when ((`sep`.`ID_MEIO_PGTO` not in (1, 13, 18, 19)) and (`sep`.`ID_STATUS_LOJA` = 1))
                then cast(`sep`.`DATA_REGISTRO` as date)
            else `sep`.`DATA_PGTO` end)                                 AS `DATA_PAGAMENTO`,
       (case
            when (`sep`.`ID_MEIO_PGTO` in (2, 3, 4, 5, 9, 15, 16, 17))
                then (cast(`sep`.`DATA_REGISTRO` as date) + interval `sep`.`PARCELAS` month)
            else NULL end)                                              AS `ULT_PARCELA_CARTAO`,
       `sep`.`CUPOM`                                                    AS `CUPOM`,
       `sep`.`ID_TIPO_LANCAMENTO`                                       AS `ID_TIPO_LANCAMENTO`
from (((`superpro`.`SPRO_ECOMM_PEDIDO` `sep` join `superpro`.`SPRO_VW_CLIENTE_VALIDO` `sc`
        on ((`superpro`.`sc`.`ID_CLIENTE` = `sep`.`ID_CLIENTE`))) left join `superpro`.`SPRO_PRECO_PLANO` `spp`
       on ((`spp`.`ID_PRECO_PLANO` = `sep`.`ID_PLANO`))) left join `superpro`.`SPRO_PLANO_CONSUMO` `spc`
      on ((`spc`.`ID_PLANO_CONSUMO` = `spp`.`ID_PLANO_CONSUMO`)))
where (`sep`.`DATA_REGISTRO` >= '2018-01-01 00:00:00');

-- comment on column VW_PBI_FATO_PEDIDOS.`MESES ADD` not supported: Meses adicionais ao prazo contratado (campanhas)

