create
    definer = admin@`%` function fcCalcUsoQuestao(ID_BCO_QUESTAO_ int) returns int
BEGIN
	# 11/08/2014
	# Localiza o total de vezes que uma questão foi utilizada.
	# @author Claudio Rubens Silva Filho

	DECLARE TOTAL_USO INT;
	DECLARE LIST_ID_INTERBITS CHAR;
	SET TOTAL_USO = 0;
	SET LIST_ID_INTERBITS = '';

	IF(ID_BCO_QUESTAO_ IS NOT NULL) THEN	
		# Localiza os IDs de registros usados pela Interbits (domínío interbits ou supervip). Estes não devem ser contabilizados.
		SELECT GROUP_CONCAT(ID_CLIENTE) INTO LIST_ID_INTERBITS FROM SPRO_CLIENTE WHERE EMAIL LIKE '%interbits%' OR EMAIL LIKE '%supervip%';

		# Localiza o total de registros que fizeram uso da questão atual, excluindo docs gerados por IDs da Interbits.
		SELECT COUNT(*) INTO TOTAL_USO FROM SPRO_HISTORICO_GERADOC WHERE MATCH(ITENS_SELECIONADOS) AGAINST(ID_BCO_QUESTAO_ IN BOOLEAN MODE) 
		AND ID_LOGIN NOT IN (LIST_ID_INTERBITS);
	END IF;

  RETURN TOTAL_USO;
END;

