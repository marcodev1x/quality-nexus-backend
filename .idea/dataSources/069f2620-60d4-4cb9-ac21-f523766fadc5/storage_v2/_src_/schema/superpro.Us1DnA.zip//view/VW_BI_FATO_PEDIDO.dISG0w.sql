create definer = admin@`%` view VW_BI_FATO_PEDIDO as
select `P`.`ID_PEDIDO`                            AS `ID_PEDIDO`,
       `P`.`ID_CLIENTE`                           AS `ID_CLIENTE`,
       `P`.`ID_PLANO`                             AS `ID_PLANO`,
       `PL`.`ID_PLANO_CONSUMO`                    AS `ID_PLANO_CONSUMO`,
       `P`.`ID_MEIO_PGTO`                         AS `ID_MEIO_PGTO`,
       `P`.`ID_STATUS_LOJA`                       AS `ID_STATUS_LOJA`,
       date_format(`P`.`DATA_REGISTRO`, '%Y%m%d') AS `ID_DATA`,
       date_format(`P`.`DATA_REGISTRO`, '%H%i')   AS `ID_HORA`,
       `P`.`DATA_REGISTRO`                        AS `DATA_REGISTRO`,
       `P`.`PARCELAS`                             AS `PARCELAS`,
       `P`.`VALOR_TOTAL`                          AS `VALOR_TOTAL`,
       `P`.`VALOR_PARCELA`                        AS `VALOR_PARCELA`,
       `P`.`CREDITOS_SALDO_ANT`                   AS `CREDITOS_SALDO_ANT`,
       `P`.`CREDITOS`                             AS `CREDITOS`,
       `P`.`CUPOM`                                AS `CUPOM`
from ((`superpro`.`SPRO_ECOMM_PEDIDO` `P` left join `superpro`.`SPRO_PRECO_PLANO` `PL`
       on ((`PL`.`ID_PRECO_PLANO` = `P`.`ID_PLANO`))) left join `superpro`.`SPRO_PLANO_CONSUMO` `PC`
      on ((`PC`.`ID_PLANO_CONSUMO` = `PL`.`ID_PLANO_CONSUMO`)))
where (`P`.`DATA_REGISTRO` >= '2018-01-01');

