create definer = admin@`%` view VW_SPRO_PLANO_REL_CLIENTE as
select `superpro`.`SPRO_PLANO_CONSUMO`.`ID_PLANO_CONSUMO`         AS `ID_PLANO_CONSUMO`,
       `superpro`.`SPRO_PLANO_CONSUMO`.`PLANO_CONSUMO`            AS `PLANO_CONSUMO`,
       `superpro`.`SPRO_PLANO_CONSUMO`.`VALOR_MIN`                AS `VALOR_MIN`,
       `superpro`.`SPRO_PLANO_CONSUMO`.`IMG_CAB`                  AS `IMG_CAB`,
       `superpro`.`SPRO_PLANO_CONSUMO`.`VANTAGENS`                AS `VANTAGENS`,
       `superpro`.`SPRO_PLANO_CONSUMO`.`PRAZO_MESES_VENC`         AS `PRAZO_MESES_VENC`,
       `superpro`.`SPRO_PLANO_REL_CLIENTE`.`ID_PLANO_REL_CLIENTE` AS `ID_PLANO_REL_CLIENTE`,
       `superpro`.`SPRO_PLANO_REL_CLIENTE`.`DATA_REGISTRO`        AS `DATA_REGISTRO`,
       `superpro`.`SPRO_PLANO_REL_CLIENTE`.`ID_CLIENTE`           AS `ID_CLIENTE`,
       `superpro`.`SPRO_CLIENTE`.`NOME_PRINCIPAL`                 AS `NOME_CLIENTE`
from ((`superpro`.`SPRO_PLANO_CONSUMO` join `superpro`.`SPRO_PLANO_REL_CLIENTE`
       on ((`superpro`.`SPRO_PLANO_CONSUMO`.`ID_PLANO_CONSUMO` =
            `superpro`.`SPRO_PLANO_REL_CLIENTE`.`ID_PLANO_CONSUMO`))) join `superpro`.`SPRO_CLIENTE`
      on ((`superpro`.`SPRO_CLIENTE`.`ID_CLIENTE` = `superpro`.`SPRO_PLANO_REL_CLIENTE`.`ID_CLIENTE`)));

