create
    definer = admin@`%` procedure spResgate()
BEGIN
	declare mes_atual int;
	declare ano_atual int;
	declare ano_ini int default 2018;
	declare mes_ini int default 1;
	declare mes_fim int default 3;

	DROP TABLE IF EXISTS `TEMPO_RESGATE`;
	
	CREATE TABLE `TEMPO_RESGATE` (
		`ID_CLIENTE` int(11) NOT NULL,
		`DATA_RESGATE` date NOT NULL,
		`DIAS` int(11) NOT NULL
	) ENGINE=InnoDB DEFAULT CHARSET=latin1;

	SELECT EXTRACT(year from current_date()), EXTRACT(month from current_date()) into ano_atual, mes_atual;

	resgates: loop 
		
		IF (ano_ini = ano_atual and mes_ini >= mes_atual) THEN 
			LEAVE resgates;
		END IF;
		
		call spCalcularTempoResgate(ano_ini, mes_ini, mes_fim);
		
		set mes_ini = mes_ini + 3;
		set mes_fim = mes_fim + 3;
	
		if mes_fim > 12 then 
			set mes_ini = 1;
			set mes_fim = 3;
			set ano_ini = ano_ini + 1;
		end if;
		
	end loop resgates;
	
	
END;

