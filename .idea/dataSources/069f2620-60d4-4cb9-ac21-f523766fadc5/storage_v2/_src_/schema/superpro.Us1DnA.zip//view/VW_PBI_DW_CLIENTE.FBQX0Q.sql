create definer = staging@`%` view VW_PBI_DW_CLIENTE as
select `sc`.`ID_CLIENTE`                                    AS `ID_CLIENTE`,
       `sc`.`NOME_PRINCIPAL`                                AS `NOME`,
       `sc`.`SOBRENOME`                                     AS `SOBRENOME`,
       `sc`.`APELIDO`                                       AS `APELIDO`,
       `sc`.`SEXO`                                          AS `SEXO`,
       `sc`.`EMAIL`                                         AS `EMAIL`,
       concat(`sc`.`DDD_CELULAR`, ' ', `sc`.`FONE_CELULAR`) AS `CELULAR`,
       concat(`sc`.`DDD_RESID`, ' ', `sc`.`FONE_RESID`)     AS `TELEFONE`,
       `sc`.`ANIVERSARIO`                                   AS `NASCIMENTO`,
       `sc`.`PF_PJ`                                         AS `PF_PJ`,
       `sc`.`CPF_CNPJ`                                      AS `CPF_CNPJ`,
       `sc`.`RAZAO_SOCIAL`                                  AS `RAZAO_SOCIAL`,
       `sc`.`ID_MATRIZ`                                     AS `ID_MATRIZ`,
       `sc`.`ID_FILIAL`                                     AS `ID_FILIAL`,
       `sc`.`ID_AUTH_FUNCAO`                                AS `ID_AUTH_FUNCAO`,
       (case
            when (`sc`.`ID_AUTH_PERFIL` in (3, 6, 9, 10, 11, 13)) then `sc`.`ID_AUTH_PERFIL`
            when (((`sc`.`ID_AUTH_PERFIL` = 0) or (`sc`.`ID_AUTH_PERFIL` is null)) and
                  ((`su`.`ID_USER_PERFIL` = 0) or (`su`.`ID_USER_PERFIL` is null))) then `sc`.`ID_AUTH_PERFIL`
            when (((`sc`.`ID_AUTH_PERFIL` = 0) or (`sc`.`ID_AUTH_PERFIL` is null) or (`sc`.`ID_AUTH_PERFIL` = 2)) and
                  (`su`.`ID_USER_PERFIL` in (2, 3, 11))) then 3
            when (((`sc`.`ID_AUTH_PERFIL` = 0) or (`sc`.`ID_AUTH_PERFIL` is null) or (`sc`.`ID_AUTH_PERFIL` = 2)) and
                  (`su`.`ID_USER_PERFIL` = 4)) then 6
            when (((`sc`.`ID_AUTH_PERFIL` = 0) or (`sc`.`ID_AUTH_PERFIL` is null) or (`sc`.`ID_AUTH_PERFIL` = 2)) and
                  (`su`.`ID_USER_PERFIL` = 9)) then 9
            when (((`sc`.`ID_AUTH_PERFIL` = 0) or (`sc`.`ID_AUTH_PERFIL` is null) or (`sc`.`ID_AUTH_PERFIL` = 2)) and
                  (`su`.`ID_USER_PERFIL` = 12)) then 11
            when (((`sc`.`ID_AUTH_PERFIL` = 0) or (`sc`.`ID_AUTH_PERFIL` is null) or (`sc`.`ID_AUTH_PERFIL` = 2)) and
                  (`su`.`ID_USER_PERFIL` = 13)) then 13
            when exists(select 1
                        from `superpro`.`SPRO_HISTORICO_GERADOC` `shg`
                        where ((`shg`.`FORMATO` <> 'SMS') and (`shg`.`ID_LOGIN` = `sc`.`ID_CLIENTE`))) then 3
            when (((`sc`.`ID_AUTH_PERFIL` in (0, 4, 7)) or (`su`.`ID_USER_PERFIL` = 5)) and (not exists(select 1
                                                                                                        from `superpro`.`SPRO_HISTORICO_GERADOC` `shg`
                                                                                                        where ((`shg`.`FORMATO` <> 'SMS') and (`shg`.`ID_LOGIN` = `sc`.`ID_CLIENTE`)))) and
                  (not exists(select 1
                              from `superpro`.`SPRO_CREDITO_CONSOLIDADO` `scc`
                              where (`scc`.`ID_CLIENTE` = `sc`.`ID_CLIENTE`)))) then 4
            when exists(select 1
                        from `superpro`.`SPRO_CREDITO_CONSOLIDADO` `scc`
                        where ((`scc`.`ID_CLIENTE` = `sc`.`ID_CLIENTE`) and (`scc`.`OPERACAO` = 'C') and
                               ((`scc`.`CREDITO` <= 10) or regexp_like(`scc`.`MOTIVO`, 'degusta')))) then 3
            else 2 end)                                     AS `ID_AUTH_PERFIL`,
       `sc`.`COD_POSTAL`                                    AS `CEP`,
       `sc`.`LOGRADOURO`                                    AS `LOGRADOURO`,
       `sc`.`NUMERO`                                        AS `NUMERO`,
       `sc`.`BAIRRO`                                        AS `BAIRRO`,
       `sc`.`CIDADE`                                        AS `CIDADE`,
       `sc`.`UF`                                            AS `UF`,
       `sc`.`PAIS`                                          AS `PAIS`,
       `sc`.`DEL`                                           AS `DELETADO`,
       `sc`.`BLOQ`                                          AS `BLOQUEADO`,
       `sc`.`DATA_REGISTRO`                                 AS `DATA_CADASTRO`,
       `sc`.`DATA_UPD`                                      AS `DATA_ATUALIZADO`,
       `sc`.`PBI_VALIDO`                                    AS `PBI_VALIDO`
from (`superpro`.`SPRO_CLIENTE` `sc` join `superpro`.`SPRO_USER` `su` on ((`sc`.`ID_CLIENTE` = `su`.`ID_USER`)))
where (`sc`.`PBI_VALIDO` = 1);

