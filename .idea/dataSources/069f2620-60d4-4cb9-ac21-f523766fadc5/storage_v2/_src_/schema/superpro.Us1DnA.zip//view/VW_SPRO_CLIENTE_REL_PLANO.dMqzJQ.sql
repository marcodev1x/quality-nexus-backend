create definer = staging@`%` view VW_SPRO_CLIENTE_REL_PLANO as
select `superpro`.`SPRO_CLIENTE`.`EMAIL`                  AS `EMAIL`,
       `superpro`.`SPRO_CLIENTE`.`NOME_PRINCIPAL`         AS `NOME_PRINCIPAL`,
       `superpro`.`SPRO_PLANO_CONSUMO`.`PLANO_CONSUMO`    AS `PLANO_CONSUMO`,
       `superpro`.`SPRO_PLANO_CONSUMO`.`ID_PLANO_CONSUMO` AS `ID_PLANO_CONSUMO`,
       `superpro`.`SPRO_CLIENTE`.`ID_CLIENTE`             AS `ID_CLIENTE`,
       (select sum(`TB1`.`CREDITO`) AS `SUM(CREDITO)`
        from `superpro`.`SPRO_CREDITO_CONSOLIDADO` `TB1`
        where (`TB1`.`ID_CLIENTE` = `superpro`.`SPRO_CLIENTE`.`ID_CLIENTE`)
        group by `TB1`.`ID_CLIENTE`)                      AS `TOTAL_CREDITO_ADQUIRIDO`
from ((`superpro`.`SPRO_CLIENTE` join `superpro`.`SPRO_PLANO_REL_CLIENTE` on ((`superpro`.`SPRO_CLIENTE`.`ID_CLIENTE` =
                                                                               `superpro`.`SPRO_PLANO_REL_CLIENTE`.`ID_CLIENTE`))) join `superpro`.`SPRO_PLANO_CONSUMO`
      on ((`superpro`.`SPRO_PLANO_CONSUMO`.`ID_PLANO_CONSUMO` =
           `superpro`.`SPRO_PLANO_REL_CLIENTE`.`ID_PLANO_CONSUMO`)));

