create definer = admin@`%` trigger TopDownloadBeforeInsert
    before insert
    on SPRO_TOP_DOWNLOAD
    for each row
BEGIN
	SET NEW.UUID_DOWNLOAD= uuid();
END;

