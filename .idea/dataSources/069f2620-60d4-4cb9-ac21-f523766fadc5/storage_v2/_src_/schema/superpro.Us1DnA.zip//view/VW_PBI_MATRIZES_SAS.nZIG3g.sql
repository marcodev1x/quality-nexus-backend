create definer = admin@`%` view VW_PBI_MATRIZES_SAS as
select `sc`.`ID_CLIENTE`     AS `ID_CLIENTE`,
       `sc`.`NOME_PRINCIPAL` AS `NOME_PRINCIPAL`,
       `sc`.`ID_MATRIZ`      AS `ID_MATRIZ`,
       `sc`.`LOGIN`          AS `LOGIN`,
       `sc`.`DEL`            AS `DEL`,
       `sc`.`EMAIL`          AS `EMAIL`,
       `sc`.`SOBRENOME`      AS `SOBRENOME`,
       `sc`.`RAZAO_SOCIAL`   AS `RAZAO_SOCIAL`,
       `sc`.`PF_PJ`          AS `PF_PJ`,
       `sc`.`BLOQ`           AS `BLOQ`,
       `sc`.`ID_AUTH_PERFIL` AS `ID_AUTH_PERFIL`,
       `sc`.`DATA_REGISTRO`  AS `DATA_REGISTRO`
from `superpro`.`SPRO_CLIENTE` `sc`
where (`sc`.`ID_CLIENTE` in (66815, 877547, 890196));

