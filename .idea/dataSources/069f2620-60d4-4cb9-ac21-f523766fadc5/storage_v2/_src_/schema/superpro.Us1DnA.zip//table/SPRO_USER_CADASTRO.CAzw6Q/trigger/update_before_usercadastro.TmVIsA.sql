create definer = admin@`%` trigger update_before_usercadastro
    before update
    on SPRO_USER_CADASTRO
    for each row
BEGIN
	IF (NEW.DATA_CONTRATO_PJ_RECEB = '0000-00-00') THEN
		SET NEW.DATA_CONTRATO_PJ_RECEB = NULL;
	END IF;
END;

