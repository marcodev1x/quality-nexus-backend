create definer = admin@`%` view VW_SPRO_LST_USUARIO as
select `superpro`.`SPRO_LST_USUARIO`.`ID_LST_USUARIO`         AS `ID_LST_USUARIO`,
       `superpro`.`SPRO_LST_USUARIO`.`ID_HISTORICO_GERADOC`   AS `ID_HISTORICO_GERADOC`,
       `superpro`.`SPRO_LST_USUARIO`.`ID_CLIENTE`             AS `ID_CLIENTE`,
       `superpro`.`SPRO_LST_USUARIO`.`ID_LST_TIPO_USER`       AS `ID_LST_TIPO_USER`,
       `superpro`.`SPRO_LST_USUARIO`.`NUM_QUESTOES`           AS `NUM_QUESTOES`,
       `superpro`.`SPRO_LST_USUARIO`.`NUM_QUESTOES_ESTATICAS` AS `NUM_QUESTOES_ESTATICAS`,
       `superpro`.`SPRO_LST_USUARIO`.`NUM_QUESTOES_DINAMICAS` AS `NUM_QUESTOES_DINAMICAS`,
       `superpro`.`SPRO_LST_USUARIO`.`LST_QUESTOES_ESTATICAS` AS `LST_QUESTOES_ESTATICAS`,
       `superpro`.`SPRO_LST_USUARIO`.`LST_QUESTOES_DINAMICAS` AS `LST_QUESTOES_DINAMICAS`,
       `superpro`.`SPRO_LST_USUARIO`.`RESPOSTAS_TEMP`         AS `RESPOSTAS_TEMP`,
       `superpro`.`SPRO_LST_USUARIO`.`DATA_REGISTRO`          AS `DATA_REGISTRO`,
       `superpro`.`SPRO_CLIENTE`.`NOME_PRINCIPAL`             AS `NOME_PRINCIPAL`,
       `superpro`.`SPRO_CLIENTE`.`APELIDO`                    AS `APELIDO`,
       `superpro`.`SPRO_CLIENTE`.`EMAIL`                      AS `EMAIL`,
       `superpro`.`SPRO_CLIENTE`.`SOBRENOME`                  AS `SOBRENOME`,
       `superpro`.`SPRO_HISTORICO_GERADOC`.`COD_LISTA`        AS `COD_LISTA`,
       `superpro`.`SPRO_LST_USUARIO`.`MSG_EMAIL_ENV`          AS `MSG_EMAIL_ENV`,
       `superpro`.`SPRO_LST_USUARIO`.`DT_HR_EMAIL_ENV`        AS `DT_HR_EMAIL_ENV`
from ((`superpro`.`SPRO_LST_USUARIO` join `superpro`.`SPRO_CLIENTE` on ((`superpro`.`SPRO_CLIENTE`.`ID_CLIENTE` =
                                                                         `superpro`.`SPRO_LST_USUARIO`.`ID_CLIENTE`))) join `superpro`.`SPRO_HISTORICO_GERADOC`
      on ((`superpro`.`SPRO_HISTORICO_GERADOC`.`ID_HISTORICO_GERADOC` =
           `superpro`.`SPRO_LST_USUARIO`.`ID_HISTORICO_GERADOC`)));

