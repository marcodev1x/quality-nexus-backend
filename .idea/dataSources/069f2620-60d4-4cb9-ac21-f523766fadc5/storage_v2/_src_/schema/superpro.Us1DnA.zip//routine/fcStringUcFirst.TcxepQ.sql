create
    definer = admin@`%` function fcStringUcFirst(oldWord varchar(255)) returns varchar(255)
BEGIN
	RETURN CONCAT(UCASE(SUBSTRING(oldWord, 1, 1)),SUBSTRING(LOWER(oldWord), 2));
END;

