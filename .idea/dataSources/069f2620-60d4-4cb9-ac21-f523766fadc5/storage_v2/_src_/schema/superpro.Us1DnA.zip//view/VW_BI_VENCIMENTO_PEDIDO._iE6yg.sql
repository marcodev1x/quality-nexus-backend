create definer = admin@`%` view VW_BI_VENCIMENTO_PEDIDO as
select `UP`.`ID_CLIENTE` AS `ID_CLIENTE`, max(`CC`.`VENCIMENTO`) AS `VENCIMENTO`
from ((select `superpro`.`SPRO_ECOMM_PEDIDO`.`ID_CLIENTE`      AS `ID_CLIENTE`,
              max(`superpro`.`SPRO_ECOMM_PEDIDO`.`NUM_PEDIDO`) AS `ULTIMO_NUM_PEDIDO`
       from `superpro`.`SPRO_ECOMM_PEDIDO`
       group by `superpro`.`SPRO_ECOMM_PEDIDO`.`ID_CLIENTE`) `UP` join `superpro`.`SPRO_CREDITO_CONSOLIDADO` `CC`
      on (((`CC`.`ID_CLIENTE` = `UP`.`ID_CLIENTE`) and (`CC`.`NUM_PEDIDO` = `UP`.`ULTIMO_NUM_PEDIDO`))))
group by `UP`.`ID_CLIENTE`
having (max(`CC`.`VENCIMENTO`) between cast('2020-04-01' as date) and cast('2021-09-30' as date));

