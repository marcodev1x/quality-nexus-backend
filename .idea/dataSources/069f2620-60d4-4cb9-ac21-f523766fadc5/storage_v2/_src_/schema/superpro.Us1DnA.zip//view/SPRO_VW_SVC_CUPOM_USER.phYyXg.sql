create definer = admin@`%` view SPRO_VW_SVC_CUPOM_USER as
select `TB1`.`CUPOM`                                                         AS `CUPOM`,
       `TB1`.`NUM_SEQ`                                                       AS `NUM_SEQ`,
       (select `superpro`.`SPRO_USER`.`NOME`
        from `superpro`.`SPRO_USER`
        where (`superpro`.`SPRO_USER`.`ID_USER` = `TB2`.`ID_USER`))          AS `NOME_BENEFICIARIO`,
       `TB2`.`ID_USER_INDICADO`                                              AS `ID_USER_INDICADO`,
       (select `superpro`.`SPRO_USER`.`NOME`
        from `superpro`.`SPRO_USER`
        where (`superpro`.`SPRO_USER`.`ID_USER` = `TB2`.`ID_USER_INDICADO`)) AS `NOME_INDICADO`,
       `TB2`.`ID_SVC_CUPOM_REL_USER`                                         AS `ID_SVC_CUPOM_REL_USER`,
       `TB2`.`ID_SVC_CUPOM`                                                  AS `ID_SVC_CUPOM`,
       `TB2`.`PERCENT_DESC`                                                  AS `PERCENT_DESC`,
       `TB2`.`ID_USER`                                                       AS `ID_USER_BENEFICIARIO`,
       `TB2`.`DATA_INI`                                                      AS `DATA_INI`,
       `TB2`.`DATA_FIM`                                                      AS `DATA_FIM`,
       `TB2`.`NUM_PEDIDO_INI`                                                AS `NUM_PEDIDO_INI`,
       `TB2`.`NUM_PEDIDO_FIM`                                                AS `NUM_PEDIDO_FIM`,
       if((now() < `TB2`.`DATA_INI`), 'AGENDADO',
          if(((now() >= `TB2`.`DATA_INI`) and (now() <= `TB2`.`DATA_FIM`)), 'A_VENCER',
             if((now() = `TB2`.`DATA_FIM`), 'VENCE_HOJE', 'VENCIDO')))       AS `STATUS_VENC`,
       `TB2`.`BENEFICIO_INICIADO_EM`                                         AS `DATA_BENEFICIO_INI`,
       `TB2`.`BENEFICIO_ENCERRADO_EM`                                        AS `DATA_BENEFICIO_FIM`,
       `TB2`.`OBS`                                                           AS `OBS`,
       `TB2`.`DATA_REGISTRO`                                                 AS `DATA_REGISTRO`
from (`superpro`.`SPRO_SVC_CUPOM` `TB1` join `superpro`.`SPRO_SVC_CUPOM_REL_USER` `TB2`)
where (`TB1`.`ID_SVC_CUPOM` = `TB2`.`ID_SVC_CUPOM`);

