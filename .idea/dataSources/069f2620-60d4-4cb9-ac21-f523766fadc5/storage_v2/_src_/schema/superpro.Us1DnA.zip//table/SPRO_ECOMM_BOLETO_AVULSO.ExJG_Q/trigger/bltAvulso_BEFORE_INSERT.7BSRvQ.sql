create definer = admin@`%` trigger bltAvulso_BEFORE_INSERT
    before insert
    on SPRO_ECOMM_BOLETO_AVULSO
    for each row
BEGIN
	SET NEW.UUID_BOLETO = uuid();
END;

