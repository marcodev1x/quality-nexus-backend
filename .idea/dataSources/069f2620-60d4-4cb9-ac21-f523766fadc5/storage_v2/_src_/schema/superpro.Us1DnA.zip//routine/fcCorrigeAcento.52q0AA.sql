create
    definer = admin@`%` function fcCorrigeAcento(tabela char, field char) returns text
BEGIN
	#Routine body goes here...
	SET @charFind = 'Ã©';
	SET @charReplace = 'é';
	SET @memo = CONCAT(DATE(NOW()),' - char: ', @charFind);
	SET @tablename = 'SPRO_CLIENTE';
	SET @colname = 'NOME_PRINCIPAL';

	SET @query_ = CONCAT(
	'UPDATE ', @tablename,' SET ', @colname, 
	' = REPLACE(', @colname,",'", @charFind, "','",@charReplace,"'), MEMO=CONCAT(MEMO, '", 
	@memo, "') WHERE ", @colname, " LIKE '%", @charFind, "%'");
	RETURN '';
END;

