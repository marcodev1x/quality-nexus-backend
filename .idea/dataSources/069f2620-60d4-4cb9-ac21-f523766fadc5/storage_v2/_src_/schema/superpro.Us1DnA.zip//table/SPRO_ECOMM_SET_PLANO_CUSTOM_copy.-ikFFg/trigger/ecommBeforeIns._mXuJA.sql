create definer = admin@`%` trigger ecommBeforeIns
    before insert
    on SPRO_ECOMM_SET_PLANO_CUSTOM_copy
    for each row
BEGIN
	# Verifica o prazo máximo por pedido
	SET @prazoMaximo = NULL;
	SELECT IFNULL(CAST(VALUE AS UNSIGNED), 0) INTO @prazoMaximo FROM SPRO_CFG_SYS WHERE VAR = 'prazo_maximo_pedido';

	# Verifica o vencimento atual do usuário
	SELECT VENCIMENTO INTO @vencimento FROM SPRO_CREDITO_CONSOLIDADO WHERE ID_CLIENTE = NEW.ID_USER
	ORDER BY ID_CREDITO_CONSOLIDADO DESC LIMIT 1;
	
	IF (NEW.PRAZO_EM_MESES > 0 AND @vencimento IS NOT NULL AND LENGTH(@vencimento) > 8 AND @prazoMaximo IS NOT NULL AND @prazoMaximo > 0) THEN
		# Verifica qual o limite de vencimento
		SELECT DATE_ADD(@vencimento, INTERVAL @prazoMaximo  MONTH) INTO @limiteVenc;

	 	# Calcula o vencimento a partir do prazo que o cliente definiu
		SELECT DATE_ADD(@vencimento, INTERVAL NEW.PRAZO_EM_MESES MONTH) INTO @novoVenc;

		# Verifica se o novo vencimento é maior do que o permitido
		SELECT DATEDIFF(@limiteVenc,@novoVenc) INTO @diffDias;

		IF (@diffDias < 0) THEN
			# Não permite criar o pedido
			SIGNAL SQLSTATE '02000' SET MESSAGE_TEXT = 'Warning: o prazo excede o limite permitido de vencimento';
		END IF;
	END IF;
END;

