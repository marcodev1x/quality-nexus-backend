create
    definer = admin@`%` function SaldoClienteVencido(id_cliente int) returns int
BEGIN
	declare ult_saldo, consumo, perfil, A_DEBITAR, A_CREDITAR, NUM_DEPENDENTES int;
	declare ult_aquisicao datetime;
	set ult_saldo =0;
	set consumo =0;
	set A_CREDITAR =0;
	set A_DEBITAR =0;

	SELECT sc.ID_AUTH_PERFIL into perfil from SPRO_CLIENTE sc where sc.ID_CLIENTE = id_cliente;

	SELECT IFNULL(COUNT(*),0) INTO NUM_DEPENDENTES FROM SPRO_CLIENTE WHERE ID_MATRIZ = id_cliente;

	SELECT IFNULL(scc.SALDO_FINAL,0), scc.DATA_REGISTRO into ult_saldo, ult_aquisicao 
	from SPRO_CREDITO_CONSOLIDADO scc  
	where scc.ID_CLIENTE = id_cliente 
	order by scc.DATA_REGISTRO  desc limit 1;

	if(not ult_aquisicao is null) then
		if(perfil = 6 or NUM_DEPENDENTES > 0)
		then 
		
			SELECT IFNULL(SUM(CREDITO),0) INTO A_DEBITAR FROM SPRO_CREDITO_CONSOLIDADO 
			WHERE ID_MATRIZ = id_cliente AND DATA_REGISTRO >= ult_aquisicao AND OPERACAO = 'C';

			SELECT IFNULL(SUM(CREDITO),0) INTO A_CREDITAR 
			FROM SPRO_CREDITO_CONSOLIDADO 
			WHERE ID_MATRIZ = id_cliente AND DATA_REGISTRO >= ult_aquisicao AND OPERACAO = 'D';
			
			/*SELECT sum(scc.DEBITO) into consumo 
			from SPRO_CONSUMO_CREDITO scc 
			join SPRO_CLIENTE sc 
			on scc.ID_CLIENTE = sc.ID_CLIENTE 
			where sc.ID_MATRIZ = id_cliente 
			and scc.DATA_REGISTRO >= ult_aquisicao;*/
			
			
			/*(SELECT min(scr.DATA_REGISTRO) 
									from SPRO_CREDITO_CONSOLIDADO scr 
									where scr.ID_CLIENTE  = sc.ID_CLIENTE  
									and scr.DATA_REGISTRO >= ult_aquisicao 
									and scr.OPERACAO = 'C');*/
		
			set ult_saldo = ult_saldo + A_CREDITAR;
			set consumo = A_DEBITAR;
		
		else 
			SELECT sum(scc.DEBITO) into consumo 
			from SPRO_CONSUMO_CREDITO scc 
			where scc.ID_CLIENTE = id_cliente and scc.DATA_REGISTRO >= ult_aquisicao;
		
			if (consumo is null) then return 0; end if;
		end if;
	
		if(consumo > ult_saldo) then 
			return 0; 
		else
			return ult_saldo - consumo;
		end if;
	
	else
		return 0;
	end if;

	
END;

