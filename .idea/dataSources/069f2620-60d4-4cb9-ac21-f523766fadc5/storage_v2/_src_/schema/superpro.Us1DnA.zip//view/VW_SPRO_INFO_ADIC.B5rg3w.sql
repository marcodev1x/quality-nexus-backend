create definer = admin@`%` view VW_SPRO_INFO_ADIC as
select `superpro`.`SPRO_REGIAO`.`REGIAO`                        AS `REGIAO`,
       `superpro`.`SPRO_UF`.`ID_UF`                             AS `ID_UF`,
       `superpro`.`SPRO_UF`.`SIGLA`                             AS `UF`,
       `superpro`.`SPRO_FONTE_VESTIBULAR`.`ID_FONTE_VESTIBULAR` AS `ID_FONTE_VESTIBULAR`,
       `superpro`.`SPRO_REGIAO`.`ID_REGIAO`                     AS `ID_REGIAO`,
       `superpro`.`SPRO_BCO_QUESTAO`.`ID_BCO_QUESTAO`           AS `ID_BCO_QUESTAO`,
       `superpro`.`SPRO_BCO_QUESTAO`.`ID_TEXTO`                 AS `ID_TEXTO`,
       `superpro`.`SPRO_BCO_QUESTAO`.`ID_GRAU_DIFICULDADE`      AS `ID_GRAU_DIFICULDADE`,
       `superpro`.`SPRO_BCO_QUESTAO`.`ANO`                      AS `ANO`,
       `superpro`.`SPRO_BCO_QUESTAO`.`ID_TIPO_QUESTAO`          AS `ID_TIPO_QUESTAO`,
       `superpro`.`SPRO_BCO_QUESTAO`.`FIGR`                     AS `FIGR`,
       `superpro`.`SPRO_BCO_QUESTAO`.`FIG`                      AS `FIG`,
       `superpro`.`SPRO_BCO_QUESTAO`.`RESOLUCAO`                AS `RESOLUCAO`,
       `superpro`.`SPRO_BCO_QUESTAO`.`ENUNCIADO`                AS `ENUNCIADO`,
       `superpro`.`SPRO_FONTE_VESTIBULAR`.`FONTE_VESTIBULAR`    AS `FONTE_VESTIBULAR`,
       `superpro`.`SPRO_GRAU_DIFICULDADE`.`GRAU_DIFICULDADE`    AS `GRAU_DIFICULDADE`,
       `superpro`.`SPRO_TIPO_QUESTAO`.`TIPO_QUESTAO`            AS `TIPO_QUESTAO`
from (((((`superpro`.`SPRO_BCO_QUESTAO` join `superpro`.`SPRO_FONTE_VESTIBULAR`
          on ((`superpro`.`SPRO_FONTE_VESTIBULAR`.`ID_FONTE_VESTIBULAR` =
               `superpro`.`SPRO_BCO_QUESTAO`.`ID_FONTE_VESTIBULAR`))) join `superpro`.`SPRO_UF`
         on ((`superpro`.`SPRO_UF`.`ID_UF` = `superpro`.`SPRO_FONTE_VESTIBULAR`.`ID_UF`))) join `superpro`.`SPRO_REGIAO`
        on ((`superpro`.`SPRO_REGIAO`.`ID_REGIAO` =
             `superpro`.`SPRO_UF`.`ID_REGIAO`))) left join `superpro`.`SPRO_GRAU_DIFICULDADE`
       on ((`superpro`.`SPRO_GRAU_DIFICULDADE`.`ID_GRAU_DIFICULDADE` =
            `superpro`.`SPRO_BCO_QUESTAO`.`ID_GRAU_DIFICULDADE`))) left join `superpro`.`SPRO_TIPO_QUESTAO`
      on ((`superpro`.`SPRO_TIPO_QUESTAO`.`ID_TIPO_QUESTAO` = `superpro`.`SPRO_BCO_QUESTAO`.`ID_TIPO_QUESTAO`)));

