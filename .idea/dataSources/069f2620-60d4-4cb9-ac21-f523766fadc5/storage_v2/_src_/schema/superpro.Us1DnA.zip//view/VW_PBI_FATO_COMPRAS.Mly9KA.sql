create definer = staging@`%` view VW_PBI_FATO_COMPRAS as
select `sep`.`ID_CLIENTE`                       AS `ID_CLIENTE`,
       `sep`.`NUM_PEDIDO`                       AS `NUMERO_PEDIDO`,
       min(cast(`sep`.`DATA_REGISTRO` as date)) AS `PRIMEIRA COMPRA`
from (`superpro`.`SPRO_ECOMM_PEDIDO` `sep` join `superpro`.`SPRO_VW_CLIENTE_VALIDO` `sc`
      on ((`superpro`.`sc`.`ID_CLIENTE` = `sep`.`ID_CLIENTE`)))
where ((`sep`.`ID_STATUS_LOJA` = 1) and (`sep`.`NUM_PEDIDO_PAI` is null))
group by `sep`.`ID_CLIENTE`;

