create
    definer = admin@`%` function fcArredondarAnos(anos decimal) returns int
BEGIN
	if anos - TRUNCATE(anos,0) >= 0.5 
		then return ceil(anos);
	else 
		return floor(anos);
	end if;
END;

