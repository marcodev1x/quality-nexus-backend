create definer = staging@`%` view VW_PBI_FATO_CONTRATO as
select `superpro`.`SC`.`ID_CLIENTE`         AS `ID_CLIENTE`,
       `superpro`.`SVPP`.`ID_PLANO_CONSUMO` AS `ID_PLANO_CONSUMO`,
       `SEP`.`NUM_PEDIDO`                   AS `NUM_PEDIDO`,
       `SEP`.`FORMA_PGTO`                   AS `FORMA_PGTO`,
       `SEP`.`ID_MEIO_PGTO`                 AS `ID_MEIO_PGTO`,
       `SEP`.`PARCELAS`                     AS `PARCELAS`,
       `SEP`.`VALOR_TOTAL`                  AS `VALOR_TOTAL`,
       `SEP`.`CREDITOS`                     AS `CREDITOS`,
       `SEP`.`VALIDADE_CREDITOS`            AS `VALIDADE_CREDITOS`,
       `SEP`.`MESES_ADIC`                   AS `MESES_ADIC`,
       `SEP`.`DATA_REGISTRO`                AS `DATA_PEDIDO`,
       `SCC`.`SALDO_FINAL`                  AS `SALDO_FINAL`,
       `SCC`.`VENCIMENTO`                   AS `VENCIMENTO`,
       cast(`SCC`.`DATA_REGISTRO` as date)  AS `DATA_RECEB_CREDITO`
from (((`superpro`.`SPRO_CREDITO_CONSOLIDADO` `SCC` join `superpro`.`SPRO_VW_CLIENTE_VALIDO` `SC`
        on ((`superpro`.`SC`.`ID_CLIENTE` = `SCC`.`ID_CLIENTE`))) join `superpro`.`SPRO_ECOMM_PEDIDO` `SEP`
       on (((`SEP`.`NUM_PEDIDO` = `SCC`.`NUM_PEDIDO`) and
            (`SEP`.`ID_STATUS_LOJA` = 1)))) left join `superpro`.`SPRO_VW_PRECO_PLANO` `SVPP`
      on ((`superpro`.`SVPP`.`ID_PRECO_PLANO` = `SEP`.`ID_PLANO`)))
where ((`SEP`.`NUM_PEDIDO_PAI` is null) and (`SCC`.`OPERACAO` = 'C'))
order by `superpro`.`SC`.`ID_CLIENTE`, `SEP`.`NUM_PEDIDO`;

-- comment on column VW_PBI_FATO_CONTRATO.MESES_ADIC not supported: Meses adicionais ao prazo contratado (campanhas)

