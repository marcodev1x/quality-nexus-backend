create definer = staging@`%` view SPRO_VW_PEDIDO_DATALORE as
select `sep`.`NUM_PEDIDO`                  AS `Numero pedido`,
       `sep`.`NUM_PEDIDO_PAI`              AS `Pedido pai`,
       `sesl`.`DESCRICAO`                  AS `Status`,
       `sep`.`DESCR_PRODUTO`               AS `Descrição`,
       `sep`.`CREDITOS`                    AS `CREDITOS`,
       `sep`.`VALOR_TOTAL`                 AS `Valor`,
       cast(`sep`.`DATA_REGISTRO` as date) AS `Data registro`,
       `sep`.`DATA_VENC_BOLETO`            AS `Vencimento boleto`,
       `sep`.`DATA_PGTO`                   AS `Data pagamento`,
       `sep`.`FORMA_PGTO`                  AS `Forma pagamento`,
       `semp`.`MEIO_PGTO`                  AS `Meio pagamento`,
       `sep`.`ID_CLIENTE`                  AS `ID cliente`,
       `sep`.`NOME_CLIENTE`                AS `Nome cliente`,
       `sep`.`EMAIL_CLIENTE`               AS `E-mail`,
       `sap`.`PERFIL`                      AS `Perfil`,
       `sc`.`ID_MATRIZ`                    AS `Matriz`
from ((((`superpro`.`SPRO_ECOMM_PEDIDO` `sep` join `superpro`.`SPRO_CLIENTE` `sc`
         on ((`sc`.`ID_CLIENTE` = `sep`.`ID_CLIENTE`))) left join `superpro`.`SPRO_ECOMM_STATUS_LOJA` `sesl`
        on ((`sesl`.`ID_STATUS_LOJA` = `sep`.`ID_STATUS_LOJA`))) left join `superpro`.`SPRO_ECOMM_MEIO_PGTO` `semp`
       on ((`semp`.`ID_MEIO_PGTO` = `sep`.`ID_MEIO_PGTO`))) join `superpro`.`SPRO_AUTH_PERFIL` `sap`
      on ((`sap`.`ID_AUTH_PERFIL` = `sc`.`ID_AUTH_PERFIL`)))
where ((`sc`.`DEL` <> '1') and (`sc`.`BLOQ` = 0));

