create definer = admin@`%` view VW_SPRO_CLASSIFICACAO_QUESTAO_ED as
select `superpro`.`SPRO_CLASSIFICACAO_QUESTAO_ED`.`ID_CLASSIFICACAO`   AS `ID_CLASSIFICACAO`,
       `superpro`.`SPRO_CLASSIFICACAO_QUESTAO_ED`.`ID_BCO_QUESTAO`     AS `ID_BCO_QUESTAO`,
       `superpro`.`SPRO_CLASSIFICACAO_QUESTAO_ED`.`ID_MATERIA`         AS `ID_MATERIA`,
       `superpro`.`SPRO_CLASSIFICACAO_QUESTAO_ED`.`ID_TOPICO`          AS `ID_TOPICO`,
       `superpro`.`SPRO_CLASSIFICACAO_QUESTAO_ED`.`ID_ITEM`            AS `ID_ITEM`,
       `superpro`.`SPRO_CLASSIFICACAO_QUESTAO_ED`.`ID_SUBITEM`         AS `ID_SUBITEM`,
       `superpro`.`SPRO_CLASSIFICACAO_QUESTAO_ED`.`DATA_REGISTRO`      AS `DATA_REGISTRO`,
       `superpro`.`SPRO_MATERIA_QUESTAO`.`MATERIA`                     AS `MATERIA`,
       `superpro`.`SPRO_MATERIA_QUESTAO`.`FOLDER`                      AS `FOLDER`,
       `superpro`.`SPRO_DIVISAO_QUESTAO`.`DIVISAO`                     AS `DIVISAO`,
       `superpro`.`SPRO_TOPICO_QUESTAO`.`TOPICO`                       AS `TOPICO`,
       `superpro`.`SPRO_ITEM_QUESTAO`.`NOME_ITEM`                      AS `NOME_ITEM`,
       `superpro`.`SPRO_SUBITEM_QUESTAO`.`SUBITEM`                     AS `SUBITEM`,
       concat(`superpro`.`SPRO_CLASSIFICACAO_QUESTAO_ED`.`ID_MATERIA`, '_',
              `superpro`.`SPRO_CLASSIFICACAO_QUESTAO_ED`.`ID_DIVISAO`, '_',
              `superpro`.`SPRO_CLASSIFICACAO_QUESTAO_ED`.`ID_TOPICO`, '_',
              `superpro`.`SPRO_CLASSIFICACAO_QUESTAO_ED`.`ID_ITEM`, '_',
              `superpro`.`SPRO_CLASSIFICACAO_QUESTAO_ED`.`ID_SUBITEM`) AS `CODIGO`,
       `superpro`.`SPRO_CLASSIFICACAO_QUESTAO_ED`.`ID_DIVISAO`         AS `ID_DIVISAO`,
       `superpro`.`SPRO_BCO_QUESTAO_ED`.`DATA_PUB`                     AS `DATA_PUB`,
       `superpro`.`SPRO_BCO_QUESTAO_ED`.`ID_TEXTO`                     AS `ID_TEXTO`,
       `superpro`.`SPRO_BCO_QUESTAO_ED`.`ID_AUTH_USUARIO`              AS `ID_AUTH_USUARIO`,
       `superpro`.`SPRO_BCO_QUESTAO_ED`.`REVISADO_EM`                  AS `REVISADO_EM`,
       `superpro`.`SPRO_BCO_QUESTAO_ED`.`PROCESSADO_EM`                AS `PROCESSADO_EM`,
       `superpro`.`SPRO_BCO_QUESTAO_ED`.`ERRO_IMG`                     AS `ERRO_IMG`,
       `superpro`.`SPRO_BCO_QUESTAO_ED`.`ID_FONTE_VESTIBULAR`          AS `ID_FONTE_VESTIBULAR`,
       `superpro`.`SPRO_BCO_QUESTAO_ED`.`ANO`                          AS `ANO`,
       `superpro`.`SPRO_CLASSIFICACAO_QUESTAO_ED`.`DATA_HR_REF`        AS `DATA_HR_REF`
from ((((((`superpro`.`SPRO_CLASSIFICACAO_QUESTAO_ED` left join `superpro`.`SPRO_MATERIA_QUESTAO`
           on ((`superpro`.`SPRO_MATERIA_QUESTAO`.`ID_MATERIA` =
                `superpro`.`SPRO_CLASSIFICACAO_QUESTAO_ED`.`ID_MATERIA`))) left join `superpro`.`SPRO_DIVISAO_QUESTAO`
          on ((`superpro`.`SPRO_DIVISAO_QUESTAO`.`ID_DIVISAO` =
               `superpro`.`SPRO_CLASSIFICACAO_QUESTAO_ED`.`ID_DIVISAO`))) left join `superpro`.`SPRO_TOPICO_QUESTAO`
         on ((`superpro`.`SPRO_TOPICO_QUESTAO`.`ID_TOPICO` =
              `superpro`.`SPRO_CLASSIFICACAO_QUESTAO_ED`.`ID_TOPICO`))) left join `superpro`.`SPRO_ITEM_QUESTAO`
        on ((`superpro`.`SPRO_ITEM_QUESTAO`.`ID_ITEM` =
             `superpro`.`SPRO_CLASSIFICACAO_QUESTAO_ED`.`ID_ITEM`))) left join `superpro`.`SPRO_SUBITEM_QUESTAO`
       on ((`superpro`.`SPRO_SUBITEM_QUESTAO`.`ID_SUBITEM` =
            `superpro`.`SPRO_CLASSIFICACAO_QUESTAO_ED`.`ID_SUBITEM`))) join `superpro`.`SPRO_BCO_QUESTAO_ED`
      on ((`superpro`.`SPRO_BCO_QUESTAO_ED`.`ID_BCO_QUESTAO` =
           `superpro`.`SPRO_CLASSIFICACAO_QUESTAO_ED`.`ID_BCO_QUESTAO`)));

