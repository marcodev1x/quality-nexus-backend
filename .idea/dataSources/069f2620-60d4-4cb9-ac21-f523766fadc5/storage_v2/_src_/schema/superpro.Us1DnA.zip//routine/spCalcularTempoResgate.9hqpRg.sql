create
    definer = admin@`%` procedure spCalcularTempoResgate(IN ano int, IN mes_ini int, IN mes_fim int)
BEGIN
	
declare finished int default 0;	
declare id_cliente, dias int;
declare data_resgate date;
	
declare c cursor for
select 
tempresgate.cliente,
tempresgate.momento,
tempresgate.dias
from
(	SELECT sc.ID_CLIENTE as cliente, date(min(sep.DATA_REGISTRO)) as momento, 
	fcTempoMedioResgateTrim(sc.ID_CLIENTE, ano, mes_ini,mes_fim, min(sep.DATA_REGISTRO)) as dias
	from SPRO_VW_CLIENTE_VALIDO sc
   	join SPRO_ECOMM_PEDIDO sep
    	on sep.ID_CLIENTE  = sc.ID_CLIENTE 
	where 
	date(sep.DATA_REGISTRO) >= CONCAT(ano,'-',mes_ini,'-01')
	and date(sep.DATA_REGISTRO) <= CONCAT(ano,'-',mes_fim,'-31')
	and sep.ID_STATUS_LOJA = 1
	and EXISTS 
	(
		SELECT 1 
		from SPRO_CREDITO_CONSOLIDADO scc 
		where scc.VENCIMENTO < sep.DATA_REGISTRO 
		and scc.ID_CLIENTE = sep.ID_CLIENTE 
		and scc.OPERACAO = 'C'
		and date(scc.DATA_REGISTRO) >= CONCAT(ano,'-',mes_ini,'-01')
		and date(scc.DATA_REGISTRO) <= CONCAT(ano,'-',mes_fim,'-31')	
	)
	group by sc.ID_CLIENTE
) as tempresgate
where tempresgate.dias > 0;

DECLARE CONTINUE HANDLER FOR NOT FOUND SET finished = 1;

if finished = 0 then 
	/*DROP TABLE IF EXISTS `TEMPO_RESGATE`;
	
	CREATE TABLE `TEMPO_RESGATE` (
		`ID_CLIENTE` int(11) NOT NULL,
		`DATA_RESGATE` date NOT NULL,
		`DIAS` int(11) NOT NULL
	) ENGINE=InnoDB DEFAULT CHARSET=latin1;*/

	open c;

	resgates: loop 
		
		fetch c into id_cliente, data_resgate, dias;
	
		IF finished = 1 THEN 
			LEAVE resgates;
		END IF;	
		
		insert IGNORE into TEMPO_RESGATE (ID_CLIENTE, DATA_RESGATE, DIAS) 
		values (id_cliente, data_resgate, dias);
	
	end loop resgates;
	
	close c;

end if;


END;

