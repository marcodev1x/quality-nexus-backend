create definer = admin@`%` trigger before_UPDATE_copy
    before update
    on SPRO_PRECO_PLANO_backup_13_01_2020
    for each row
BEGIN
	INSERT INTO SPRO_PRECO_PLANO_UPD (SELECT *, NOW() AS UPDATED_AT FROM SPRO_PRECO_PLANO WHERE ID_PRECO_PLANO = OLD.ID_PRECO_PLANO);
END;

