create definer = admin@`%` view VW_SPRO_TEXTO_ED as
select `TB2`.`ID_TEXTO`                                                                                     AS `ID_TEXTO`,
       `TB2`.`DATA_REGISTRO`                                                                                AS `DATA_REGISTRO`,
       `TB2`.`ID_AUTH_USUARIO`                                                                              AS `ID_AUTH_USUARIO`,
       `TB2`.`TITULO`                                                                                       AS `TITULO`,
       `TB2`.`TEXTO`                                                                                        AS `TEXTO`,
       `TB2`.`TEXTO_BUSCA`                                                                                  AS `TEXTO_BUSCA`,
       `TB2`.`ID_FONTE_VESTIBULAR`                                                                          AS `ID_FONTE_VESTIBULAR`,
       `TB2`.`ANO`                                                                                          AS `ANO`,
       `TB2`.`SEMESTRE`                                                                                     AS `SEMESTRE`,
       `TB2`.`FASE`                                                                                         AS `FASE`,
       `TB2`.`CADERNO`                                                                                      AS `CADERNO`,
       `TB2`.`ID_AUTOR_TEXTO`                                                                               AS `ID_AUTOR_TEXTO`,
       `TB2`.`ID_ESTILO_TEXTO`                                                                              AS `ID_ESTILO_TEXTO`,
       `TB2`.`BLOQ_EDIT`                                                                                    AS `BLOQ_EDIT`,
       `TB2`.`DT_HR_BLOQ_EDIT`                                                                              AS `DT_HR_BLOQ_EDIT`,
       `TB2`.`ERRO_IMG`                                                                                     AS `ERRO_IMG`,
       (select count(0)
        from `superpro`.`SPRO_BCO_QUESTAO` `TB`
        where (`TB`.`ID_TEXTO` = `TB2`.`ID_TEXTO`))                                                         AS `QUESTOES`,
       date_format(`TB2`.`DATA_REGISTRO`, '%d/%m/%Y %H:%i:%s')                                              AS `DATA_REGISTRO_BR`,
       date_format(`TB2`.`DATA_PUB`, '%d/%m/%Y %H:%i:%s')                                                   AS `DATA_PUB_BR`
from `superpro`.`SPRO_TEXTO_ED` `TB2`;

