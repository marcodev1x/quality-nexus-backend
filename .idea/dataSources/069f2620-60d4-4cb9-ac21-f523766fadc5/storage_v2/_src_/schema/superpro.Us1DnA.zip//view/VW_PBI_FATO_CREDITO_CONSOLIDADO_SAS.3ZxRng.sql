create definer = admin@`%` view VW_PBI_FATO_CREDITO_CONSOLIDADO_SAS as
select `scc`.`ID_CREDITO_CONSOLIDADO`      AS `ID_CREDITO_CONSOLIDADO`,
       `scc`.`OPERACAO`                    AS `OPERACAO`,
       `scc`.`ID_CLIENTE`                  AS `ID_CLIENTE`,
       `scc`.`SALDO_ANT`                   AS `SALDO ANTERIOR`,
       `scc`.`CREDITO`                     AS `CREDITO`,
       `scc`.`SALDO_FINAL`                 AS `SALDO_FINAL`,
       `scc`.`NUM_PEDIDO`                  AS `NUMERO_PEDIDO`,
       `scc`.`VENCIMENTO`                  AS `VENCIMENTO`,
       cast(`scc`.`DATA_REGISTRO` as date) AS `DATA_REGISTRO`,
       `scc`.`HISTORICO_APARTIR_DE`        AS `PRIMEIRO REGISTRO`
from (`superpro`.`SPRO_CREDITO_CONSOLIDADO` `scc` join `superpro`.`VW_PBI_CLIENTES_SAS` `sc`
      on ((`superpro`.`sc`.`ID_CLIENTE` = `scc`.`ID_CLIENTE`)))
where (`scc`.`DATA_REGISTRO` >= '2018-01-01 00:00:00');

