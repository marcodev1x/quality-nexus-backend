create definer = staging@`%` view VW_SPRO_INDICA_AMIGO as
select `superpro`.`SPRO_INDICA_AMIGO`.`ID_INDICA_AMIGO`    AS `ID_INDICA_AMIGO`,
       `superpro`.`SPRO_INDICA_AMIGO`.`ID_REMETENTE`       AS `ID_REMETENTE`,
       `superpro`.`SPRO_INDICA_AMIGO`.`VALIDADE_INDICACAO` AS `VALIDADE_INDICACAO`,
       `superpro`.`SPRO_INDICA_AMIGO`.`NOME`               AS `NOME`,
       `superpro`.`SPRO_INDICA_AMIGO`.`EMAIL`              AS `EMAIL`,
       `superpro`.`SPRO_INDICA_AMIGO`.`MSG`                AS `MSG`,
       `superpro`.`SPRO_INDICA_AMIGO`.`BONUS_REMETENTE`    AS `BONUS_REMETENTE`,
       `superpro`.`SPRO_INDICA_AMIGO`.`BONUS_DESTINATARIO` AS `BONUS_DESTINATARIO`,
       `superpro`.`SPRO_INDICA_AMIGO`.`DATA_REGISTRO`      AS `DATA_REGISTRO`,
       `superpro`.`SPRO_CLIENTE`.`NOME_PRINCIPAL`          AS `REMETENTE`,
       `superpro`.`SPRO_CLIENTE`.`APELIDO`                 AS `APELIDO`,
       `superpro`.`SPRO_CLIENTE`.`EMAIL`                   AS `EMAIL_REMETENTE`,
       ifnull((select count(0) AS `COUNT(*)`
               from `superpro`.`SPRO_ECOMM_PEDIDO` `TB3`
               where ((ifnull(`TB3`.`ID_MATRIZ`, 0) = 0) and (ifnull(`TB3`.`ID_FILIAL`, 0) = 0) and
                      (`TB3`.`EMAIL_CLIENTE` = `superpro`.`SPRO_INDICA_AMIGO`.`EMAIL`) and (`TB3`.`NUM_PEDIDO` > 0) and
                      (`TB3`.`ID_STATUS_LOJA` = 1))), 0)   AS `COMPRA_DEST`,
       `superpro`.`SPRO_CLIENTE`.`RAZAO_SOCIAL`            AS `RAZAO_SOCIAL`,
       `superpro`.`SPRO_CLIENTE`.`SOBRENOME`               AS `SOBRENOME`,
       `superpro`.`SPRO_CLIENTE`.`SEXO`                    AS `SEXO`
from (`superpro`.`SPRO_INDICA_AMIGO` join `superpro`.`SPRO_CLIENTE`
      on ((`superpro`.`SPRO_CLIENTE`.`ID_CLIENTE` = `superpro`.`SPRO_INDICA_AMIGO`.`ID_REMETENTE`)));

