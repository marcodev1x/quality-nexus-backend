create definer = admin@`%` view VW_SPRO_CLIENTE_BLOQ as
select `TMP`.`ID_CLIENTE`     AS `ID_CLIENTE`,
       `TMP`.`EMAIL`          AS `EMAIL`,
       `TMP`.`BLOQ`           AS `BLOQ`,
       `TMP`.`MEIO_PGTO`      AS `MEIO_PGTO`,
       `TMP`.`NUM_PEDIDO`     AS `NUM_PEDIDO`,
       `TMP`.`DATA_COMPRA`    AS `DATA_COMPRA`,
       `TMP`.`ID_STATUS_LOJA` AS `ID_STATUS_LOJA`
from (select `TB2`.`ID_CLIENTE` AS `ID_CLIENTE`,
             `TB2`.`EMAIL`      AS `EMAIL`,
             `TB2`.`BLOQ`       AS `BLOQ`,
             (select `superpro`.`TB1`.`MEIO_PGTO`
              from `superpro`.`VW_SPRO_ECOMM_PEDIDO` `TB1`
              where (`superpro`.`TB1`.`ID_CLIENTE` = `TB2`.`ID_CLIENTE`)
              order by `superpro`.`TB1`.`DATA_REGISTRO` desc
              limit 1)          AS `MEIO_PGTO`,
             (select `superpro`.`TB1`.`ID_STATUS_LOJA`
              from `superpro`.`VW_SPRO_ECOMM_PEDIDO` `TB1`
              where (`superpro`.`TB1`.`ID_CLIENTE` = `TB2`.`ID_CLIENTE`)
              order by `superpro`.`TB1`.`DATA_REGISTRO` desc
              limit 1)          AS `ID_STATUS_LOJA`,
             (select `superpro`.`TB1`.`NUM_PEDIDO`
              from `superpro`.`VW_SPRO_ECOMM_PEDIDO` `TB1`
              where (`superpro`.`TB1`.`ID_CLIENTE` = `TB2`.`ID_CLIENTE`)
              order by `superpro`.`TB1`.`DATA_REGISTRO` desc
              limit 1)          AS `NUM_PEDIDO`,
             (select `superpro`.`TB1`.`DATA_REGISTRO`
              from `superpro`.`VW_SPRO_ECOMM_PEDIDO` `TB1`
              where (`superpro`.`TB1`.`ID_CLIENTE` = `TB2`.`ID_CLIENTE`)
              order by `superpro`.`TB1`.`DATA_REGISTRO` desc
              limit 1)          AS `DATA_COMPRA`
      from `superpro`.`SPRO_CLIENTE` `TB2`
      where (`TB2`.`BLOQ` = 2)) `TMP`
where ((`TMP`.`MEIO_PGTO` <> 'BOLETO') and (`TMP`.`MEIO_PGTO` <> 'BLT_AVULSO_ITAU') and
       (`TMP`.`MEIO_PGTO` <> 'DEP_ITAU') and (`TMP`.`ID_STATUS_LOJA` = 1));

