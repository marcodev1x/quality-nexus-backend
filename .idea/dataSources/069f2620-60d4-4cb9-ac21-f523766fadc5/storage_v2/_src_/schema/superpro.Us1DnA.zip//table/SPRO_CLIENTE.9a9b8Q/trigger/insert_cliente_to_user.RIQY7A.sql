create definer = admin@`%` trigger insert_cliente_to_user
    after insert
    on SPRO_CLIENTE
    for each row
BEGIN
	SELECT COUNT(1) INTO @QTD FROM SPRO_USER_TRIGGER WHERE ID = NEW.ID_CLIENTE;

	IF(@QTD > 0) THEN
		DELETE FROM SPRO_USER_TRIGGER WHERE ID = NEW.ID_CLIENTE;
	ELSE
		INSERT INTO 
			SPRO_USER_TRIGGER
			(
				ORIGEM,
				TIPO,
				DESTINO,
				ID,
				DATA_REGISTRO
			)
		VALUES
			(
				'CLIENTE',
				'INSERT',
				'USER',
				NEW.ID_CLIENTE,
				NOW()
			);
                            
      
                             DELETE FROM SPRO_USER WHERE ID_USER_PERFIL =  (IF(NEW.ID_AUTH_PERFIL = 7,5,IF(NEW.ID_AUTH_PERFIL = 6,4,IF(NEW.ID_AUTH_PERFIL =13,13,IF(NEW.ID_MATRIZ > 0,3,2))))) AND ID_MATRIZ = NEW.ID_MATRIZ AND EMAIL = NEW.EMAIL;

                             INSERT IGNORE INTO
			SPRO_USER 
			(
				ID_USER,
				HASH,
				ID_CAMPANHA_ORIG_CAD,
				ID_MATRIZ,
				NOME,
                                                                          SOBRENOME,
				EMAIL,
				APELIDO,
				LOGIN,
                                                                          TIPO_FONE,
				DDD_FONE,
				FONE,
				PASSWD,
				DT_HR_UPD_PASSWD,
				ID_AUTH_FUNCAO,
				BLOQUEADO_EM,
				EXCLUIDO_EM,
                                                                           ID_USER_PERFIL,
				DATA_REGISTRO
			)
		VALUES
			(
				NEW.ID_CLIENTE,
				IF((LENGTH(NEW.HASH) = 0 OR NEW.HASH IS NULL),MD5(NEW.ID_CLIENTE),NEW.HASH),
				NEW.ID_CAMPANHA_ORIG_CAD,
				NEW.ID_MATRIZ,
                                                                          NEW.NOME_PRINCIPAL,
                                                                          NEW.SOBRENOME,
				NEW.EMAIL,
                                                                          IF((LENGTH(NEW.APELIDO) = 0 OR NEW.APELIDO IS NULL),NEW.NOME_PRINCIPAL,NEW.APELIDO),
				IF((LENGTH(NEW.LOGIN) = 0 OR NEW.LOGIN IS NULL),NEW.EMAIL,NEW.LOGIN),
			                'CEL',	
                                                                           NEW.DDD_CELULAR,
				NEW.FONE_CELULAR,
                                                                           IF((LENGTH(NEW.PASSWD) = 0 OR NEW.PASSWD IS NULL),MD5(NEW.SENHA),NEW.PASSWD),
			                   IF(NEW.SENHA_UPD IS NULL,NOW(),NEW.SENHA_UPD),	
				IF(NEW.ID_AUTH_FUNCAO IS NULL,0,NEW.ID_AUTH_FUNCAO),
				IF(NEW.BLOQ = 1, NOW(), NULL),
				IF(NEW.DEL = 1, NOW(), NULL),
                                                                           IF(NEW.ID_AUTH_PERFIL = 7,5,IF(NEW.ID_AUTH_PERFIL = 6,4,IF(NEW.ID_AUTH_PERFIL =13,5,IF(NEW.ID_MATRIZ > 0,3,2)))),
				NEW.DATA_REGISTRO
			);

		INSERT INTO 
			SPRO_USER_TRIGGER
			(
				ORIGEM,
				TIPO,
				DESTINO,
				ID,
				DATA_REGISTRO
			)
		VALUES
			(
				'CLIENTE',
				'INSERT',
				'CADASTRO',
				NEW.ID_CLIENTE,
				NOW()
			);
		
                                     DELETE FROM SPRO_USER_CADASTRO WHERE ID_USER = NEW.ID_CLIENTE;

		INSERT IGNORE INTO
			SPRO_USER_CADASTRO
			(
				ID_USER,
                                                                          TAG,
				PF_PJ,
				CPF_CNPJ,
				INSC_ESTADUAL,
				INSC_MUNICIPAL,
				RAZAO_SOCIAL,
				DATA_CONTRATO_PJ_RECEB,
				SEXO,
				COD_POSTAL,
				LOGRADOURO,
				NUMERO,
				COMPLEMENTO,
				BAIRRO,
				CIDADE,
				UF,
				NOME_CONTATO,
				DDD_FONE_CONTATO,
				FONE_CONTATO,
				RAMAL_CONTATO,
				DDD_FAX,
				FONE_FAX,
				RAMAL_FAX,
				DT_NASCIMENTO,
				DDD_FONE_RESID,			
				FONE_RESID,
				DDD_FONE_COM,
				FONE_COM,
				RAMAL_COM,
				DATA_REGISTRO
			)
		VALUES
			(
				NEW.ID_CLIENTE,
                                                                          NEW.TAG,
				NEW.PF_PJ,
				NEW.CPF_CNPJ,
				NEW.INSC_EST,
				NEW.INSC_MUN,
				NEW.RAZAO_SOCIAL,
				NEW.DATA_CONTRATO_RECEB,
				NEW.SEXO,
				NEW.COD_POSTAL,
				NEW.LOGRADOURO,
				NEW.NUMERO,
				NEW.COMPLEMENTO,
				NEW.BAIRRO,
				NEW.CIDADE,
				NEW.UF,
				NEW.NOME_CONTATO1,
				NEW.DDD_CONTATO1,
				NEW.FONE_CONTATO1,
				NEW.RAMAL_CONTATO1,
				NEW.DDD_FAX,
				NEW.FONE_FAX,
				NEW.RAMAL_FAX,
				NEW.ANIVERSARIO,
				NEW.DDD_RESID,			
				NEW.FONE_RESID,
				NEW.DDD_COM1,
				NEW.FONE_COM1,
				NEW.RAMAL_COM1,
				NEW.DATA_REGISTRO
			);			
		
	END IF;
	
END;

