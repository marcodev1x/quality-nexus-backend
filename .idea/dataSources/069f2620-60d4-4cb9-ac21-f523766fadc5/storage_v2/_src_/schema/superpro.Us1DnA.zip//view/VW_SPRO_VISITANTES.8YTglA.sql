create definer = staging@`%` view VW_SPRO_VISITANTES as
select distinct `superpro`.`SPRO_CLIENTE`.`ID_CLIENTE` AS `ID_CLIENTE`, `superpro`.`SPRO_CLIENTE`.`EMAIL` AS `EMAIL`
from `superpro`.`SPRO_CLIENTE`
where ((not ((`superpro`.`SPRO_CLIENTE`.`EMAIL` like '%interbits%'))) and
       (not ((`superpro`.`SPRO_CLIENTE`.`EMAIL` like '%supervip%'))) and
       (`superpro`.`SPRO_CLIENTE`.`EMAIL` like '%@%') and `superpro`.`SPRO_CLIENTE`.`ID_CLIENTE` in
                                                          (select distinct `superpro`.`SPRO_AUTH_HIST_ACESSO`.`ID_LOGIN` AS `ID_LOGIN`
                                                           from `superpro`.`SPRO_AUTH_HIST_ACESSO`) and
       `superpro`.`SPRO_CLIENTE`.`ID_CLIENTE` in (select `superpro`.`SPRO_ECOMM_PEDIDO`.`ID_CLIENTE` AS `ID_CLIENTE`
                                                  from `superpro`.`SPRO_ECOMM_PEDIDO`
                                                  where (`superpro`.`SPRO_ECOMM_PEDIDO`.`VALOR_TOTAL` > 0)) is false);

