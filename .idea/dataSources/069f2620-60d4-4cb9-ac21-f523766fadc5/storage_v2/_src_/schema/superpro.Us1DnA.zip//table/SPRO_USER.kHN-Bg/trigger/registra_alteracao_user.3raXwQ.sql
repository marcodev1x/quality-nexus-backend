create definer = admin@`%` trigger registra_alteracao_user
    after update
    on SPRO_USER
    for each row
BEGIN
INSERT into SPRO_HIST_ALTERACAO_SPRO_USER values 
		(
		OLD.ID_USER,
		OLD.ID_MATRIZ,
		NEW.ID_MATRIZ,
		OLD.NOME,
		NEW.NOME,
		OLD.EMAIL,
		NEW.EMAIL,
		OLD.LOGIN,
		NEW.LOGIN,
		OLD.EXCLUIDO_EM,
		NEW.EXCLUIDO_EM,
		OLD.BLOQUEADO_EM,
		NEW.BLOQUEADO_EM,
		OLD.DATA_REGISTRO,
		NEW.DATA_REGISTRO,
		NOW()
		);
END;

