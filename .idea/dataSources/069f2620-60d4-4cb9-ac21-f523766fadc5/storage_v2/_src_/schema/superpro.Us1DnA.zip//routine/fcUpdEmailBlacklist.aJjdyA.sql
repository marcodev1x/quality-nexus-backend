create
    definer = admin@`%` function fcUpdEmailBlacklist() returns int
BEGIN
	# 09/06/2014
	# Atualiza a tabela de blacklist com novas inserções.
	# 
	# @author Claudio Rubens Silva Filho

	DECLARE TOTAL_LINHAS_NOVAS int(11);
	DECLARE TOTAL_LINHAS_ANTES int(11);
	DECLARE TOTAL_LINHAS_DEPOIS int(11);
	

	# Guarda o total de registros atual antes de incluir novos registros.
	SELECT COUNT(*) INTO TOTAL_LINHAS_ANTES FROM SPRO_MAIL_BLK_LIST;

	# Faz a inclusão de novos registros.
	REPLACE INTO SPRO_MAIL_BLK_LIST (SELECT EMAIL FROM LIX_EMAIL);

	# Guarda o total de registros atual, após a inclusão dos novos registros.
	SELECT COUNT(*) INTO TOTAL_LINHAS_DEPOIS FROM SPRO_MAIL_BLK_LIST;
	SET TOTAL_LINHAS_NOVAS = TOTAL_LINHAS_DEPOIS - TOTAL_LINHAS_ANTES;

	RETURN TOTAL_LINHAS_NOVAS;

END;

