create
    definer = admin@`%` function fcTipoMeioPagamento(id_meio int) returns varchar(10)
BEGIN
	declare tipo varchar(10);

	case 
	when id_meio in (1,13, 18,19) then set tipo = 'Boleto';
	when id_meio in (2,3,4,15,16,17) then set tipo = 'Crédito';
	when id_meio = 5 then set tipo = 'Amex';
	when id_meio in (6,7,8,9) then set tipo = 'Débito';
	when id_meio in (10,11,12) then set tipo = 'Depósito';
	when id_meio = 20 then set tipo = 'Pix';
	else set tipo = 'Outro';
	end case;

return tipo;
END;

