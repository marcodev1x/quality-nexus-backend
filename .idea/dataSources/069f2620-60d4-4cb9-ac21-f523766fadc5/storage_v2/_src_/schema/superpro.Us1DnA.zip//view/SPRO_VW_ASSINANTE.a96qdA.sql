create definer = staging@`%` view SPRO_VW_ASSINANTE as
select `TB1`.`ID_PEDIDO`                                                                                           AS `ID_PEDIDO`,
       `TB1`.`ID_MATRIZ`                                                                                           AS `ID_MATRIZ`,
       `TB1`.`ID_PLANO`                                                                                            AS `ID_PRECO_PLANO`,
       `TB1`.`ID_FILIAL`                                                                                           AS `ID_FILIAL`,
       `TB1`.`ID_PLANO`                                                                                            AS `ID_PLANO`,
       (select `TB`.`ID_USER_PERFIL`
        from `superpro`.`SPRO_USER` `TB`
        where (`TB`.`ID_USER` = `TB1`.`ID_CLIENTE`))                                                               AS `ID_USER_PERFIL`,
       (select `TB_A`.`CODIGO_PLANO`
        from (`superpro`.`SPRO_PLANO_CONSUMO` `TB_A` join `superpro`.`SPRO_PRECO_PLANO` `TB_B`
              on ((`TB_A`.`ID_PLANO_CONSUMO` = `TB_B`.`ID_PLANO_CONSUMO`)))
        where (`TB_B`.`ID_PRECO_PLANO` = `TB1`.`ID_PLANO`))                                                        AS `CODIGO_PLANO`,
       `TB2`.`SALDO_FINAL`                                                                                         AS `SALDO_FINAL`,
       `TB1`.`ID_CLIENTE`                                                                                          AS `ID_CLIENTE`,
       `TB1`.`NUM_PEDIDO_PAI`                                                                                      AS `NUM_PEDIDO_PAI`,
       `TB1`.`NUM_PEDIDO`                                                                                          AS `NUM_PEDIDO`,
       `TB1`.`STR_NUM_PGTO`                                                                                        AS `STR_NUM_PGTO`,
       `TB1`.`NOME_CLIENTE`                                                                                        AS `NOME_CLIENTE`,
       `TB1`.`DESCR_PRODUTO`                                                                                       AS `DESCR_PRODUTO`,
       `TB1`.`NUM_PEDIDO_VER_WEB`                                                                                  AS `NUM_PEDIDO_VER_WEB`,
       (select `TB`.`EMAIL`
        from `superpro`.`SPRO_USER` `TB`
        where (`TB`.`ID_USER` = `TB1`.`ID_CLIENTE`))                                                               AS `EMAIL_CLIENTE`,
       (select `TB`.`UF`
        from `superpro`.`SPRO_CLIENTE` `TB`
        where (`TB`.`ID_CLIENTE` = `TB1`.`ID_CLIENTE`))                                                            AS `UF`,
       `TB1`.`FORMA_PGTO`                                                                                          AS `FORMA_PGTO`,
       `TB1`.`ID_MEIO_PGTO`                                                                                        AS `ID_MEIO_PGTO`,
       `TB1`.`PARCELAS`                                                                                            AS `PARCELAS`,
       `TB1`.`VALOR_TOTAL`                                                                                         AS `VALOR_TOTAL`,
       `TB1`.`VALOR_PARCELA`                                                                                       AS `VALOR_PARCELA`,
       `TB1`.`VALOR_ADM`                                                                                           AS `VALOR_ADM`,
       `TB1`.`CREDITOS`                                                                                            AS `CREDITOS`,
       `TB1`.`VALIDADE_CREDITOS`                                                                                   AS `VALIDADE_CREDITOS`,
       `TB1`.`ID_PEDIDO_LOJA`                                                                                      AS `ID_PEDIDO_LOJA`,
       `TB1`.`SESSION_ID`                                                                                          AS `SESSION_ID`,
       `TB1`.`ID_STATUS_LOJA`                                                                                      AS `ID_STATUS_LOJA`,
       `TB1`.`MSG_BANCO`                                                                                           AS `MSG_BANCO`,
       `TB1`.`VISA_TID`                                                                                            AS `VISA_TID`,
       `TB1`.`AMEX_NUM_CAPTURA`                                                                                    AS `AMEX_NUM_CAPTURA`,
       `TB1`.`COD_BANCO`                                                                                           AS `COD_BANCO`,
       `TB1`.`COD_AUTH`                                                                                            AS `COD_AUTH`,
       `TB1`.`COD_RET`                                                                                             AS `COD_RET`,
       `TB1`.`NR_CARTAO`                                                                                           AS `NR_CARTAO`,
       `TB1`.`EMAIL_ENV_CLI`                                                                                       AS `EMAIL_ENV_CLI`,
       `TB1`.`OBS`                                                                                                 AS `OBS`,
       `TB1`.`NAO_QUERO_PROMO`                                                                                     AS `NAO_QUERO_PROMO`,
       `TB1`.`CUPOM`                                                                                               AS `CUPOM`,
       `TB1`.`XML_RETORNO`                                                                                         AS `XML_RETORNO`,
       `TB1`.`DATA_PGTO`                                                                                           AS `DATA_PGTO`,
       `TB1`.`DATA_VENC_BOLETO`                                                                                    AS `DATA_VENC_BOLETO`,
       `TB1`.`DATA_FAT_CALC`                                                                                       AS `DATA_FAT_CALC`,
       `TB1`.`DATA_REGISTRO`                                                                                       AS `DATA_REGISTRO`,
       `TB2`.`CREDITO`                                                                                             AS `CREDITO`,
       `TB2`.`VENCIMENTO`                                                                                          AS `VENCIMENTO`,
       `TB2`.`HISTORICO_APARTIR_DE`                                                                                AS `HISTORICO_APARTIR_DE`
from (`superpro`.`SPRO_ECOMM_PEDIDO` `TB1` join `superpro`.`SPRO_CREDITO_CONSOLIDADO` `TB2`
      on (((`TB1`.`NUM_PEDIDO` = `TB2`.`NUM_PEDIDO`) and (`TB1`.`ID_CLIENTE` = `TB2`.`ID_CLIENTE`) and
           (ifnull(`TB1`.`ID_MATRIZ`, 0) = 0))))
where ((ifnull(`TB1`.`NUM_PEDIDO_PAI`, 0) = 0) and ((select `TB3`.`ID_CLIENTE`
                                                     from `superpro`.`SPRO_CLIENTE` `TB3`
                                                     where (((`TB3`.`EMAIL` like '%supervip%') or
                                                             ((`TB3`.`EMAIL` like '%interbits%') and (`TB3`.`ID_CLIENTE` <> 26436)) or
                                                             (`TB3`.`EMAIL` like '%teste%')) and
                                                            (`TB3`.`ID_CLIENTE` = `TB1`.`ID_CLIENTE`))) is null) and
       (`TB2`.`NUM_PEDIDO` > 0) and (ifnull(`TB2`.`BONUS`, 0) = 0) and (`TB2`.`VENCIMENTO` >= curdate()));

-- comment on column SPRO_VW_ASSINANTE.STR_NUM_PGTO not supported: Identifica o pagamento atual. ÃƒÅ¡lil para pedidos vinculados a um pedido pai (Ex: 1_3 = pagamento 1 do total de trÃƒÂªs)

