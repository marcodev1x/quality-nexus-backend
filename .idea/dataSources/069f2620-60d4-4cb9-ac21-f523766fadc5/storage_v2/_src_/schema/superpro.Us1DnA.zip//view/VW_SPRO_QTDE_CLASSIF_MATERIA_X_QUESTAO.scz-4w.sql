create definer = admin@`%` view VW_SPRO_QTDE_CLASSIF_MATERIA_X_QUESTAO as
select `superpro`.`SPRO_CLASSIFICACAO_QUESTAO`.`ID_MATERIA`     AS `ID_MATERIA`,
       count(0)                                                 AS `QTDE_ROWS`,
       `superpro`.`SPRO_CLASSIFICACAO_QUESTAO`.`ID_BCO_QUESTAO` AS `ID_BCO_QUESTAO`
from `superpro`.`SPRO_CLASSIFICACAO_QUESTAO`
group by `superpro`.`SPRO_CLASSIFICACAO_QUESTAO`.`ID_MATERIA`, `superpro`.`SPRO_CLASSIFICACAO_QUESTAO`.`ID_BCO_QUESTAO`;

