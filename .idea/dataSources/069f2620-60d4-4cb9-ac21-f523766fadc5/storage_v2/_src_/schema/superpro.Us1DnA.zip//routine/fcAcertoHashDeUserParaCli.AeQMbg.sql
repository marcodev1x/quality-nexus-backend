create
    definer = admin@`%` function fcAcertoHashDeUserParaCli(HASH_USER char(64)) returns int
BEGIN
	# 11/05/2014
	# Mantém a paridade do HASH entre as tabelas SPRO_CLIENTE e SPRO_USER
	# @author Claudio Rubens Silva Filho

	DECLARE ID_CLIENTE_ INT;
	DECLARE ID_USER_ INT;
	DECLARE ALTERADO INT;
	
	SET ALTERADO = 0;

	SELECT HIGH_PRIORITY ID_CLIENTE INTO ID_CLIENTE_ FROM SPRO_CLIENTE WHERE HASH = HASH_USER;
	
	IF (ID_CLIENTE_ = 0 OR ID_CLIENTE_ IS NULL) THEN
		# O hash informado não existe na tabela Cliente.
	  SELECT HIGH_PRIORITY ID_USER INTO ID_USER_ FROM SPRO_USER WHERE HASH = HASH_USER;
		
		IF (ID_USER_ > 0) THEN
			# Encontrou um usuário com o hash atual
			UPDATE SPRO_CLIENTE SET HASH = HASH_USER WHERE ID_CLIENTE = ID_USER_;
			SET ALTERADO = 1;
		ELSE 
			SET ALTERADO = ID_USER_;
		END IF;		
	END IF;
	RETURN ALTERADO;
END;

