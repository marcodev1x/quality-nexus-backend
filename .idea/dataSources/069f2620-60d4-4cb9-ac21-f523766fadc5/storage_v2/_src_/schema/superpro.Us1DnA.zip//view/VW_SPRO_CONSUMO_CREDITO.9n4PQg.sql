create definer = admin@`%` view VW_SPRO_CONSUMO_CREDITO as
select `superpro`.`SPRO_CONSUMO_CREDITO`.`ID_CONSUMO_CREDITO`                        AS `ID_CONSUMO_CREDITO`,
       `superpro`.`SPRO_CONSUMO_CREDITO`.`ID_CLIENTE`                                AS `ID_CLIENTE`,
       `superpro`.`SPRO_CONSUMO_CREDITO`.`DEBITO`                                    AS `DEBITO`,
       `superpro`.`SPRO_CONSUMO_CREDITO`.`SUFIXO`                                    AS `SUFIXO`,
       `superpro`.`SPRO_CONSUMO_CREDITO`.`REFERENCIA`                                AS `REFERENCIA`,
       `superpro`.`SPRO_CONSUMO_CREDITO`.`ID_HIST_GERADOC`                           AS `ID_HIST_GERADOC`,
       `superpro`.`SPRO_CONSUMO_CREDITO`.`DATA_REGISTRO`                             AS `DATA_REGISTRO`,
       `superpro`.`SPRO_CLIENTE`.`NOME_PRINCIPAL`                                    AS `NOME_PRINCIPAL`,
       `superpro`.`SPRO_CLIENTE`.`SOBRENOME`                                         AS `SOBRENOME`,
       `superpro`.`SPRO_CLIENTE`.`EMAIL`                                             AS `EMAIL`,
       `superpro`.`SPRO_HISTORICO_GERADOC`.`DESCR_ARQ`                               AS `DESCR_ARQ`,
       `superpro`.`SPRO_HISTORICO_GERADOC`.`ITENS_SELECIONADOS`                      AS `ITENS_SELECIONADOS`,
       `superpro`.`SPRO_HISTORICO_GERADOC`.`ITENS_ORDENADOS`                         AS `ITENS_ORDENADOS`,
       date_format(`superpro`.`SPRO_HISTORICO_GERADOC`.`DATA_REGISTRO`, '%d/%m/%Y')  AS `DATA_REGISTRO_BR`,
       `superpro`.`SPRO_HISTORICO_GERADOC`.`DT_HR_VALIDADE`                          AS `DT_HR_VALIDADE`,
       date_format(`superpro`.`SPRO_HISTORICO_GERADOC`.`DT_HR_VALIDADE`, '%d/%m/%Y') AS `DT_HR_VALIDADE_BR`,
       `superpro`.`SPRO_HISTORICO_GERADOC`.`COD_LISTA`                               AS `COD_LISTA`,
       `superpro`.`SPRO_HISTORICO_GERADOC`.`LISTA_ATIVA`                             AS `LISTA_ATIVA`,
       `superpro`.`SPRO_HISTORICO_GERADOC`.`VER_IMPRESSA`                            AS `VER_IMPRESSA`,
       `superpro`.`SPRO_CONSUMO_CREDITO`.`TIPO`                                      AS `TIPO`,
       `superpro`.`SPRO_HISTORICO_GERADOC`.`FORMATO`                                 AS `FORMATO`,
       `superpro`.`SPRO_HISTORICO_GERADOC`.`DEL`                                     AS `DEL`,
       `superpro`.`SPRO_HISTORICO_GERADOC`.`ST_GABARITO_ALUNO`                       AS `ST_GABARITO_ALUNO`,
       `superpro`.`SPRO_HISTORICO_GERADOC`.`NUM_QUESTOES`                            AS `NUM_QUESTOES`,
       `superpro`.`SPRO_HISTORICO_GERADOC`.`LISTA_ATIVA_DT_HR_FIM`                   AS `LISTA_ATIVA_DT_HR_FIM`,
       `superpro`.`SPRO_HISTORICO_GERADOC`.`LISTA_ATIVA_DT_HR_INI`                   AS `LISTA_ATIVA_DT_HR_INI`,
       `superpro`.`SPRO_HISTORICO_GERADOC`.`ORIGEM`                                  AS `ORIGEM`
from ((`superpro`.`SPRO_CONSUMO_CREDITO` join `superpro`.`SPRO_CLIENTE` on ((`superpro`.`SPRO_CLIENTE`.`ID_CLIENTE` =
                                                                             `superpro`.`SPRO_CONSUMO_CREDITO`.`ID_CLIENTE`))) join `superpro`.`SPRO_HISTORICO_GERADOC`
      on ((`superpro`.`SPRO_HISTORICO_GERADOC`.`ID_HISTORICO_GERADOC` =
           `superpro`.`SPRO_CONSUMO_CREDITO`.`ID_HIST_GERADOC`)));

