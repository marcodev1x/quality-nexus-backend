create definer = admin@`%` view VW_SPRO_ANO_QUESTAO as
select distinct `superpro`.`SPRO_BCO_QUESTAO`.`ANO` AS `ANO`
from `superpro`.`SPRO_BCO_QUESTAO`
order by `superpro`.`SPRO_BCO_QUESTAO`.`ANO` desc;

