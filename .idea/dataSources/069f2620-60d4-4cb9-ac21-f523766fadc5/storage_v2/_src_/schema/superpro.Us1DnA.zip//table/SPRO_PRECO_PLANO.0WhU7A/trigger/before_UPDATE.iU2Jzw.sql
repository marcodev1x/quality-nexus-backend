create definer = admin@`%` trigger before_UPDATE
    before update
    on SPRO_PRECO_PLANO
    for each row
BEGIN
	INSERT INTO SPRO_PRECO_PLANO_UPD (SELECT *, NOW() AS UPDATED_AT FROM SPRO_PRECO_PLANO WHERE ID_PRECO_PLANO = OLD.ID_PRECO_PLANO);
END;

