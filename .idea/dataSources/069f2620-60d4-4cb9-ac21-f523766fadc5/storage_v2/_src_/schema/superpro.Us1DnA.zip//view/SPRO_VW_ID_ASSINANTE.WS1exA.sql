create definer = staging@`%` view SPRO_VW_ID_ASSINANTE as
select `TB1`.`ID_CLIENTE` AS `ID_CLIENTE`, `TB1`.`EMAIL_CLIENTE` AS `EMAIL_CLIENTE`
from (`superpro`.`SPRO_ECOMM_PEDIDO` `TB1` join `superpro`.`SPRO_CREDITO_CONSOLIDADO` `TB2`
      on (((`TB1`.`ID_CLIENTE` = `TB2`.`ID_CLIENTE`) and (`TB1`.`NUM_PEDIDO` = `TB2`.`NUM_PEDIDO`) and
           ((`TB1`.`ID_MATRIZ` = 0) or (`TB1`.`ID_MATRIZ` is null)))))
where ((ifnull(`TB1`.`NUM_PEDIDO_PAI`, 0) = 0) and (not ((`TB1`.`EMAIL_CLIENTE` like '%supervip%'))) and
       ((not ((`TB1`.`EMAIL_CLIENTE` like '%interbits%'))) or (`TB1`.`ID_CLIENTE` = 26436)) and
       (not ((`TB1`.`EMAIL_CLIENTE` like '%teste%'))) and (`TB2`.`NUM_PEDIDO` > 0) and (`TB2`.`BONUS` = 0) and
       (`TB1`.`ID_PLANO` > 0) and (`TB2`.`VENCIMENTO` >= curdate()));

