create definer = admin@`%` trigger update_cliente_copy
    after update
    on SPRO_CLIENTE_1507
    for each row
BEGIN
	IF (NEW.DEL != OLD.DEL AND NEW.DEL = 1 AND NEW.ID_AUTH_PERFIL = 6) THEN
		# Trata-se de um cadastro de escola. O registro foi excluído
		# Exclui o prefixo da escola
		DELETE FROM SPRO_USER_ESCOLA WHERE ID_USER = NEW.ID_CLIENTE;
	END IF;

END;

