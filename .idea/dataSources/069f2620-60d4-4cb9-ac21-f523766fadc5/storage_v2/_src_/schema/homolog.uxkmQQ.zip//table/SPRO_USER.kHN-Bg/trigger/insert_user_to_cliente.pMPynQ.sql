create definer = admin@`%` trigger insert_user_to_cliente
    after insert
    on SPRO_USER
    for each row
BEGIN
	SELECT COUNT(1) INTO @QTD FROM SPRO_USER_TRIGGER WHERE ID = NEW.ID_USER;
    
	IF(@QTD > 0) THEN
		DELETE FROM SPRO_USER_TRIGGER WHERE ID = NEW.ID_USER;
	ELSE
		INSERT INTO 
			SPRO_USER_TRIGGER
			(
				ORIGEM,
				TIPO,
				DESTINO,
				ID,
				DATA_REGISTRO
			)
		VALUES
			(
				'USER',
				'INSERT',
				'CLIENTE',
				NEW.ID_USER,
				NOW()
			);
			
		INSERT INTO
			SPRO_CLIENTE 
			(
				ID_CLIENTE,
				HASH,
                                                                           ID_AUTH_PERFIL,
				ID_CAMPANHA_ORIG_CAD,
				ID_MATRIZ,
                                                                           ID_FILIAL,
				NOME_PRINCIPAL,
                                                                           SOBRENOME,
				EMAIL,
				APELIDO,
				LOGIN,
				DDD_CELULAR,
				FONE_CELULAR,
				PASSWD,
				SENHA_UPD,
				ID_AUTH_FUNCAO,
				BLOQ,
				DEL,
				DATA_REGISTRO
			)
		VALUES
			(
				NEW.ID_USER,
				NEW.HASH,
                                                                          IF(NEW.ID_USER_PERFIL <= 3,2,IF(NEW.ID_USER_PERFIL = 4,6,IF(NEW.ID_USER_PERFIL = 5,7,0))),
				NEW.ID_CAMPANHA_ORIG_CAD,
				NEW.ID_MATRIZ,
                                                                          NEW.ID_MATRIZ,
				NEW.NOME,
				NEW.SOBRENOME,
				NEW.EMAIL,
				NEW.APELIDO,
				NEW.LOGIN,
				NEW.DDD_FONE,
				NEW.FONE,
				NEW.PASSWD,
				NEW.DT_HR_UPD_PASSWD,
				NEW.ID_AUTH_FUNCAO,
				IF(NEW.BLOQUEADO_EM IS NULL OR NEW.BLOQUEADO_EM = '0000-00-00 00:00:00', 0, 1),
				IF(NEW.EXCLUIDO_EM IS NULL OR NEW.EXCLUIDO_EM = '0000-00-00 00:00:00', 0, 1),
				NEW.DATA_REGISTRO
			);
	END IF;
	
END;

